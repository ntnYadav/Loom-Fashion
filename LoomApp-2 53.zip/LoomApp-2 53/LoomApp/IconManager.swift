//
//  Untitled.swift
//  LoomApp
//
//  Created by Flucent tech on 14/08/25.
//

import UIKit

class IconManager {
    static let shared = IconManager()

    func updateAppIconIfNeeded() {
        let defaults = UserDefaults.standard
        let currentDate = Date()

        if let firstLaunch = defaults.object(forKey: "firstLaunchDate") as? Date {
            let twoDaysLater = Calendar.current.date(byAdding: .day, value: 2, to: firstLaunch)!

            if currentDate >= twoDaysLater {
                switchToAlternateIcon()
            }
        } else {
            // Save launch date on first run
            defaults.set(currentDate, forKey: "firstLaunchDate")
        }
    }

    private func switchToAlternateIcon() {
        guard UIApplication.shared.supportsAlternateIcons else { return }

        UIApplication.shared.setAlternateIconName("IconB") { error in
            if let error = error {
                print("Error changing icon: \(error.localizedDescription)")
            } else {
                print("Icon changed to IconB successfully.")
            }
        }
    }
}
