import UIKit

class CouponBankCartCell: UICollectionViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblProductAll: UILabel!
    @IBOutlet weak var lblDescribe: UILabel!
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var lblCoupon: UILabel!
    @IBOutlet weak var lblCouponOffer: UILabel!
    @IBOutlet weak var lblTC: UILabel!
    @IBOutlet weak var lblOffer: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnCoupon: UIButton!
    @IBOutlet weak var btnCouponApply: UIButton!

    @IBOutlet weak var btnViewAll: UIButton!
    @IBOutlet weak var btnapplylabel: UIButton!
    @IBOutlet weak var btnTNC: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Good place for one-time setup (colors, fonts, etc.)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        //lblCouponOffer.font = UIFont(name: ConstantFontSize.regular, size: 14)
        lblProductAll.font = UIFont(name: ConstantFontSize.regular, size: 12)
        //lblCouponOffer.textColor = UIColor.blue
        lblProductAll.textColor = UIColor.blue

        applyDashedBorderToLabel()
        
       // innerView.dropShadow(color: .lightGray, opacity: 0.5, offSet: CGSize(width: -1, height: 0.5), radius: 3, scale: true)

    }

    private func applyDashedBorderToLabel() {
        // Remove existing dashed border
        lblCoupon.layer.sublayers?
            .filter { $0.name == "dashedBorder" }
            .forEach { $0.removeFromSuperlayer() }

        let dashBorder = CAShapeLayer()
        dashBorder.name = "dashedBorder"
        dashBorder.strokeColor = UIColor.black.cgColor
        dashBorder.lineDashPattern = [4, 4]
        dashBorder.fillColor = nil
        dashBorder.lineWidth = 1
        dashBorder.frame = lblCoupon.bounds
        dashBorder.path = UIBezierPath(rect: lblCoupon.bounds).cgPath

        lblCoupon.layer.addSublayer(dashBorder)
    }
}
