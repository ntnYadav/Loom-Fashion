//
//  ExpandableCell.swift
//  expandableCellDemo
//
//  Created by Itsuki on 2023/10/23.
//

import UIKit


class priceDetailCell: UICollectionViewCell {
    static let cellIdentifier = String(describing: priceDetailCell.self)
   
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
   
        
   
}
