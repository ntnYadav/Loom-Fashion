//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//WalletDetailTableCell

import UIKit
import SVGKit

class LMViewMore : UITableViewCell {
    @IBOutlet weak var btnViewmore: UIButton!
    @IBOutlet weak var lblName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
     
    }
}


