import UIKit

class CouponBankCell: UICollectionViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblProductAll: UILabel!
    @IBOutlet weak var lblDescribe: UILabel!
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var lblCoupon: UILabel!
    @IBOutlet weak var lblCouponOffer: UILabel!
    @IBOutlet weak var lblTC: UILabel!
    @IBOutlet weak var lblOffer: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnCoupon: UIButton!
    @IBOutlet weak var btntnc: UIButton!

    @IBOutlet weak var btnViewAllProduct: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Good place for one-time setup (colors, fonts, etc.)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        lblCouponOffer.font = UIFont(name: ConstantFontSize.regular, size: 14)
        lblProductAll.font = UIFont(name: ConstantFontSize.regular, size: 12)
        lblCouponOffer.textColor = UIColor.blue
        lblProductAll.textColor = UIColor.blue

        applyDashedBorderToLabel()
        innerView.layer.borderColor = UIColor.lightGray.cgColor
        innerView.layer.borderWidth = 1

//        innerView.dropShadow(color: .lightGray, opacity: 0.5, offSet: CGSize(width: -1, height: 0.5), radius: 3, scale: true)

    }

    private func applyDashedBorderToLabel() {
        // Remove existing dashed border
        lblCoupon.layer.sublayers?
            .filter { $0.name == "dashedBorder" }
            .forEach { $0.removeFromSuperlayer() }

        let dashBorder = CAShapeLayer()
        dashBorder.name = "dashedBorder"
        dashBorder.strokeColor = UIColor.black.cgColor
        dashBorder.lineDashPattern = [4, 4]
        dashBorder.fillColor = nil
        dashBorder.lineWidth = 1
        dashBorder.frame = lblCoupon.bounds
        dashBorder.path = UIBezierPath(rect: lblCoupon.bounds).cgPath

        lblCoupon.layer.addSublayer(dashBorder)
    }
}
extension UIView {

  // OUTPUT 1
//  func dropShadow(scale: Bool = true) {
//    layer.masksToBounds = false
//    layer.shadowColor = UIColor.black.cgColor
//    layer.shadowOpacity = 0.5
//    layer.shadowOffset = CGSize(width: -1, height: 1)
//    layer.shadowRadius = 1
//
//    layer.shadowPath = UIBezierPath(rect: bounds).cgPath
//    layer.shouldRasterize = true
//    layer.rasterizationScale = scale ? UIScreen.main.scale : 1
//  }
//
//  // OUTPUT 2
//  func dropShadow(color: UIColor, opacity: Float = 0.1, offSet: CGSize, radius: CGFloat = 1, scale: Bool = true) {
//    layer.masksToBounds = false
//      layer.shadowColor   = UIColor.lightGray.cgColor
//    layer.shadowOpacity = opacity
//    layer.shadowOffset  = offSet
//    layer.shadowRadius  = radius
//
//    layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
//    layer.shouldRasterize = true
//    layer.rasterizationScale = scale ? UIScreen.main.scale : 1
//  }
}
