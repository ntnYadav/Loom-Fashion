//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.

import UIKit
import SVGKit


class LMCoponBankCell: UITableViewCell ,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    var openTNC: ((String) -> Void)?
    var Onapplyaction: ((Int,String) -> Void)?
    var couponarr : CouponData?
    var selectedIndexPathPopular: IndexPath? = nil

//var couponarr:[Couponinitial] = []

    @IBOutlet weak var couponCollection: UICollectionView!
    
    var check = ""
    let  arrCoupon = ["All", "Shirts"]
    var selectedCell = [IndexPath]()
    
    // static let cellIdentifier = String(describing: MainCell.self)

    @IBOutlet weak var label: UILabel!
    
  
    override func awakeFromNib() {
        super.awakeFromNib()
        initalCollectionCall()
    }
    
    func initalCollectionCall() {
        couponCollection.delegate = self
        couponCollection.dataSource = self
       
        couponCollection.register(UINib(nibName: "CouponBankCartCell", bundle: nil), forCellWithReuseIdentifier: "CouponBankCartCell")
        
        couponCollection.reloadData()

    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return couponarr?.applicableCoupons?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = couponCollection.dequeueReusableCell(withReuseIdentifier: "CouponBankCartCell", for: indexPath) as! CouponBankCartCell
       // let obj = arrCoupon[indexPath.row]
        cell.innerView.layer.borderWidth = 1
        cell.innerView.layer.cornerRadius = 5
        
        cell.lblProductAll.text  = ""
        cell.img.image = SVGKImage(named: "offerBank")?.uiImage
        cell.innerView.layer.borderColor = UIColor.lightGray.cgColor
        if selectedIndexPathPopular == indexPath {
            //cell.btnCouponApply.backgroundColor = UIColor.lightGray
            cell.btnapplylabel.backgroundColor = .lightGray
            cell.btnapplylabel.setTitleColor(.black, for: .normal)
            cell.btnapplylabel.setTitle("Applied", for: .normal)
            
        } else {
            cell.btnCouponApply.addTarget(self, action: #selector(LMCoponBankCell.actApplycoupon(_:)), for: .touchUpInside)
            cell.btnCouponApply.tag = indexPath.row
            cell.btnapplylabel.backgroundColor = UIColor.black
            cell.btnapplylabel.setTitle("Apply", for: .normal)
            cell.btnapplylabel.setTitleColor(.white, for: .normal)
        }
        
        
        
        let obj = couponarr?.applicableCoupons?[indexPath.row]
        if let potPrice = obj?.name {
           // let potentialFinalPrice = String(format: "%.0f", potPrice)

            cell.lblOffer.text    = " \(potPrice)" //obj.name
        }
        cell.lblDescribe.text = obj?.description
        if  let couponcode = obj?.code {
            cell.lblCoupon.text   = "  \(couponcode)  "
        }
      
        cell.btnTNC.addTarget(self, action: #selector(LMCoponBankCell.actTNC(_:)), for: .touchUpInside)
        cell.btnCouponApply.tag = indexPath.row

            return cell
        
    }
    
    //7011462743
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            return CGSize(width: 350, height: 180)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    @objc func actApplycoupon(_ sender: UIButton) {
        let tagindex = sender.tag
        selectedIndexPathPopular = IndexPath(row: tagindex, section: 0)
        Onapplyaction?(tagindex, "")
    }
    @objc func actTNC(_ sender: UIButton) {
        
        openTNC?("")
    }
}
