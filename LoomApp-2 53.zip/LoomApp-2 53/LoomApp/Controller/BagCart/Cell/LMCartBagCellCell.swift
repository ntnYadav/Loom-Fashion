//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMCartBagCellCell :UITableViewCell {
    @IBOutlet weak var lblProductDetail: UILabel!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var lblSize: UILabel!
    @IBOutlet weak var viewCell: UIView!
    var productQty: Int = 0
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var btnQtylisting: UIButton!
    @IBOutlet weak var btnMovetoList: UIButton!
    // Note: must be strong
    @IBOutlet weak var btndelete: UIButton!
    @IBOutlet weak var btnImagClick: UIButton!
    var onCollectionItemupdateQty: ((_ index: Int, _ qty: Int) -> Void)?

    override func awakeFromNib() {
        super.awakeFromNib()
    
    }
    
    @IBAction func actQty(_ sender: Any) {
        let tag = ((sender as AnyObject).tag)!
//          let objModel = viewmodel.modelproduct?.items[tag]
          
        if productQty <= 5 {
              let input = (productQty)
              let arr = (1...input).map { "\($0)" }
              RPicker.selectOption(dataArray: arr) {[weak self] (selctedText, atIndex) in
                  self?.lblSize.text = "QTY | \(atIndex + 1)"
                  self?.onCollectionItemupdateQty?(tag, atIndex + 1)

              }
          } else {
              RPicker.selectOption(dataArray: THconstant.arrqty) {[weak self] (selctedText, atIndex) in
                  self?.lblSize.text = "QTY | \(atIndex + 1)"
                      self?.onCollectionItemupdateQty?(tag, atIndex + 1)
                  // TODO: Your implementation for selection
              }
          }
        
    }
    @IBAction func actDelete(_ sender: Any) {
    }
}

