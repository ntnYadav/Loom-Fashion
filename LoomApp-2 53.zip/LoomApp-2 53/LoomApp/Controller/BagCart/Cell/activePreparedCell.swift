//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//WalletDetailTableCell

import UIKit
import SVGKit

class activePreparedCell : UITableViewCell {
    @IBOutlet weak var lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}


