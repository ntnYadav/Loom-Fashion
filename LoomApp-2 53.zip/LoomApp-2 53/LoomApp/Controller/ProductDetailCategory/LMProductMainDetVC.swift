//
//  ViewController.swift
//  CustomHeaderView
//
//  Created by Santosh on 04/08/20.
//  Copyright © 2020 Santosh. All rights reserved.
//

import UIKit
import SwiftUI
import SDWebImage
import SVGKit
struct Section {
    let title: String
    let items: [String]
    var isExpanded: Bool
}

struct SectionData {
    let title: String
    let items: [String]
    var isExpanded: Bool
}
class PagerViewModel: ObservableObject {
    @Published var selectedIndex: Int = 0
}
class LMProductMainDetVC: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var viewHeaderMain: UIView!
    // let  arrCotegory = ["All", "Shirts", "DETAILS","SUBDETAILS", "OFFERS","SUBOFFERS","REVIEWS","SUBREVIEWS1","SUBREVIEWS2","SUBREVIEWS3","DELIVERY", "RETURN", "YOU MAY ALSO LIK"]
    @IBOutlet weak var imgHeart: UIImageView!
    @IBOutlet weak var imgNag: UIImageView!
    @IBOutlet weak var imgBack: UIImageView!
    var  arrCotegory = ["All", "Shirts", "DETAILS","REVIEWS","DELIVERY", "RETURN"]
   // let  arrCotegory = ["All", "Shirts", "DETAILS","SUBDETAILS", "OFFERS","SUBOFFERS","REVIEWS","SUBREVIEWS1","SUBREVIEWS2","SUBREVIEWS3","DELIVERY","DELIVERYDetail", "RETURN","RETURNDetail"]

    var flagDetail = false
    var flagOffer = false
    var flagReview = false
    var flagDelivery = false
    var flagReturn = false
    
    

    let subDetails = ["SUBDETAILS"]
    let subOffers = ["SUBOFFERS"]
    let subReviews1 = ["SUBREVIEWS1"]
    let subReviews2 = ["SUBREVIEWS1", "SUBREVIEWS2"]
    let subReviews3 = ["SUBREVIEWS1", "SUBREVIEWS2","SUBREVIEWS3"]
    let subReviews4 = ["SUBREVIEWS1", "SUBREVIEWS2", "SUBREVIEWS3"]

    let subDelivery = ["DELIVERYDetail"]
    let subReturn = ["RETURNDetail"]


    // Flags to track current expansion state
    var isDetailsExpanded = false
    var isOffersExpanded = false
    var isReviewsExpanded = false
    var isDeliveryExpanded = false
    var isReturnExpanded = false


    var sections: [Section] = [
        Section(title: "All", items: ["Apple"], isExpanded: true),
        Section(title: "Shirts ", items: ["Carrot"], isExpanded: true),
        Section(title: "DETAILS  ", items: ["Carrot"], isExpanded: false),
        Section(title: "REVIEWS ", items: ["Carrot"], isExpanded: false),
        Section(title: "DELIVERY  ", items: ["Carrot"], isExpanded: false),
        Section(title: "RETURN", items: ["Carrot"], isExpanded: false),

    ]
    @IBOutlet weak var imgLike: UIImageView!
    var previousContentOffset: CGFloat = 0
    @IBOutlet weak var btnHeart1: UIButton!
    @IBOutlet weak var imgBag: UIImageView!
    @IBOutlet weak var btnline: UIButton!
    @IBOutlet weak var viewpager: UIView!
    
    @IBOutlet weak var imgBagFinal: UIImageView!
    @IBOutlet weak var backImgfinal: UIImageView!
    var sizeChartUrl: String?
    let pagerModel = PagerViewModel()
    var timer = Timer()
    var currentIndex = 0
    var colorName = ""
    var flag  = true
    var sharedValientID = ""

    var productId:String = keyName.emptyStr
    var defaultVaniantID:String = keyName.emptyStr

    @IBOutlet weak var viewheader: UIView!
    @IBOutlet weak var marqueeContainer: UIView!
    @IBOutlet weak var marqueeLabel: UILabel!
    // MARK: - IBOutlets
    @IBOutlet weak var sheetView: UIView!
    @IBOutlet weak var collectionShirts: UICollectionView!
    @IBOutlet weak var sheetTopConst: NSLayoutConstraint!
    @IBOutlet weak var viewHeight: NSLayoutConstraint!
    
    // MARK: - Properties
    private var panGesture: UIPanGestureRecognizer!
    private var fullViewYPosition: CGFloat = 94
    private var partialViewYPosition: CGFloat = (UIScreen.main.bounds.height - 100) * 0.75
    @IBOutlet weak var tableView: UITableView!
    
    
    
    
    lazy fileprivate var viewmodel = LMProductMainDetailFinalMV(hostController: self)
    var mobileBrand = [MobileBrand]()

    @IBOutlet weak var mainview: UIView!

        var collectionView: UICollectionView!

        override func viewDidLoad() {
             super.viewDidLoad()
            THUserDefaultValue.isUsercolorsize = nil

            viewHeaderMain.alpha = 0
            imgNag.image = SVGKImage(named: "ic_bagfinal")?.uiImage
            imgBack.image = SVGKImage(named: "ic_backfinal")?.uiImage
            imgHeart.image = SVGKImage(named: "ic_heart_empty")?.uiImage
                // Fade in when the view appears
                UIView.animate(withDuration: 0.5) {
                   // self.viewHeaderMain.alpha = 1
                }

            mobileBrand.append(MobileBrand.init(brandName: "Apple", modelName: ["iPhone 5s"]))
            mobileBrand.append(MobileBrand.init(brandName: "Samsung", modelName: ["Samsung M Series"]))
            
             view.backgroundColor = .white

             let layout = UICollectionViewFlowLayout()
             layout.scrollDirection = .vertical
             layout.headerReferenceSize = CGSize(width: view.frame.width, height: 200)
             layout.sectionHeadersPinToVisibleBounds = true // 👈 Make header sticky

             collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: layout)
             collectionView.backgroundColor = .white
             collectionView.delegate = self
             collectionView.dataSource = self
             collectionView.contentInsetAdjustmentBehavior = .never
             collectionView.register(CustomCell.self, forCellWithReuseIdentifier: CustomCell.identifier)
             collectionView.register(UINib(nibName: "LMcellShopCell", bundle: nil), forCellWithReuseIdentifier: "LMcellShopCell")
             collectionView.register(UINib(nibName: "LMcellShopCell2", bundle: nil), forCellWithReuseIdentifier: "LMcellShopCell2")
             collectionView.register(UINib(nibName: "LMProductCell1", bundle: nil), forCellWithReuseIdentifier: "LMProductCell1")
             collectionView.register(UINib(nibName: "LMPDashboardHeaderCell", bundle: nil), forCellWithReuseIdentifier: "LMPDashboardHeaderCell")
            collectionView.register(UINib(nibName: "LMPlaycell", bundle: nil), forCellWithReuseIdentifier: "LMPlaycell")

            collectionView.register(UINib(nibName: "LMProductHeaderDetail", bundle: nil), forCellWithReuseIdentifier: "LMProductHeaderDetail")

            
            collectionView.register(UINib(nibName: "LMcellReviewProduct1", bundle: nil), forCellWithReuseIdentifier: "LMcellReviewProduct1")

            collectionView.register(UINib(nibName: "DetailHTMLcell2", bundle: nil), forCellWithReuseIdentifier: "DetailHTMLcell2")

            collectionView.register(UINib(nibName: "LMPorductBannerCell", bundle: nil), forCellWithReuseIdentifier: "LMPorductBannerCell")

            collectionView.register(UINib(nibName: "ProductDetailCell", bundle: nil), forCellWithReuseIdentifier: "ProductDetailCell")

            collectionView.register(UINib(nibName: "DetailHTMLcell1", bundle: nil), forCellWithReuseIdentifier: "DetailHTMLcell1")


            collectionView.register(UINib(nibName: "DevliaryCell", bundle: nil), forCellWithReuseIdentifier: "DevliaryCell")

            collectionView.register(UINib(nibName: "LMProductTitleCell", bundle: nil), forCellWithReuseIdentifier: "LMProductTitleCell")
            collectionView.register(UINib(nibName: "LMOfferCouponCell", bundle: nil), forCellWithReuseIdentifier: "LMOfferCouponCell")
            collectionView.register(UINib(nibName: "LMcellReviewRating", bundle: nil), forCellWithReuseIdentifier: "LMcellReviewRating")
            collectionView.register(UINib(nibName: "LMcellReviewProduct", bundle: nil), forCellWithReuseIdentifier: "LMcellReviewProduct")

            collectionView.register(UINib(nibName: "LMcellReviewimages", bundle: nil), forCellWithReuseIdentifier: "LMcellReviewimages")

            collectionView.register(UINib(nibName: "DevliaryCell1", bundle: nil), forCellWithReuseIdentifier: "DevliaryCell1")

            collectionView.register(UINib(nibName: "DevliaryCell2", bundle: nil), forCellWithReuseIdentifier: "DevliaryCell2")

             collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")

            collectionView.register(
                UINib(nibName: "searchBarHeaderCv", bundle: nil),
                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                withReuseIdentifier: "searchBarHeaderCv"
            )
            collectionView.register(
                UINib(nibName: "searchBarHeader", bundle: nil),
                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                withReuseIdentifier: "searchBarHeader"
            )
            collectionView.register(
                UINib(nibName: "searchBarHeader2", bundle: nil),
                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                withReuseIdentifier: "searchBarHeader2"
            )
            
            let height = UIScreen.main.bounds.height
           // collectionView.translatesAutoresizingMaskIntoConstraints = false
            mainview.addSubview(collectionView)
            
            collectionView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                collectionView.topAnchor.constraint(equalTo: mainview.topAnchor),
                collectionView.leadingAnchor.constraint(equalTo: mainview.leadingAnchor),
                collectionView.trailingAnchor.constraint(equalTo: mainview.trailingAnchor),
                collectionView.bottomAnchor.constraint(equalTo: mainview.bottomAnchor, constant: -250) // 👈 Reduce 120 from bottom
            ])

            view.bringSubviewToFront(collectionView)
            collectionView.isUserInteractionEnabled = true
            mainview.isUserInteractionEnabled = true
            viewmodel.validateValue(productId: productId, defaultVaniantID: defaultVaniantID)
            viewmodel.validateCoupon()

            viewmodel.validateProductDetail()
            viewmodel.validateReviewDetail(productId:productId)

         }
    
   
    override func viewWillAppear(_ animated: Bool) {
        
             super.viewDidLoad()
            THUserDefaultValue.isUsercolorsize = nil

            viewHeaderMain.alpha = 0
            imgNag.image = SVGKImage(named: "ic_bagfinal")?.uiImage
            imgBack.image = SVGKImage(named: "ic_backfinal")?.uiImage
            imgHeart.image = SVGKImage(named: "ic_heart_empty")?.uiImage
                // Fade in when the view appears
                UIView.animate(withDuration: 0.5) {
                   // self.viewHeaderMain.alpha = 1
                }

            mobileBrand.append(MobileBrand.init(brandName: "Apple", modelName: ["iPhone 5s"]))
            mobileBrand.append(MobileBrand.init(brandName: "Samsung", modelName: ["Samsung M Series"]))
            
             view.backgroundColor = .white

             let layout = UICollectionViewFlowLayout()
             layout.scrollDirection = .vertical
             layout.headerReferenceSize = CGSize(width: view.frame.width, height: 200)
             layout.sectionHeadersPinToVisibleBounds = true // 👈 Make header sticky

             collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: layout)
             collectionView.backgroundColor = .white
             collectionView.delegate = self
             collectionView.dataSource = self
             collectionView.contentInsetAdjustmentBehavior = .never
             collectionView.register(CustomCell.self, forCellWithReuseIdentifier: CustomCell.identifier)
             collectionView.register(UINib(nibName: "LMcellShopCell", bundle: nil), forCellWithReuseIdentifier: "LMcellShopCell")
             collectionView.register(UINib(nibName: "LMcellShopCell2", bundle: nil), forCellWithReuseIdentifier: "LMcellShopCell2")
             collectionView.register(UINib(nibName: "LMProductCell1", bundle: nil), forCellWithReuseIdentifier: "LMProductCell1")
             collectionView.register(UINib(nibName: "LMPDashboardHeaderCell", bundle: nil), forCellWithReuseIdentifier: "LMPDashboardHeaderCell")
            collectionView.register(UINib(nibName: "LMPlaycell", bundle: nil), forCellWithReuseIdentifier: "LMPlaycell")

            collectionView.register(UINib(nibName: "LMProductHeaderDetail", bundle: nil), forCellWithReuseIdentifier: "LMProductHeaderDetail")

            
            collectionView.register(UINib(nibName: "LMcellReviewProduct1", bundle: nil), forCellWithReuseIdentifier: "LMcellReviewProduct1")

            collectionView.register(UINib(nibName: "DetailHTMLcell2", bundle: nil), forCellWithReuseIdentifier: "DetailHTMLcell2")

            collectionView.register(UINib(nibName: "LMPorductBannerCell", bundle: nil), forCellWithReuseIdentifier: "LMPorductBannerCell")

            collectionView.register(UINib(nibName: "ProductDetailCell", bundle: nil), forCellWithReuseIdentifier: "ProductDetailCell")

            collectionView.register(UINib(nibName: "DetailHTMLcell1", bundle: nil), forCellWithReuseIdentifier: "DetailHTMLcell1")


            collectionView.register(UINib(nibName: "DevliaryCell", bundle: nil), forCellWithReuseIdentifier: "DevliaryCell")

            collectionView.register(UINib(nibName: "LMProductTitleCell", bundle: nil), forCellWithReuseIdentifier: "LMProductTitleCell")
            collectionView.register(UINib(nibName: "LMOfferCouponCell", bundle: nil), forCellWithReuseIdentifier: "LMOfferCouponCell")
            collectionView.register(UINib(nibName: "LMcellReviewRating", bundle: nil), forCellWithReuseIdentifier: "LMcellReviewRating")
            collectionView.register(UINib(nibName: "LMcellReviewProduct", bundle: nil), forCellWithReuseIdentifier: "LMcellReviewProduct")

            collectionView.register(UINib(nibName: "LMcellReviewimages", bundle: nil), forCellWithReuseIdentifier: "LMcellReviewimages")

            collectionView.register(UINib(nibName: "DevliaryCell1", bundle: nil), forCellWithReuseIdentifier: "DevliaryCell1")

            collectionView.register(UINib(nibName: "DevliaryCell2", bundle: nil), forCellWithReuseIdentifier: "DevliaryCell2")

             collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")

            collectionView.register(
                UINib(nibName: "searchBarHeaderCv", bundle: nil),
                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                withReuseIdentifier: "searchBarHeaderCv"
            )
            collectionView.register(
                UINib(nibName: "searchBarHeader", bundle: nil),
                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                withReuseIdentifier: "searchBarHeader"
            )
            collectionView.register(
                UINib(nibName: "searchBarHeader2", bundle: nil),
                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                withReuseIdentifier: "searchBarHeader2"
            )
            
            let height = UIScreen.main.bounds.height
           // collectionView.translatesAutoresizingMaskIntoConstraints = false
            mainview.addSubview(collectionView)
            
            collectionView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                collectionView.topAnchor.constraint(equalTo: mainview.topAnchor),
                collectionView.leadingAnchor.constraint(equalTo: mainview.leadingAnchor),
                collectionView.trailingAnchor.constraint(equalTo: mainview.trailingAnchor),
                collectionView.bottomAnchor.constraint(equalTo: mainview.bottomAnchor, constant: -250) // 👈 Reduce 120 from bottom
            ])

            view.bringSubviewToFront(collectionView)
            collectionView.isUserInteractionEnabled = true
            mainview.isUserInteractionEnabled = true
            viewmodel.validateValue(productId: productId, defaultVaniantID: defaultVaniantID)
//            viewmodel.validateCoupon()
            viewmodel.validateProductDetail()
            viewmodel.validateReviewDetail(productId:productId)

         
        collectionView.reloadData()
    }
    
    
//    override var shouldAutorotate: Bool {
//        return false
//    }


        // MARK: - UICollectionViewDataSource
    // MARK: - UICollectionViewDataSource
override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    print("Cell tapped")
    super.touchesBegan(touches, with: event)
}
     
    @objc func actImage(_ sender : UIButton) {
        
    }
    @objc func actsimilar(_ sender : UIButton) {
        let obj = LMSimilarVC()
        obj.modelproduct = viewmodel.modelproduct
        obj.modalPresentationStyle = .overFullScreen
       // obj.modalTransitionStyle = .coverVertical
        self.present(obj, animated: true)
    }
    @objc func likeactionProduct(_ sender : UIButton) {
      //  if THUserDefaultValue.isUserLoging == true {
            
            let objModel = viewmodel.modelproduct?.variantsColor?[0].sizes?[0]
            print(objModel)
            if objModel?.isWishlisted == false {
                viewmodel.modelproduct?.variantsColor?[0].sizes?[0].isWishlisted = true
                //imgLike.image = SVGKImage(named: "ic_heart_fill")?.uiImage
            } else {
                //imgLike.image = SVGKImage(named: "ic_heart_empty")?.uiImage
                viewmodel.modelproduct?.variantsColor?[0].sizes?[0].isWishlisted = false
            }
            
            if self.colorName == "" {
                let color1 = (viewmodel.modelproduct?.variantsColor?[0].value) ?? ""
                viewmodel.callWishListAPI(productId: viewmodel.modelproduct?.productId ?? "", strColor: color1, strVaiantId:viewmodel.modelproduct?.variantsColor?[0].sizes?[0].variantId ?? "")
            } else {
                viewmodel.callWishListAPI(productId: viewmodel.modelproduct?.productId ?? "", strColor: self.colorName, strVaiantId:viewmodel.modelproduct?.variantsColor?[0].sizes?[0].variantId ?? "")
            }
            
        collectionView.reloadData()
           
//        } else {
//               let halfVC = LoginVC()
//               halfVC.modalPresentationStyle = .overFullScreen
//               self.present(halfVC, animated: true)
//
//        }
    }
    @objc func movetoBag() {
        
        
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        if let modalVC = storyboard.instantiateViewController(withIdentifier:VcIdentifier.LMAddresslistVC) as? LMAddresslistVC {
            // self.NavigationController(navigateFrom: self, navigateTo: LMAddresslistVC(), navigateToString: VcIdentifier.LMAddresslistVC)
             
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
             if let modalVC = storyboard.instantiateViewController(withIdentifier:VcIdentifier.LMCartTableVC) as? LMCartTableVC {
                 modalVC.flagBack = false
                 modalVC.navigationControl = true

                 self.navigationController?.pushViewController(modalVC, animated: true)
             }
          
         //}
    }
    @objc func backTapped() {
        self.navigationController?.popViewController(animated: true)
    }
    //2ad^
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return mobileBrand.count

    }
  
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section {
        case 0:
            // return mobileBrand.count
            return arrCotegory.count
            
        case 1:
            // return self?.model?
            return viewmodel.modelproduct?.similarProducts?.count ?? 0
        default:
            return 0
        }
    }
    
    //2ad
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        if indexPath.section == 0 {
            let objMain = arrCotegory[indexPath.row]
            //let objSection = sections[indexPath.row]
            if objMain   == "All" {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMPorductBannerCell", for: indexPath) as! LMPorductBannerCell
                cell.modelproduct = viewmodel.modelproduct
                cell.initalCollectionCall()
                cell.imageOpenincontroller = { currentIndex, str in
                    
                    
                    let fullVC = LMProductdetailsPhotos()
                    fullVC.modelproduct = self.viewmodel.modelproduct
                    fullVC.startIndex = currentIndex
                    fullVC.modalPresentationStyle = .fullScreen
                    fullVC.modalTransitionStyle = .crossDissolve
                    self.present(fullVC, animated: true, completion: nil)
                }

//                let obj = viewmodel.modelproduct?.variants?[0].images?[indexPath.row] ?? keyName.emptyStr
//                DispatchQueue.main.async {
//                    cell.imgProduct.sd_imageIndicator = SDWebImageActivityIndicator.gray
//                    cell.imgProduct.sd_setImage(with: URL(string: obj))
//                }
//                cell.imgBag.image = SVGKImage(named: "ic_bagfinal")?.uiImage
//                cell.imgBack.image = SVGKImage(named: "ic_backfinal")?.uiImage
//                cell.imgHeart.image = SVGKImage(named: "ic_heart_empty")?.uiImage
//                
//                cell.imgProduct.tag = indexPath.item // or your identifier
//                cell.imgProduct.isUserInteractionEnabled = true
                
//
                
                cell.btnSimilar.addTarget(self, action: #selector(LMProductMainDetVC.actsimilar(_:)), for: .touchUpInside)

                cell.btnHeat.addTarget(self, action: #selector(LMProductMainDetVC.likeactionProduct(_:)), for: .touchUpInside)
                cell.btnHeat.tag = indexPath.row
                cell.btnBack.addTarget(self, action: #selector(backTapped), for: .touchUpInside)
                cell.btnBack.tag = indexPath.row

                cell.btnbag.addTarget(self, action: #selector(movetoBag), for: .touchUpInside)
                cell.btnbag.tag = indexPath.row

                let objModel = viewmodel.modelproduct?.variantsColor?[0].sizes?[0]
                if objModel?.isWishlisted == false {
                    cell.imgHeart.image = SVGKImage(named: "ic_heart_empty")?.uiImage
                } else {
                    cell.imgHeart.image = SVGKImage(named: "ic_heart_fill")?.uiImage
                }
//                
//
//               cell.btnHeart.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
//                //cell.progressbar()
//               cell.btnback.addTarget(self, action: #selector(backTapped), for: .touchUpInside)
//                cell.btnBag.addTarget(self, action: #selector(movetoBag), for: .touchUpInside)
//
//                cell.setup()
                return cell
                
            } else if objMain   == "Shirts" {
                // Header Cell
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMProductHeaderDetail", for: indexPath) as! LMProductHeaderDetail
//
                  //  cell.selectionStyle = .none
                
                if viewmodel.couponarr.count != 0 {
                    cell.collectionheight.constant = 215
                } else {
                    cell.collectionheight.constant = 0
                }
                if self.colorName == "" {
                    let color1 = viewmodel.modelproduct?.variantsColor?[0].value
                    cell.lblTitle.text = (viewmodel.modelproduct?.title ?? keyName.emptyStr) + " " + (color1 ?? "")
                } else {
                    cell.lblTitle.text = (viewmodel.modelproduct?.title ?? keyName.emptyStr) + " " + self.colorName

                }
                     //print(viewmodel.modelproduct)
                   // cell.lblprice.text = keyName.rupessymbol + "\(viewmodel.modelproduct?.variants?[0].price.mrp ?? 0)"
                   // cell.lblRating.text = "\(viewmodel.modelproduct?.averageRating)"
                    sizeChartUrl = viewmodel.modelproduct?.sizeChart ?? ""
                
               

                cell.btnChart.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
                cell.btnShare.addTarget(self, action: #selector(sharedImage), for: .touchUpInside)

                cell.onActtnc = { [weak self] indevalue in
                    print("adhjasd")
                    guard let controller = storyboardHome.instantiateViewController(identifier: controllerName.pivacypolicy.controllerID) as? LMPrivacyPolicyVC else {
                        debugPrint("ViewController not found")
                        return
                    }
                    controller.isFrom =  .Tnc
                    self?.navigationController?.pushViewController(controller, animated: true)
                }
                cell.onActProductView = {[weak self] indevalue in
                    let objProduct = self?.storyboard?.instantiateViewController(withIdentifier: VcIdentifier.LMProductDetailVC) as! LMProductDetailVC
//                    objProduct.productId  = prodID
//                    objProduct.strFilter  = strFilter
                    objProduct.productName  = indevalue
                    objProduct.apiCallingCoupon  = "true"

                    
                    objProduct.apiCalling = true
                    self?.navigationController?.pushViewController(objProduct, animated: true)
                }
                cell.oncollectionCoupon = { [weak self] indexValue in
                    let halfVC = CouponsViewController()
                    AppDelegate.shared.headertitle = "Coupon"

//                    if indexValue == 0 {
//                        AppDelegate.shared.headertitle = "Coupon"
//                    } else {
//                        AppDelegate.shared.headertitle = "Coupon"//"Bank Offer"
//                    }
                    
                    halfVC.couponarr = self?.viewmodel.modelCouponInitial ?? []
                    halfVC.modalPresentationStyle = .overFullScreen
                    self?.present(halfVC, animated: true)
                }
                    if let price = viewmodel.modelproduct?.variants?[0].price {
    //                    let mrp = price.mrp
    //                    let sellingPrice = price.sellingPrice
    //                    let discountPercent = price.discountPercents
    //                    let attributedPriceText = createPriceAttributedText(
    //                        discountPercent: 0,
    //                        originalPrice: mrp!,
    //                        discountedPrice: sellingPrice!
    //                    )
    //                    cell.lblprice.attributedText = attributedPriceText
                        
                        
                        
                        
                        let mrp = price.mrp
                        let sellingPrice = price.sellingPrice
                        let discountPercent = price.discountPercents
                        
                        if mrp == sellingPrice {
                        
                            let attributedPriceText = LMGlobal.shared.createPriceAttributedTextWithout(
                                               discountPercent: 0,
                                               originalPrice: 0,
                                               discountedPrice: sellingPrice ?? 0
                                           )
                            cell.lblprice.attributedText = attributedPriceText
                        } else {
                            let attributedPriceText = createPriceAttributedText(
                                discountPercent: 0,
                                originalPrice: mrp!,
                                discountedPrice: sellingPrice!
                            )
                            cell.lblprice.attributedText = attributedPriceText
                            
                        }

                        
                        
                        
                    }
                
                
                
                
                
                
                
                
                
                if let price = viewmodel.modelproduct?.variants?.first?.price {
                    
                    if price.discountType == "flat" {

                        let discount = Int(price.mrp ?? 0) - Int(price.sellingPrice ?? 0)
                        
                        if discount != 0 {
                            cell.lbldiscountPrice.isHidden = false
                            cell.imgBackground.isHidden = false
                            cell.lbldiscountPrice.text = "  ₹\(discount) OFF!"
                          //  cell.lbldiscountPrice.textColor = .white

                            cell.imgBackground.image = UIImage(named: "red-orange")
                        } else {
                            cell.lbldiscountPrice.isHidden = true
                            cell.imgBackground.isHidden = true
                        }
                        
                    } else {
                        if let discountPercent = price.discountPercents, discountPercent != 0 {
                            
                            
                            
                            cell.imgBackground.image = UIImage(named: "green")
                            if let finalDiscountPercent1 = price.discountPercents {
                                
                                let formatted = String(format: "%.0f", discountPercent)
                                if finalDiscountPercent1 != 0 {
                                    cell.lbldiscountPrice.isHidden = false
                                    cell.imgBackground.isHidden = false
                                  
                                    
                                    let formatted = String(format: "%.0f", finalDiscountPercent1)  // "10"
                                   // cell.lbldiscountPrice.textColor = .white
                                    cell.lbldiscountPrice.text = "  \(formatted)% OFF!"

                                    cell.lbldiscountPrice.text = "  ₹\(formatted) % OFF!"
                                } else {
                                   cell.lbldiscountPrice.isHidden = true
                                   cell.imgBackground.isHidden = true
                                }
                            }

                            
                            
                            
                            
                            let formatted = String(format: "%.0f", discountPercent)
                            cell.lbldiscountPrice.isHidden = false
                            cell.imgBackground.isHidden = false
                            cell.lbldiscountPrice.text = "  \(formatted)% OFF!"
                            cell.lbldiscountPrice.textColor = .white

                            cell.imgBackground.image = UIImage(named: "green gradient")
                        } else {
                            cell.lbldiscountPrice.isHidden = true
                            cell.imgBackground.isHidden = true
                        }
                    }
                } else {
                  
                    
                }

                
                
                
                
    //            if objModel.discountType == "flat" {
    //                let discount = Int(objModel.lowestMRP ?? 0) - Int(objModel.lowestSellingPrice ?? 0)
    ////                        cell.lbldiscountPrice.text = "  ₹\(discount) OFF!"
    ////                    cell.imgBackground.image = UIImage(named: "red")
    //                if discount != 0 {
    //                    cell.lbldiscountPrice.text = "  ₹\(discount) OFF!"
    //                    cell.imgBackground.image = UIImage(named: "red")
    //                } else {
    //                   cell.lbldiscountPrice.isHidden = true
    //                   cell.imgBackground.isHidden = true
    //                }
    //            } else {
    //                cell.imgBackground.image = UIImage(named: "green")
    //                if let finalDiscountPercent1 = objModel.finalDiscountPercent {
    //
    //                    let formatted = String(format: "%.0f", finalDiscountPercent1)  // "10"
    //                    if finalDiscountPercent1 != 0 {
    //                        let formatted = String(format: "%.0f", finalDiscountPercent1)  // "10"
    //                        cell.lbldiscountPrice.text = "  ₹\(formatted) % OFF!"
    //                    } else {
    //                       cell.lbldiscountPrice.isHidden = true
    //                       cell.imgBackground.isHidden = true
    //                    }
    //                }
    //            }
    //
    //
                
                
                if let rating = viewmodel.modelproduct?.averageRating {
                    cell.btnrating.setTitle("\(rating)", for: .normal)

                }
    //                    let attributed = NSMutableAttributedString(string: " \(rating)", attributes: [
    //                        .font: UIFont(name: ConstantFontSize.Bold, size: 15),.foregroundColor: UIColor.black
    //                    ])
    //                    let boldText = NSAttributedString(string: " ratings ", attributes: [
    //                        .font: UIFont(name: ConstantFontSize.regular, size: 14),
    //                        .foregroundColor: UIColor.lightGray
    //                    ])
    //                    attributed.append(boldText)
    //                    cell.lblRating.attributedText = attributed
    //                }
                    if let review = viewmodel.modelproduct?.reviewCount {
                        
                        let attributed1 = NSMutableAttributedString(string: " \(review)", attributes: [
                            .font: UIFont(name: ConstantFontSize.Bold, size: 15),.foregroundColor: UIColor.black
                        ])
                        let boldText1 = NSAttributedString(string: "  review ", attributes: [
                            .font: UIFont(name: ConstantFontSize.regular, size: 14),
                            .foregroundColor: UIColor.lightGray
                        ])
                        attributed1.append(boldText1)
                        cell.lblReview.attributedText = attributed1
                    }
                    cell.arrColor = viewmodel.modelproduct?.colors ?? []
                    cell.arrSize  = viewmodel.modelproduct?.variantsColor?[0].sizes ?? []
                    cell.couponarr  = viewmodel.couponarr
                    cell.onCollectionItemTag1Color = { [weak self] arr in
                        print(arr)
                       // self?.btnline.isHidden = false
                     //   self?.viewheader.backgroundColor = .clear
                            self?.colorName =  arr.value ?? ""
                            self?.viewmodel.modelproduct?.variantsColor?[0].sizes = arr.sizes
                            self?.viewmodel.modelproduct?.variants?[0].images     = arr.sizes?[0].images
                            self?.viewmodel.modelproduct?.variants?[0].price      = arr.sizes?[0].price
                        self?.sharedValientID = self?.viewmodel.modelproduct?.variantsColor?[0].sizes?[0].variantId ?? ""

                            self?.collectionView.reloadData()
                           // self?.tableView.reloadData()
                    }
                    
                    cell.onCollectionItemcolorSize = { [weak self] indevalue, sizeArr in
                        
                      //  self?.btnline.isHidden = false
                       // self?.viewheader.backgroundColor = .clear

                        self?.viewmodel.modelproduct?.variantsColor?[0].sizes = sizeArr
                        self?.viewmodel.modelproduct?.variants?[0].price      = sizeArr[indevalue].price
                        self?.collectionView.reloadData()
                       // self?.tableView.reloadData()
                    }
                    cell.initalSetup()
                    return cell
     
        } else if objMain == "DETAILS" {
            // Header Cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMProductTitleCell", for: indexPath) as! LMProductTitleCell
            
            cell.lblTitle.text = arrCotegory[indexPath.row]
            if arrCotegory.contains("SUBDETAILS") {
                cell.lblTitle.textAlignment = .center
                cell.lblPlus.text =  " - "

            } else {
                cell.lblTitle.text =  "  " + arrCotegory[indexPath.row]
                cell.lblPlus.text =  " + "
                cell.lblTitle.textAlignment = .left
            }

             return cell
           
        } else if objMain == "SUBDETAILS" {
            
            
            guard let cell = collectionView.dequeueReusableCell(
                    withReuseIdentifier: "DetailHTMLcell1",
                    for: indexPath
                ) as? DetailHTMLcell1 else {
                    // Fallback: return a basic cell or crash gracefully in development
                    return UICollectionViewCell()
                }

                // Configure your cell here safely
//                cell.configure(with: yourModelData)
//
//                return cell
            
            
            cell.dataLoad(str: viewmodel.modelproduct?.description ?? "")

            
            
//            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DetailHTMLcell1", for: indexPath) as? DetailHTMLcell1 else {
//                   fatalError("Could not dequeue DetailHTMLcell1")
//               }

//               let htmlString = viewmodel.modelproduct?.formatedDescription ?? ""
//               let fullHTML = wrapHTMLContent(htmlString)
//
//               if let attributed = htmlToAttributedString(fullHTML) {
//                   cell.txtViewDesc.attributedText = attributed
//               }

               return cell // ✅ This is mandatory
        } else if objMain == "OFFERS" {
            // Header Cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMProductTitleCell", for: indexPath) as! LMProductTitleCell
            cell.lblTitle.text = arrCotegory[indexPath.row]
            if arrCotegory.contains("SUBOFFERS") {
                cell.lblTitle.textAlignment = .center
                cell.lblPlus.text =  " - "

            } else {
                cell.lblTitle.text =  "  " + arrCotegory[indexPath.row]
                cell.lblPlus.text =  " + "
                cell.lblTitle.textAlignment = .left
            }
            

             return cell
        } else if objMain == "SUBOFFERS" {

            
            // Header Cell
        //Retview
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMOfferCouponCell", for: indexPath) as! LMOfferCouponCell
                //cell.selectionStyle = .none

                if viewmodel.modelCoupon?.results.count != 0 {
                    let model = viewmodel.modelCoupon?.results[0]
                    cell.lblcouponTtile.text = model?.title
                    cell.lblCouponCode.text =  "CODE: " + (model?.code ?? "")
                    
                    if (viewmodel.modelCoupon?.results.count ?? 0) >= 2 {
                        let model1 = viewmodel.modelCoupon?.results[1]
                        cell.lblcoupon2.text = model1?.title
                        cell.lblCouponCode2.text =  "CODE: " + (model1?.code ?? "")
                    } else {
                        cell.img1.isHidden = true
                    }
                } else {
                    cell.lblCouponCode.text =  " No active offer"
                    cell.img1.isHidden = true
                    cell.img2.isHidden = true
                }
                return cell

      
//        } else if objMain == "SUBOFFERS" {
//            // Header Cell
//            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMProductTitleCell", for: indexPath) as! LMProductTitleCell
//            cell.lblTitle.text = arrCotegory[indexPath.row]
//
//             return cell
        } else if objMain == "REVIEWS" {
            // Header Cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMProductTitleCell", for: indexPath) as! LMProductTitleCell
            cell.lblTitle.text = arrCotegory[indexPath.row]
            if arrCotegory.contains("SUBREVIEWS1") {
                cell.lblTitle.textAlignment = .center
                cell.lblPlus.text =  " - "

            } else {
                cell.lblTitle.text =  "  " + arrCotegory[indexPath.row]
                cell.lblPlus.text =  " + "
                cell.lblTitle.textAlignment = .left
            }

             return cell
        
        } else if objMain == "SUBREVIEWS1" {
            // Header Cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMcellReviewRating", for: indexPath) as! LMcellReviewRating
            
            
//            cell.starView.rating = 3.5
//                   starView.ratingCount = 50
//                   // get current rating
//                   let currentRating = starView.rating
//            
            if let rating = viewmodel.modelproduct?.averageRating {
                cell.lblRating.text = "\(rating) "
                cell.starView1.rating = rating
                cell.starView1.ratingCount = Int(rating)

            }
            
           
             return cell
        } else if objMain == "SUBREVIEWS2" {
            // Header Cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMcellReviewimages", for: indexPath) as! LMcellReviewimages
            cell.customerImages = viewmodel.customerImages
            cell.initalCollectionCall()
            //cell.lblTitle.text = arrCotegory[indexPath.row]
            
            return cell
        } else if objMain == "SUBREVIEWS3" {
            // Header Cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMcellReviewProduct", for: indexPath) as! LMcellReviewProduct
            
            cell.onCollectionViewMore = { [weak self] indevalue in
               // self.viewheader.backgroundColor = .clear

                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let secondVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMReviewRateListVC) as! LMReviewRateListVC
                secondVC.productId      = self?.productId ?? ""
                self?.navigationController?.pushViewController(secondVC, animated: true)
            }

            if viewmodel.modelReview.count != 0 {
                let obj = viewmodel.modelReview[0]
                cell.images = obj.images
                cell.initalCollectionCall()

                cell.lblTitle.text  = obj.userName
                cell.lblDis.text = obj.comment
                if let rating = obj.rating {
                    cell.lblRating.text = " \(rating) ☆"
                }
            }
                // cell.lblTitle.text = arrCotegory[indexPath.row]

             return cell
//        } else if objMain == "SUBREVIEWS4" {
//            // Header Cell
//            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMcellReviewProduct1", for: indexPath) as! LMcellReviewProduct1
//
////            if viewmodel.modelReview.count != 0 {
////                if viewmodel.modelReview.count >= 2 {
////                    let obj = viewmodel.modelReview[1]
////                    cell.images = obj.images
////                   // cell.initalCollectionCall()
////
////                    cell.lblTitle.text  = obj.userName
////                    cell.lblDis.text = obj.comment
////                    if let rating = obj.rating {
////                        cell.lblRating.text = " \(rating) ☆"
////                    }
////                }
////                // cell.lblTitle.text = arrCotegory[indexPath.row]
////            }
//             return cell
        } else if objMain == "DELIVERY" {
            // Header Cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMProductTitleCell", for: indexPath) as! LMProductTitleCell
            
            cell.lblTitle.text = arrCotegory[indexPath.row]
            if arrCotegory.contains("DELIVERYDetail") {
                cell.lblTitle.textAlignment = .center
                cell.lblPlus.text =  " - "

            } else {
                cell.lblTitle.text =  "  " + arrCotegory[indexPath.row]
                cell.lblPlus.text =  " + "
                cell.lblTitle.textAlignment = .left
            }

             return cell
        } else if objMain == "DELIVERYDetail" {

            
            //returm
              //  let cell = tableView.dequeueReusableCell(withIdentifier: "DevliaryCell", for: indexPath) as! DevliaryCell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DevliaryCell1", for: indexPath) as! DevliaryCell1

            //    cell.selectionStyle = .none
                if THUserDefaultValue.isUserPincodeLoging  == true {
                    cell.view24.isHidden      = false
                    cell.imgTraqck.isHidden   = false
                    cell.viewDelivery.isHidden = true

                    let dateformate = THUserDefaultValue.userdatefrmate ?? ""

                   // let threeDaysAgo = dateThreeDaysAgo()
                    let formatted = addThreeDays(to: dateformate)
                    
                    
                   // (to: dateformate)

                    let pincode = THUserDefaultValue.isUserPincode ?? ""
                    if pincode == "" {
                        
                    } else {
                        
                    }
                    let StrEstimate1 = formatted.components(separatedBy: ",").first ?? ""

                    let fullText = "Delivery to \(pincode) by \(StrEstimate1)"
                    let attributedText = NSMutableAttributedString(string: fullText)

                    if let range = fullText.range(of: pincode) {
                        let nsRange = NSRange(range, in: fullText)
                        attributedText.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: nsRange)
                        // Optional: also bold it or change color
                        attributedText.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 14), range: nsRange)
                    }

                    cell.lblPincode.attributedText = attributedText
                    
                    cell.btnDelivery.addTarget(self, action: #selector(openPincodeController), for: .touchUpInside)

                    
                    //cell.btnDelivery.setTitle("Delivery to \(THUserDefaultValue.isUserPincode ?? "")", for: .normal)
                } else {
                    cell.view24.isHidden      = true
                    cell.imgTraqck.isHidden   = true
                    cell.viewDelivery.isHidden = false
                    

                }
                
                return cell
        
        } else if objMain == "RETURN" {
            // Header Cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMProductTitleCell", for: indexPath) as! LMProductTitleCell
            
            // let  arrCotegory = ["All", "Shirts", "DETAILS","SUBDETAILS", "OFFERS","SUBOFFERS","REVIEWS","SUBREVIEWS1","SUBREVIEWS2","SUBREVIEWS3","DELIVERY","DELIVERYDetail", "RETURN","RETURNDetail"]
            cell.lblTitle.text = arrCotegory[indexPath.row]
            if arrCotegory.contains("RETURNDetail") {
                cell.lblTitle.textAlignment = .center
                cell.lblPlus.text =  " - "

            } else {
                cell.lblTitle.text =  "  " + arrCotegory[indexPath.row]
                cell.lblPlus.text =  " + "
                cell.lblTitle.textAlignment = .left
            }
            
            
            return cell
        } else if objMain == "RETURNDetail" {
            // Header Cell

            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DetailHTMLcell2", for: indexPath) as? DetailHTMLcell2 else {
                   fatalError("Could not dequeue DetailHTMLcell1")
               }

           // cell.selectionStyle = .none
            showRefundPolicy(in: cell.txtViewDesc)
            return cell

        }
            
            
         //   let  arrCotegory = ["All", "Shirts", "DETAILS","SUBDETAILS", "OFFERS","SUBOFFERS","REVIEWS","SUBREVIEWS1","SUBREVIEWS2","SUBREVIEWS3","DELIVERY", "RETURN", "YOU MAY ALSO LIK"]
            } else {
                let subcategoryIndex = indexPath.row
               // let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMSmilarProductCell", for: indexPath) as! LMSmilarProductCell
                //                if viewmodel.modelproduct?.similarProducts?.count != nil ||  viewmodel.modelproduct?.similarProducts?.count != 0  {
                //                    cell.productsdetail = viewmodel.modelproduct?.similarProducts ?? []
                //                    cell.initSet()
                //
                //                    cell.onproductItemTapLike = { [weak self] collectionIndexPath, variantId , color in
                //                        print(collectionIndexPath)
                //                        self?.viewmodel.callWishListAPI(productId: collectionIndexPath, strColor: color, strVaiantId:variantId)
                //
                //                    }
                //
                //                    cell.onproductItemTap1 = { [weak self] collectionIndexPath, variantId in
                //                        print(collectionIndexPath)
                //                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                //                        let secondVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMProductDetVC) as! LMProductDetVC
                //                        secondVC.productId        = collectionIndexPath
                //                        secondVC.defaultVaniantID = variantId
                //                        self?.navigationController?.pushViewController(secondVC, animated: true)
                //                    }
                //                }
                
                    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductDetailCell", for: indexPath) as! ProductDetailCell
                let objModel = viewmodel.modelproduct?.similarProducts?[indexPath.row]
                    cell.imgProduct.sd_setImage(with: URL(string: objModel?.variantThumbnail?.image ?? ""))
                cell.lblProductName.text = objModel?.title
                    cell.lblProductName.font = UIFont(name: "HeroNew-Regular", size: 15)
                    cell.lblProductPrice.text = keyName.rupessymbol + " \(objModel?.lowestSellingPrice ?? 0.0)"
                    
                
//                cell.onproductItemTapLike = { [weak self] collectionIndexPath, variantId , color in
//                    print(collectionIndexPath)
//                    self?.viewmodel.callWishListAPI(productId: collectionIndexPath, strColor: color, strVaiantId:variantId)
//
//                }

                    cell.btnFavorite.addTarget(self, action: #selector(LMProductMainDetVC.likeaction(_:)), for: .touchUpInside)
                    
            //        let svgImage:SVGKImage = SVGKImage(named: "ic_heart_empty")
            //        cell.imgLike.image = svgImage.uiImage
                    if objModel?.isWishlisted == true {
                        cell.imgLike.image = SVGKImage(named: "ic_heart_fill")?.uiImage
                    } else {
                        cell.imgLike.image = SVGKImage(named: "ic_heart_empty")?.uiImage
                    }
                    
                    cell.btnFavorite.tag = indexPath.row
                
                
                cell.lblrateandReview.layer.cornerRadius = 10
                cell.lblrateandReview.layer.masksToBounds = true
                cell.lblrateandReview.layer.borderWidth = 0.5
                cell.lblrateandReview.layer.borderColor = UIColor.lightGray.cgColor
                cell.lblrateandReview.backgroundColor = UIColor.systemGray6
                cell.lblrateandReview.isHidden = true
                cell.viewraview.isHidden = true

                if objModel?.averageRating != 0 && objModel?.reviewCount != 0 {
                    
                    if let rating = objModel?.averageRating {
                        cell.lblrateandReview.isHidden = false
                        let formattedRating = rating.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(rating)) : String(rating)
                        if let reviewCount = objModel?.reviewCount {
                            let formattedRating1 = reviewCount.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(reviewCount)) : String(reviewCount)

                            //cell.lblreview.text = "\(formattedRating) "
                            cell.lblrateandReview.text = "     \(formattedRating)  ☆  |  \(formattedRating1)     "
                        } else {
                            cell.lblrateandReview.text = "     \(formattedRating)  ☆     "
                        }
                    } else {
                        cell.lblrateandReview.isHidden = false
                    }
                }
                
                


                    if objModel?.discountType == "flat" {
                        let discount = Int(objModel?.lowestMRP ?? 0) - Int(objModel?.lowestSellingPrice ?? 0)

                        if discount != 0 {
                            cell.lblDiscountPrice.text = "  ₹ \(discount) OFF!"
                            cell.imgBackground.image = UIImage(named: "red")
                        } else {
                           cell.lblDiscountPrice.isHidden = true
                           cell.imgBackground.isHidden = true
                        }
     
//                        let discount = Int(objModel?.lowestMRP ?? 0) - Int(objModel?.lowestSellingPrice ?? 0)
//                        
//                        
//                            cell.lblDiscountPrice.text = "  ₹ \(discount) OFF!"
//                        cell.imgBackground.image = UIImage(named: "red")
                    } else {
                        cell.imgBackground.image = UIImage(named: "green")
                        
                        
                        if let finalDiscountPercent1 = objModel?.finalDiscountPercent {
                            if finalDiscountPercent1 != 0 {
                                let formatted = String(format: "%.0f", finalDiscountPercent1)  // "10"
                                cell.lblDiscountPrice.text = "  ₹ \(formatted) % OFF!"
                                //cell.lblDiscountPrice.textColor = .white

                            } else {
                               cell.lblDiscountPrice.isHidden = true
                               cell.imgBackground.isHidden = true
                            }
                            
                        }
                        
//                        if let finalDiscountPercent1 = objModel?.finalDiscountPercent {
//                            let formatted = String(format: "%.0f", finalDiscountPercent1)  // "10"
//                            cell.lblDiscountPrice.text = "  ₹ \(formatted) % OFF!"
//                        }
                    }
                    
                    
                
                
                
                
                
                
                
                cell.lblCount.isHidden = true

                if let colorcode = objModel?.colorPreview?.count {
                        if 3 < colorcode {
                            cell.lblCount.isHidden = false
                            if let countlavbel = objModel?.totalColorCount {
                                cell.lblCount.text = "+ \((countlavbel - 3))"
                            }
                        }
                        if colorcode == 1 {
                            let uiColor = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? "")
                            if let lowercaseString = objModel?.colorPreview?[0].lowercased() {
                                if lowercaseString == "white" {
                                    cell.lbl1.layer.borderColor = UIColor.black.cgColor
                                    cell.lbl1.layer.borderWidth = 1
                                }
                            }
                            cell.lbl1.backgroundColor = uiColor
                            cell.lbl2.isHidden = true
                            cell.lbl3.isHidden = true

                        } else if colorcode == 2 {
                            let uiColor  = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? "")
                            let uiColor1 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[1] ?? "")
                            if let lowercaseString = objModel?.colorPreview?[0].lowercased() {
                                if lowercaseString == "white" {
                                    cell.lbl1.layer.borderColor = UIColor.black.cgColor
                                    cell.lbl1.layer.borderWidth = 1
                                }
                            }
                            if let lowercaseString = objModel?.colorPreview?[1].lowercased() {
                                if lowercaseString == "white" {
                                    cell.lbl2.layer.borderColor = UIColor.black.cgColor
                                    cell.lbl2.layer.borderWidth = 1
                                }
                            }
                            cell.lbl1.backgroundColor = uiColor
                            cell.lbl2.backgroundColor = uiColor1
                            cell.lbl3.isHidden = true
                        } else {
                            let uiColor  = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? "")
                            let uiColor1 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[1] ?? "")
                            let uiColor2 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[2] ?? "")
                            
                            if let lowercaseString = objModel?.colorPreview?[0].lowercased() {
                                if lowercaseString == "white" {
                                    cell.lbl1.layer.borderColor = UIColor.black.cgColor
                                    cell.lbl1.layer.borderWidth = 1
                                }
                            }
                            if let lowercaseString = objModel?.colorPreview?[1].lowercased() {
                                if lowercaseString == "white" {
                                    cell.lbl2.layer.borderColor = UIColor.black.cgColor
                                    cell.lbl2.layer.borderWidth = 1
                                }
                            }
                            if let lowercaseString = objModel?.colorPreview?[2].lowercased() {
                                if lowercaseString == "white" {
                                    cell.lbl3.layer.borderColor = UIColor.black.cgColor
                                    cell.lbl3.layer.borderWidth = 1
                                }
                            }
                            
                            cell.lbl1.backgroundColor = uiColor
                            cell.lbl2.backgroundColor = uiColor1
                            cell.lbl3.backgroundColor = uiColor2
                        }
                    }
                    
                    return cell
                

            }
        

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMcellShopCell", for: indexPath) as! LMcellShopCell

        return cell
    }
    
    func didTapSimilar(modelproduct: ProductDataDetail) {
        print("Selected product: ")
        
        // Example: open product detail screen
        // let detailVC = ProductDetailViewController()
        // detailVC.productData = modelproduct
        // navigationController?.pushViewController(detailVC, animated: true)
    }
//    func  didTapSimilar(modeldetail:LMSimilarVC) {
//    print(modeldetail)
//                let vc = LMSimilarVC()
//                vc.modalPresentationStyle = .overFullScreen
//                vc.modalTransitionStyle = .crossDissolve  // Smooth fade animation
//                self.present(vc, animated: true, completion: nil)
//        
//    }
    @objc func likeaction(_ sender : UIButton) {
        let tag = sender.tag
        var objModel = viewmodel.modelproduct?.similarProducts?[tag]
        //var objModel = productsdetail[tag]
        if objModel?.isWishlisted == nil {
            viewmodel.modelproduct?.similarProducts?[tag].isWishlisted = true

            objModel?.isWishlisted = true
        } else {
            if objModel?.isWishlisted == false {
                viewmodel.modelproduct?.similarProducts?[tag].isWishlisted = true

                objModel?.isWishlisted = true
            } else {
                viewmodel.modelproduct?.similarProducts?[tag].isWishlisted = false

                objModel?.isWishlisted = false
            }
        }
        collectionView.reloadData()
        self.viewmodel.callWishListAPI(productId: objModel?._id ?? "", strColor: objModel?.variantThumbnail?.variantId ?? "", strVaiantId:objModel?.variantThumbnail?.variantId ?? "")
      //  onproductItemTapLike?(objModel._id ?? "", objModel.variantThumbnail?.variantId ?? "", objModel.variantThumbnail?.color ?? "")

    }
    func toggleSubItems(at index: Int, isExpanded: inout Bool, subItems: [String]) {
        if isExpanded {
            // Collapse
            for sub in subItems.reversed() {
                if let idx = arrCotegory.firstIndex(of: sub) {
                    arrCotegory.remove(at: idx)
                }
            }
        } else {
            // Expand
            arrCotegory.insert(contentsOf: subItems, at: index + 1)
        }
        isExpanded.toggle()
        collectionView.reloadData()

    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        if indexPath.section == 1 {
            
            let obj = viewmodel.modelproduct?.similarProducts?[indexPath.row]
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let secondVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMProductMainDetVC) as! LMProductMainDetVC
            secondVC.productId        = obj?._id ?? ""
            secondVC.defaultVaniantID = obj?.variantThumbnail?.variantId ?? ""
            self.navigationController?.pushViewController(secondVC, animated: true)
        } else {
            let tappedItem = arrCotegory[indexPath.item]
            switch tappedItem {
            case "DETAILS":
                toggleSubItems(at: indexPath.item, isExpanded: &isDetailsExpanded, subItems: subDetails)

//            case "OFFERS":
//                toggleSubItems(at: indexPath.item, isExpanded: &isOffersExpanded, subItems: subOffers)

            case "REVIEWS":
                if viewmodel.customerImages.count != 0 {
                    
                    if viewmodel.modelReview.count != 0 {
                        if viewmodel.modelReview.count == 1{
                            toggleSubItems(at: indexPath.item, isExpanded: &isReviewsExpanded, subItems: subReviews3)
                        } else {
                            toggleSubItems(at: indexPath.item, isExpanded: &isReviewsExpanded, subItems: subReviews4)
                        }
                    } else {
                        toggleSubItems(at: indexPath.item, isExpanded: &isReviewsExpanded, subItems: subReviews1)
                    }
                } else {
                    if viewmodel.modelReview.count != 0 {
                        if viewmodel.modelReview.count == 1{
                            toggleSubItems(at: indexPath.item, isExpanded: &isReviewsExpanded, subItems: subReviews3)
                        } else {
                            toggleSubItems(at: indexPath.item, isExpanded: &isReviewsExpanded, subItems: subReviews4)
                        }
                    } else {
                        toggleSubItems(at: indexPath.item, isExpanded: &isReviewsExpanded, subItems: subReviews1)
                    }
                }
            case "DELIVERY":
                //toggleSubItems(at: indexPath.item, isExpanded: &isDeliveryExpanded, subItems: subDelivery)

                    
                    let pincode = THUserDefaultValue.isUserPincode ?? ""
                    if pincode == "" {
                        

                           // viewheader.isHidden = true
                            //btnline.isHidden = false
                           // self.viewheader.backgroundColor = .white
                          //  print("viewmodel.modelproduct?.dimensions==\(viewmodel.modelproduct?.dimensions)")
                            let deleteSheet = LMPincodeVC()
                            deleteSheet.dimensions11 = viewmodel.modelproduct?.dimensions
                            deleteSheet.widgthKM11   = viewmodel.modelproduct?.weightInKg ?? 0.0
                            deleteSheet.modalPresentationStyle = .overFullScreen
                            deleteSheet.modalTransitionStyle = .coverVertical
                            
                            deleteSheet.onApplyTapped = { [weak self] indevalue, sizeArr in
                                THUserDefaultValue.isUserPincodeLoging = true
                                print("User confirmed delete\(indevalue)\(sizeArr)")
                                THUserDefaultValue.isUserPincode   = indevalue
                                
                                self?.reloadCollectionView(indexpathValue:indexPath)
                             
                                                
                                self?.collectionView.reloadData()
                            }
                            present(deleteSheet, animated: true)

                    } else {

                        if THUserDefaultValue.isUserPincodeLoging == true {
                          //  sections[section].isExpanded.toggle()
                            toggleSubItems(at: indexPath.item, isExpanded: &isDeliveryExpanded, subItems: subDelivery)
                        } else {
                           // viewheader.isHidden = true
                            //btnline.isHidden = false
                           // self.viewheader.backgroundColor = .white
                            print("viewmodel.modelproduct?.dimensions==\(viewmodel.modelproduct?.dimensions)")
                            let deleteSheet = LMPincodeVC()
                            deleteSheet.dimensions11 = viewmodel.modelproduct?.dimensions
                            deleteSheet.widgthKM11   = viewmodel.modelproduct?.weightInKg ?? 0.0
                            deleteSheet.modalPresentationStyle = .overFullScreen
                            deleteSheet.modalTransitionStyle = .coverVertical
                            
                            deleteSheet.onApplyTapped = { [weak self] indevalue, sizeArr in
                                THUserDefaultValue.isUserPincodeLoging = true
                                print("User confirmed delete\(indevalue)\(sizeArr)")
                                THUserDefaultValue.isUserPincode   = indevalue
                                self?.reloadCollectionView(indexpathValue:indexPath)

    //                                self?.sections = [
    //                                Section(title: "", items: ["Apple"], isExpanded: true),
    //                                Section(title: "DETAILS ", items: ["Carrot"], isExpanded: false),
    //                                Section(title: "OFFERS  ", items: ["Carrot"], isExpanded: false),
    //                                Section(title: "REVIEWS  ", items: ["Carrot"], isExpanded: false),
    //                                Section(title: "DELIVERY ", items: ["Carrot"], isExpanded: true),
    //                                Section(title: "RETURN  ", items: ["Carrot"], isExpanded: false),
    //                                Section(title: "YOU MAY ALSO LIKE", items: ["Carrot"], isExpanded: true),
    //                            ]
                                
                                
                               
                                self?.collectionView.reloadData()
                            }
                            present(deleteSheet, animated: true)
                        }
                    }
                    
              
                
            case "RETURN":
                toggleSubItems(at: indexPath.item, isExpanded: &isReturnExpanded, subItems: subReturn)

                
                
           
            
            default:
                break
            }

            collectionView.reloadData()
        }
        
    
    }

    func reloadCollectionView(indexpathValue: IndexPath) {
        toggleSubItems(at: indexpathValue.item, isExpanded: &isDeliveryExpanded, subItems: subDelivery)
        collectionView.reloadData()

    }
        // MARK: - Header View

        func collectionView(_ collectionView: UICollectionView,
                            viewForSupplementaryElementOfKind kind: String,
                            at indexPath: IndexPath) -> UICollectionReusableView {
            if kind == UICollectionView.elementKindSectionHeader {
                if indexPath.section == 0 {
                    let header = collectionView.dequeueReusableSupplementaryView(
                        ofKind: kind,
                        withReuseIdentifier: "searchBarHeaderCv",
                        for: indexPath
                    ) as! searchBarHeaderCv
                    
                    header.initset()
                 
                    //header.backgroundColor = .green
                    //header.label.text = "Section Header"
                    return header
                } else {
                    let header = collectionView.dequeueReusableSupplementaryView(
                        ofKind: kind,
                        withReuseIdentifier: "searchBarHeader2",
                        for: indexPath
                    ) as! searchBarHeader2
                   
                    if indexPath.section == 1 {
                        header.lblHeaderTitle.text =  "YOU MAY ALSO LIKE"
                    } else {
                        header.lblHeaderTitle.text =  ""

                    }
                    header.lblHeaderTitle.font  =  UIFont(name: ConstantFontSize.regular, size: 16)

                    return header
                }
            }
            return UICollectionReusableView()
        }

        // MARK: - Layout

        func collectionView(_ collectionView: UICollectionView,
                            layout collectionViewLayout: UICollectionViewLayout,
                            sizeForItemAt indexPath: IndexPath) -> CGSize {
            if indexPath.section == 0 {
                
                let objMain = arrCotegory[indexPath.row]
                if objMain == "All" {
                    return CGSize(width: (view.frame.width), height: 640)
                } else if objMain == "Shirts" {
                    if viewmodel.couponarr.count != 0 {
                        return CGSize(width: (view.frame.width), height: 620)
                    } else {
                        return CGSize(width: (view.frame.width), height: 420)
                    }
                } else if objMain == "DETAILS" {
                    return CGSize(width: (view.frame.width), height: 58)
                    
                } else if objMain == "SUBDETAILS" {
                    let htmlString = viewmodel.modelproduct?.description ?? keyName.emptyStr
                    let textHeight = htmlString.height(withConstrainedWidth: collectionView.frame.width - 40, font: UIFont(name: ConstantFontSize.regular, size: 16)!)
                      //  return textHeight + 450
                    return CGSize(width: (view.frame.width), height: (textHeight + 450))

                } else if objMain == "OFFERS" {
                    return CGSize(width: (view.frame.width), height: 58)
                    
                } else if objMain == "SUBOFFERS" {
                    if viewmodel.modelCoupon?.results.count != 0 {
                        if viewmodel.modelCoupon?.results.count == 1 {
                            return CGSize(width: (view.frame.width), height: 70)
                        } else if viewmodel.modelCoupon?.results.count == 2 {
                            return CGSize(width: (view.frame.width), height: 130)
                        } else {
                            return CGSize(width: (view.frame.width), height: 130)
                        }
                        return CGSize(width: (view.frame.width), height: 130)
                    }
                } else if objMain == "REVIEWS" {
                    return CGSize(width: (view.frame.width), height: 58)
                    
                } else if objMain == "SUBREVIEWS1" {
                        return CGSize(width: (view.frame.width), height: 80)
                    
                } else if objMain == "SUBREVIEWS2" {
                    
                    if viewmodel.customerImages.count != 0 {
                        return CGSize(width: (view.frame.width), height: 150)
                    } else {
                        return CGSize(width: (view.frame.width), height: 0)
                    }

                } else if objMain == "SUBREVIEWS3" {
                    
                    if viewmodel.modelReview.count != 0 {
                        if viewmodel.modelReview.count >= 1{
                            let obj = viewmodel.modelReview[0]
                            if obj.images?.count != 0 {
                                return CGSize(width: (view.frame.width), height: 260)
                            } else {
                                return CGSize(width: (view.frame.width), height: 180)
                            }
                        }
                    } else {
                        return CGSize(width: (view.frame.width), height: 0)
                    }
                    return CGSize(width: (view.frame.width), height: 185)

                } else if objMain == "DELIVERY" {
                    return CGSize(width: (view.frame.width), height: 58)
                } else if objMain == "DELIVERYDetail" {
                    return CGSize(width: (view.frame.width), height: 90)

                } else if objMain == "RETURN" {
                    return CGSize(width: (view.frame.width), height: 58)
                
                 } else if objMain == "RETURNDetail" {
                   return CGSize(width: (view.frame.width), height: 320)
                 
                } else if objMain == "" {
                 return CGSize(width: (view.frame.width), height: 58)
                } else {
                    return CGSize(width: (view.frame.width), height: 400)

                }
                //       let  arrCotegory = ["All", "Shirts", "DETAILS","SUBDETAILS", "OFFERS","SUBOFFERS","REVIEWS","SUBREVIEWS1","SUBYOU MAY ALSO LIKEREVIEWS2","SUBREVIEWS3","DELIVERY","DELIVERYDetail", "RETURN","RETURNDetail", "YOU MAY ALSO LIK","YouDetail"]

                
                return CGSize(width: (view.frame.width), height: 58)

                
            }
            let width  = (collectionView.frame.width-10)/2
            return CGSize(width: width, height: 400)
//            return CGSize(width: (view.frame.width), height: 400)

        }

        func collectionView(_ collectionView: UICollectionView,
                            layout collectionViewLayout: UICollectionViewLayout,
                            referenceSizeForHeaderInSection section: Int) -> CGSize {
            if section == 0 {
                return CGSize(width: collectionView.bounds.width, height: 0) // Adjust height as needed
            } else if section == 1{
                return CGSize(width: collectionView.bounds.width, height: 60) // Adjust height as needed
           
            } else {
                return CGSize(width: collectionView.bounds.width, height: 0) // Adjust height as needed
            }
        }
        
//        func collectionView(_ collectionView: UICollectionView,
//                            layout collectionViewLayout: UICollectionViewLayout,
//                            insetForSectionAt section: Int) -> UIEdgeInsets {
//            return UIEdgeInsets(top: 0, left: -1, bottom: 0, right: -1)
//        }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
        func collectionView(_ collectionView: UICollectionView,
                            layout collectionViewLayout: UICollectionViewLayout,
                            minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return 0
        }

        func collectionView(_ collectionView: UICollectionView,
                            layout collectionViewLayout: UICollectionViewLayout,
                            minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return 0
        }
    // Called whenever the collection view scrolls
//    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//        let offsetY = scrollView.contentOffset.y
//
//        // Wider range = slower fade
//        let fadeStart: CGFloat = 0
//        let fadeEnd: CGFloat = 200
//
//        // Calculate alpha smoothly between 1 and 0
//        let alpha = max(0, min(1, 1 - (offsetY - fadeStart) / (fadeEnd - fadeStart)))
//        viewHeaderMain.alpha = alpha
//    }
    private var lastContentOffset: CGFloat = 0


    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        //print ("offsetYoffsetY == \(offsetY)")
        // When scrolled more than 200 points, hide header
        if offsetY > 200 {
            if self.viewHeaderMain.alpha != 1 {
                UIView.animate(withDuration: 0.3) {
                    self.viewHeaderMain.alpha = 1
                }
            }
            
        } else {
            // When back to top area, show header again
            if self.viewHeaderMain.alpha != 0 {
                UIView.animate(withDuration: 0.3) {
                    self.viewHeaderMain.alpha = 0
                }
            }
        }
    }



    @objc func openPincodeController() {
       // viewheader.isHidden = true
      //  btnline.isHidden = false
      //  self.viewheader.backgroundColor = .white

        print("viewmodel.modelproduct?.dimensions==\(viewmodel.modelproduct?.dimensions)")
        let deleteSheet = LMPincodeVC()
        deleteSheet.dimensions11 = viewmodel.modelproduct?.dimensions
        deleteSheet.widgthKM11  = viewmodel.modelproduct?.weightInKg ?? 0.0
        deleteSheet.modalPresentationStyle = .overFullScreen
        deleteSheet.modalTransitionStyle = .coverVertical
        deleteSheet.onApplyTapped = { [weak self] indevalue, sizeArr in
            //print("User confirmed delete\(indevalue)\(sizeArr)")
            THUserDefaultValue.isUserPincode   = indevalue
            self?.collectionView.reloadData()
        }
        present(deleteSheet, animated: true)

    }
    func createPriceAttributedTextWithout(discountPercent: Int, originalPrice: Double, discountedPrice: Double) -> NSAttributedString {
        let attributedText = NSMutableAttributedString()

        // Discount arrow + percentage
//        let discountString = "↓ \(discountPercent)% "
//        let discountAttributes: [NSAttributedString.Key: Any] = [
//            .foregroundColor: UIColor.systemGreen,
//            .font: UIFont(name: ConstantFontSize.regular, size: 13)
//        ]
//        attributedText.append(NSAttributedString(string: discountString, attributes: discountAttributes))

        // Original price with strikethrough
//        let originalPriceString = "₹\(Int(originalPrice))"
//        let originalPriceAttributes: [NSAttributedString.Key: Any] = [
//            .strikethroughStyle: NSUnderlineStyle.single.rawValue,
//            .foregroundColor: UIColor.gray,
//            .font: UIFont(name: ConstantFontSize.regular, size: 14)
//        ]
//        attributedText.append(NSAttributedString(string: originalPriceString, attributes: originalPriceAttributes))

        // Discounted price
        let discountedPriceString = " ₹\(Int(discountedPrice))"
        let discountedPriceAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.black,
            .font: UIFont(name: ConstantFontSize.Semibold, size: 14)
        ]
        attributedText.append(NSAttributedString(string: discountedPriceString, attributes: discountedPriceAttributes))

        return attributedText
    }
    func createPriceAttributedText(discountPercent: Int, originalPrice: Double, discountedPrice: Double) -> NSAttributedString {
        let attributedText = NSMutableAttributedString()

        // Discount arrow + percentage
//        let discountString = "↓ \(discountPercent)% "
//        let discountAttributes: [NSAttributedString.Key: Any] = [
//            .foregroundColor: UIColor.systemGreen,
//            .font: UIFont(name: ConstantFontSize.regular, size: 13)
//        ]
//        attributedText.append(NSAttributedString(string: discountString, attributes: discountAttributes))

        // Original price with strikethrough
        let originalPriceString = "₹\(Int(originalPrice))"
        let originalPriceAttributes: [NSAttributedString.Key: Any] = [
            .strikethroughStyle: NSUnderlineStyle.single.rawValue,
            .foregroundColor: UIColor.gray,
            .font: UIFont(name: ConstantFontSize.regular, size: 14)
        ]
        attributedText.append(NSAttributedString(string: originalPriceString, attributes: originalPriceAttributes))

        // Discounted price
        let discountedPriceString = " ₹\(Int(discountedPrice))"
        let discountedPriceAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.black,
            .font: UIFont(name: ConstantFontSize.Semibold, size: 14)
        ]
        attributedText.append(NSAttributedString(string: discountedPriceString, attributes: discountedPriceAttributes))

        return attributedText
    }

    ///Action
    @objc func backButtonTapped() {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        if let chartVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMChartVC) as? LMChartVC {
//            chartVC.sizeChartUrl = sizeChartUrl ?? ""
//            chartVC.modalPresentationStyle = .overFullScreen
//            chartVC.modalTransitionStyle = .crossDissolve
//            self.present(chartVC, animated: true, completion: nil)
//
//
 
        let fullVC = LMFullImageVC()
        fullVC.imgUrl = sizeChartUrl ?? ""
        fullVC.modalPresentationStyle = .fullScreen
        fullVC.modalPresentationStyle = .overFullScreen
        fullVC.modalTransitionStyle = .crossDissolve
        present(fullVC, animated: true, completion: nil)
        
    
    }
    @objc func sharedImage() {
      //  self.viewheader.backgroundColor = .white

        shareContent(from: self)
    }
    func shareContent(from viewController: UIViewController) {
        // Content to share
        let text = "Check out Loom Fashion!"
       // let url = URL(string: "https://www.loomfashion.co.in/product/\(productId)?variantId=\(sharedValientID)")!
        
        
        guard let url = URL(string: "https://www.loomfashion.co.in/product/\(productId)?variantId=\(sharedValientID)") else {
                print("Invalid URL")
                return
            }

            let activityVC = UIActivityViewController(activityItems: [url], applicationActivities: nil)

            if let popover = activityVC.popoverPresentationController {
                popover.sourceView = viewController.view
                popover.sourceRect = CGRect(x: viewController.view.bounds.midX,
                                            y: viewController.view.bounds.midY,
                                            width: 0, height: 0)
                popover.permittedArrowDirections = []
            }

            viewController.present(activityVC, animated: true)
        
        
        
        
        
        
        
        
        
//        let image = UIImage(named: "loomupdated") // Optional image from assets
//        var itemsToShare: [Any] = [text, url]
//        if let image = image {
//            itemsToShare.append(image)
//        }
//
//        // Initialize activity view controller
//        let activityVC = UIActivityViewController(activityItems: itemsToShare, applicationActivities: nil)
//        
//        // For iPads (required to prevent crash)
//        if let popoverController = activityVC.popoverPresentationController {
//            popoverController.sourceView = viewController.view
//            popoverController.sourceRect = CGRect(x: viewController.view.bounds.midX,
//                                                  y: viewController.view.bounds.midY,
//                                                  width: 0, height: 0)
//            popoverController.permittedArrowDirections = []
//        }
//
//        // Present share sheet
//        viewController.present(activityVC, animated: true, completion: nil)
    }
    func addThreeDays(to inputDateString: String) -> String {
        let formatter = DateFormatter()
        //formatter.locale = Locale(identifier: "en_US_POSIX")
        //formatter.locale = Locale(identifier: "en_IN") // ✅ Indian locale

        formatter.dateFormat = "MMM dd, yyyy"  // Matches: "Jun 20, 2025"

        let formatter1 = DateFormatter()
        formatter1.dateFormat = "MMM dd, yyyy"
        let currentDateString = formatter1.string(from: Date())
        
        
        
        guard let date = formatter.date(from: currentDateString) else {
            print("❌ Invalid input date string: \(inputDateString)")
            return ""
        }

        if let savedDays = Int(THUserDefaultValue.userdateDays ?? "") {
            
            if savedDays >= 5 {
                
                if let newDate = Calendar.current.date(byAdding: .day, value: (savedDays - 2), to: date) {
                    return formatter.string(from: newDate)
                }
                // ✅ savedDays is greater than or equal to currentDays
            } else {
                guard let date = formatter.date(from: inputDateString) else {
                    print("❌ Invalid input date string: \(inputDateString)")
                    return ""
                }
                
                if let newDate = Calendar.current.date(byAdding: .day, value: 0, to: date) {
                    return formatter.string(from: newDate)
                }
                // ❌ savedDays is less than currentDays
            }

        }
        
        
     
        return ""
    }
    private func wrapHTMLContent(_ bodyHTML: String) -> String {
        return """
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: HeroNew-Regular; font-size: 15px; color: #000; }
            p { margin: 10px 0; }
            strong { font-weight: bold; display: block; margin-top: 12px; }
        </style>
        </head>
        <body>
        \(bodyHTML)
        </body>
        </html>
        """
    }
    func showRefundPolicy(in textView: UITextView) {
        let htmlString = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
              padding: 16px;
              color: #333;
              line-height: 1.6;
            }
            h2 {
              color: #000;
              font-size: 20px;
              margin-top: 24px;
            }
            h3 {
              color: #444;
              font-size: 17px;
              margin-top: 20px;
            }
            ul {
              padding-left: 20px;
              margin: 8px 0;
            }
            li {
              margin-bottom: 6px;
            }
            .note {
              color: #d32f2f;
              font-weight: bold;
            }
            a {
              color: #0066cc;
              text-decoration: none;
            }
          </style>
        </head>
        <body>

                  <p>1.
        Hassle-free returns within 7 days under specific product and promotion conditions.</p>

                          <p>2.
        Refunds for prepaid orders revert to the original payment method, while COD orders receive a wallet refund.</p>

                          <p>3.
        Report defective, incorrect, or damaged items within 24 hours of delivery.</p>

                          <p>4.
        Products bought during special promotions like BOGO are not eligible for returns.</p>

                          <p>5.
        For excessive returns, reverse shipment fee upto Rs 100 can be charged, which will be deducted from the refund.</p>

                          <p>6.
        Non-returnable items include accessories, sunglasses, perfumes, masks, and innerwear due to hygiene concerns.</p>
        
        </body>
        </html>

        """

        guard let data = htmlString.data(using: .utf8) else {
            textView.text = "Failed to load content."
            return
        }

        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue
        ]

        do {
            let attributedString = try NSAttributedString(data: data, options: options, documentAttributes: nil)
            textView.attributedText = attributedString
        } catch {
            textView.text = "Error rendering HTML: \(error.localizedDescription)"
        }
    }
    func htmlToAttributedString(_ html: String) -> NSAttributedString? {
        guard let data = html.data(using: .utf8) else { return nil }
        do {
            return try NSAttributedString(
                data: data,
                options: [.documentType: NSAttributedString.DocumentType.html,
                          .characterEncoding: String.Encoding.utf8.rawValue],
                documentAttributes: nil)
        } catch {
            print("❌ HTML Parsing failed:", error)
            return nil
        }
    }
    func strikethroughText(_ text: String, color: UIColor = .black) -> NSAttributedString {
        let attributes: [NSAttributedString.Key: Any] = [
            .strikethroughStyle: NSUnderlineStyle.single.rawValue,
            .foregroundColor: color
        ]
        return NSAttributedString(string: text, attributes: attributes)
    }
    
    
    @IBAction func actHeart(_ sender: Any) {
    }
    @IBAction func actBag(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMCartTableVC) as! LMCartTableVC
        secondVC.backBtn = "Product"
        secondVC.navigationControl = true
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
    @IBAction func acctBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actAddToBag(_ sender: Any) {
        //self.viewheader.backgroundColor = .clear
//        if THUserDefaultValue.isUserLoging  == false {
//            let halfVC = LoginVC()
//            halfVC.modalPresentationStyle = .overFullScreen
//            self.present(halfVC, animated: true)
//        } else {
            if THUserDefaultValue.isUsercolorsize == nil {
                AlertManager.showAlert(on: self,
                                       title: "Please select the product size",
                                       message: "") {
                }

            } else {
                
                let variantID =  viewmodel.modelproduct?.variantsColor?[0].sizes
                if let mediumSize = variantID?.first(where: { $0.size == THUserDefaultValue.isUsercolorsize }) {
                    print("M size is available with price: \(mediumSize.variantId)")
                    viewmodel.validateAddToCart(productID: productId, variantId: mediumSize.variantId ?? "", qty: 1)
                }
            }
        //}
    }
}

extension String {
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect,
                                            options: .usesLineFragmentOrigin,
                                            attributes: [.font: font],
                                            context: nil)
        return ceil(boundingBox.height)
    }
}
class LMPRoductDetailFinalVC: UIViewController{
    var productId:String = keyName.emptyStr

}
