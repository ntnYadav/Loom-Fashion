//
//  LMAddressMV.swift
//  LoomApp
//
//  Created by Flucent tech on 30/04/25.


import Foundation
import UIKit
import Toast_Swift


class LMProductMainDetailFinalMV : NSObject{
    var modelCoupon : PromoData?
    var modelproduct : ProductDataDetail?
    var modelCategory : ResponseData?
    var modelReview: [Review] = []
    var customerImages: [CustomerImageDetail] = []
    var sizeArrayTemp: [String]?
    var couponarr:[Couponinitial] = []

    var modelCouponInitial : [Couponinitial] = []

    private var hostVC : LMProductMainDetVC
    init(hostController : LMProductMainDetVC) {
        self.hostVC = hostController
    }
    
    // MARK: validate value
    func validateValue(productId:String,defaultVaniantID:String){
        guard hostVC.checkInternet else {
            return
        }
        getCategoryApi(productId: productId, defaultVaniantID: defaultVaniantID)
    }
    
    private  func getCategoryApi(productId:String,defaultVaniantID:String) {
        GlobalLoader.shared.show()
        THApiHandler.getApi(responseType: ProductDetailResponse.self, subcategoryId: productId) { [weak self] dataResponse, error in
            debugPrint(dataResponse as Any)
            GlobalLoader.shared.hide()
            if dataResponse != nil{
                self?.modelproduct = (dataResponse?.data)!
                DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                    
                  //  if let prodVari == self?.modelproduct?.defaultVariantId  {
                        let defaultPair = self?.modelproduct?.colors?
                            .compactMap { color in
                                color.sizes?.first { $0.variantId == defaultVaniantID }
                                    .map { (color, $0) }
                            }
                            .first
                        
                        if var (color, variant) = defaultPair {
                            // hostVC.imagesCollection = variant[]
                            self?.modelproduct?.variantsColor = [color]
                            self?.modelproduct?.variants = [variant] // or append
                            self?.modelproduct?.sizestemp = variant.images
                            print("Color: \(color.value), Size: \(variant.images)")
                        }
                    let sellingPrice = self?.modelproduct?.variants?.first?.price?.sellingPrice ?? 0.0
                    self?.validateCouponInitial(productId: productId, sellingPrice: sellingPrice)

                    
//                  self?.validateCouponInitial(productId: productId, sellingPrice: self?.modelproduct?.variants?[0].price?.sellingPrice ?? 0.0)
//                    
                    
                   // self?.modelproduct?.sizeArrayTemp = self?.modelproduct?.variantsColor?[0].sizes?.compactMap { $0.size } ?? []
//                    //print(allSizes)
//                    self?.modelproduct?.sizeArrayTemp?.reversed()
                }
                DispatchQueue.main.async {
                    self?.hostVC.collectionView.reloadData()
                   // self?.hostVC.collectionView.reloadData()
                }
            }
        }
    }
    func validateAddToCart(productID:String,variantId:String,qty:Int){
        guard hostVC.checkInternet else{
            return
        }
        self.callCartAPI(productId: productID, variantId: variantId, qty: qty)
        
    }
    func callWishListAPI(productId:String,strColor:String,strVaiantId:String) {
        GlobalLoader.shared.show()
        
        let bodyRequest = wishlist(productId:productId, color:strColor.capitalizedFirstLetter, variantId: strVaiantId)
        //cartParameter(productId:productId, variantId:variantId,quantity: qty)
        THApiHandler.post(requestBody: bodyRequest, responseType: WishlistResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
            GlobalLoader.shared.hide()
            if let status = dataResponse?.success {
//                let deleteSheet = LMCartPop()
//                deleteSheet.modalPresentationStyle = .overFullScreen
//                deleteSheet.modalTransitionStyle = .coverVertical
//                self?.hostVC.present(deleteSheet, animated: true)
            } else {
                self?.hostVC.showToastView(message: msg)
            }
        }
    }
    
    private  func callCartAPI(productId:String,variantId:String,qty:Int) {
        GlobalLoader.shared.show()
        
        let bodyRequest = cartParameter(productId:productId, variantId:variantId,quantity: qty)
        THApiHandler.post(requestBody: bodyRequest, responseType: AddToCartResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
            GlobalLoader.shared.hide()
            if let status = dataResponse?.success {
                THUserDefaultValue.isUsercolorsize = nil
                
                let deleteSheet = LMCartPop()
                deleteSheet.modalPresentationStyle = .overFullScreen
                deleteSheet.modalTransitionStyle = .coverVertical
                deleteSheet.onSelected = { selected in
                    print("User selected: \(selected)")
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let secondVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMCartTableVC) as! LMCartTableVC
                    secondVC.backBtn = "Product"
                    secondVC.navigationControl = true
                    self?.hostVC.navigationController?.pushViewController(secondVC, animated: true)
                }
                self?.hostVC.present(deleteSheet, animated: true)
            } else {
                self?.hostVC.showToastView(message: msg)
            }
        }
    }
    func validateCouponInitial(productId: String, sellingPrice: Double){
        guard hostVC.checkInternet else{
            return
        }
            self.callCouponApiInitial(productId: productId, sellingPrice: sellingPrice)
        
    }
//    "productId":"684ab9012ab52489ce9754f0",
//    "sellingPrice":1499
        
//        func callCouponApiInitial(productId:String,sellingPrice:Double){
//            guard hostVC.checkInternet else {
//                return
//            }
//            GlobalLoader.shared.show()
//            let bodyRequest = CouponResponseInitalbody(productId: productId, sellingPrice: sellingPrice)
//            
//                THApiHandler.post(requestBody: bodyRequest, responseType: CouponResponseInital.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
//                    GlobalLoader.shared.hide()
//                    if let status = dataResponse?.success {
//                        let mod = dataResponse?.data
//                        self?.modelCouponInitial = mod ?? []
//                        if let coupons = self?.modelCouponInitial {
//                            self?.couponarr = self?.getLowestAndSecondLowestCoupons(from: coupons) ?? []
//                            
//                            self?.hostVC.collectionView.reloadData()
//                            print("Lowest and second lowest coupons:")
////                            for coupon in lowestTwo {
////                                print("Code: \(coupon.code ?? "N/A"), Price: \(coupon.potentialFinalPrice ?? 0)")
////                            }
//                        }
//                    } else {
//                        
//                    }
//                }
//            
//            
//        }
    func callCouponApiInitial(productId: String, sellingPrice: Double) {
        guard hostVC.checkInternet else {
            return
        }

        GlobalLoader.shared.show()

        let bodyRequest = CouponResponseInitalbody(productId: productId, sellingPrice: sellingPrice)

        THApiHandler.post(
            requestBody: bodyRequest,
            responseType: CouponResponseInital.self,
            progressView: hostVC.view
        ) { [weak self] dataResponse, error, msg in
            GlobalLoader.shared.hide()


            if let success = dataResponse?.success, success {
                if let coupons = dataResponse?.data {
                    self?.modelCouponInitial = coupons
                    self?.couponarr = self?.getLowestAndSecondLowestCoupons(from: coupons) ?? []
                    self?.hostVC.collectionView.reloadData()
                }
            } else {
                print("❌ Coupon API failed: \(msg ?? "Unknown error")")
                // You can also show an alert here if needed
            }
        }
    }

    func getLowestAndSecondLowestCoupons(from coupons: [Couponinitial]) -> [Couponinitial] {
        // Filter coupons with valid potentialFinalPrice
        let validCoupons = coupons.filter { $0.potentialFinalPrice != nil }

        // Sort by potentialFinalPrice ascending
        let sortedCoupons = validCoupons.sorted {
            $0.potentialFinalPrice! < $1.potentialFinalPrice!
        }

        // Return up to two lowest coupons
        return Array(sortedCoupons.prefix(2))
    }

//    func findLowestCoupons(from coupons: [Couponinitial]) -> (minPrice: Double?, first: Couponinitial?, last: Couponinitial?) {
//        // Filter out nil prices and get the minimum
//        let validPrices = coupons.compactMap { $0.potentialFinalPrice }
//        guard let minPrice = validPrices.min() else {
//            return (nil, nil, nil) // No valid prices
//        }
//
//        // Find first occurrence
//        let firstMatch = coupons.first { $0.potentialFinalPrice == minPrice }
//        
//        // Find last occurrence
//        let lastMatch = coupons.last { $0.potentialFinalPrice == minPrice }
//
//        return (minPrice, firstMatch, lastMatch)
//    }
//        THApiHandler.getApi(responseType: CouponResponseInital.self) { [weak self] dataResponse, error in
//            debugPrint(dataResponse as Any)
//            GlobalLoader.shared.hide()
//            
//            if dataResponse != nil{
//                self?.modelCoupon = (dataResponse?.data)!
//                DispatchQueue.main.async {
//                    self?.hostVC.collectionView.reloadData()
//                }
//            }
 //       }
    
    func validateCoupon(){
        guard hostVC.checkInternet else{
            return
        }
        callCouponApi()
        
    }
    private  func callCouponApi() {
        GlobalLoader.shared.show()
        guard hostVC.checkInternet else{
            return
        }
        THApiHandler.getApi(responseType: PromoResponse.self) { [weak self] dataResponse, error in
            debugPrint(dataResponse as Any)
            GlobalLoader.shared.hide()
            
            if dataResponse != nil{
                self?.modelCoupon = (dataResponse?.data)!
                DispatchQueue.main.async {
                    self?.hostVC.collectionView.reloadData()
                }
            }
        }
    }
    func validateProductDetail(){
        guard hostVC.checkInternet else {
            return
        }
        getCategoryApi()
    }
    func getCategoryApi() {
        GlobalLoader.shared.show()
        THApiHandler.getApi(responseType: ApiResponse.self,page:"1",limit: "20",subcategoryId: "") { [weak self] dataResponse, error in
                debugPrint(dataResponse as Any)
                GlobalLoader.shared.hide()
                if dataResponse != nil{
                    self?.modelCategory = (dataResponse?.data)
                    DispatchQueue.main.async {
                        self?.hostVC.collectionView.reloadData()
                    }
                }
          }
    }
    func validateReviewDetail(productId:String){
        guard hostVC.checkInternet else {
            return
        }
        getReviewApi(productId:productId)
    }
    private  func getReviewApi(productId:String) {
        GlobalLoader.shared.show()
        THApiHandler.getApi(responseType: ReviewResponse123.self,page:"1",limit: "100",subcategoryId: productId,tagValue:"1") { [weak self] dataResponse, error in
                debugPrint(dataResponse as Any)
                GlobalLoader.shared.hide()
                if dataResponse != nil{
                    
                    if let reviews = dataResponse?.data?.reviews {
                        self?.modelReview = reviews
                        self?.customerImages = dataResponse?.data?.customerImageDetails ?? []
                              DispatchQueue.main.async {
                                  self?.hostVC.collectionView.reloadData()
                              }
                          } else {
                              print("❌ Failed to fetch reviews or no reviews available")
                          }
                }
          }
    }
   
    
    // MARK: validate value
    func validatePincodeValue(Pincode:String,weight:Double,height:Double,breadth:Double,length:Double){
        guard hostVC.checkInternet else {
            return
        }
        GlobalLoader.shared.show()
        let bodyRequest = deliveryPincodeReq12(deliveryPincode: Int(Pincode) ?? 0, weight: 5.2, height: Double(height), breadth: Double(breadth), length: Double(length))
        
            THApiHandler.post(requestBody: bodyRequest, responseType: DeliveryEstimateResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
                GlobalLoader.shared.hide()
                if let status = dataResponse?.success {
                    let mod = dataResponse?.data
                    self?.hostVC.dismiss(animated: true) {
                        let formatter = DateFormatter()
                        formatter.dateFormat = "yyyy-MM-dd"
                        let currentDateString = formatter.string(from: Date())
                        
                        THUserDefaultValue.userdateCurrentDate = currentDateString
                        
                        THUserDefaultValue.userdateDays   = mod?.estimatedDeliveryDays ?? ""

                        THUserDefaultValue.userdatefrmate = mod?.expectedDeliveryDate ?? ""
                        //self?.hostVC.onApplyTapped?(Pincode,[""])
                        THUserDefaultValue.isUserPincodeLoging = true
                                      }
                   // self?.hostVC.showToastView(message: dataResponse?.message ?? "")
                } else {
                    
                    //self?.hostVC.infoLabel.text = "Pincode is not serviceable"
                }
            }
        
        
    }
    
}
