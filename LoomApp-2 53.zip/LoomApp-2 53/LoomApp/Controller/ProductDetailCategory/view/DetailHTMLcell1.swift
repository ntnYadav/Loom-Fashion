//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class DetailHTMLcell1 : UICollectionViewCell {
                            
@IBOutlet weak var txtViewDesc: UITextView!
@IBOutlet weak var lblDescription: UILabel!
let formatedDescription: String = ""

override func awakeFromNib() {
    super.awakeFromNib()
    // Initialization code
    txtViewDesc.isEditable = false
    txtViewDesc.isSelectable = false
}
    
    func dataLoad(str:String) {
        
        print("str HTML =\(str)")
        if str == "" {
            
        } else {
            
          
            
            let fullHTML = wrapHTMLContent(str)
            
            if let attributed = htmlToAttributedString(fullHTML) {
                txtViewDesc.attributedText = attributed
            }
        }
    }
        
    private func wrapHTMLContent(_ bodyHTML: String) -> String {
        return """
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: HeroNew-Regular; font-size: 15px; color: #000; }
            p { margin: 10px 0; }
            strong { font-weight: bold; display: block; margin-top: 12px; }
        </style>
        </head>
        <body>
        \(bodyHTML)
        </body>
        </html>
        """
    }
    func showRefundPolicy(in textView: UITextView) {
        let htmlString = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
              padding: 16px;
              color: #333;
              line-height: 1.6;
            }
            h2 {
              color: #000;
              font-size: 20px;
              margin-top: 24px;
            }
            h3 {
              color: #444;
              font-size: 17px;
              margin-top: 20px;
            }
            ul {
              padding-left: 20px;
              margin: 8px 0;
            }
            li {
              margin-bottom: 6px;
            }
            .note {
              color: #d32f2f;
              font-weight: bold;
            }
            a {
              color: #0066cc;
              text-decoration: none;
            }
          </style>
        </head>
        <body>

                  <p>1.
        Hassle-free returns within 7 days under specific product and promotion conditions.</p>

                          <p>2.
        Refunds for prepaid orders revert to the original payment method, while COD orders receive a wallet refund.</p>

                          <p>3.
        Report defective, incorrect, or damaged items within 24 hours of delivery.</p>

                          <p>4.
        Products bought during special promotions like BOGO are not eligible for returns.</p>

                          <p>5.
        For excessive returns, reverse shipment fee upto Rs 100 can be charged, which will be deducted from the refund.</p>

                          <p>6.
        Non-returnable items include accessories, sunglasses, perfumes, masks, and innerwear due to hygiene concerns.</p>
        
        </body>
        </html>

        """

        guard let data = htmlString.data(using: .utf8) else {
            textView.text = "Failed to load content."
            return
        }

        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue
        ]

        do {
            let attributedString = try NSAttributedString(data: data, options: options, documentAttributes: nil)
            textView.attributedText = attributedString
        } catch {
            textView.text = "Error rendering HTML: \(error.localizedDescription)"
        }
    }
    func htmlToAttributedString(_ html: String) -> NSAttributedString? {
        guard let data = html.data(using: .utf8) else { return nil }

        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue
        ]

        do {
            let attributedString = try NSMutableAttributedString(
                data: data,
                options: options,
                documentAttributes: nil
            )

            // Safely apply default font
            if attributedString.length > 0 {
                attributedString.addAttribute(
                    .font,
                    value: UIFont.systemFont(ofSize: 15),
                    range: NSRange(location: 0, length: attributedString.length)
                )
            }

            return attributedString
        } catch {
            print("❌ HTML Parsing failed: \(error)")
            return nil
        }
    }

//override func setSelected(_ selected: Bool, animated: Bool) {
//  //  super.setSelected(selected, animated: animated)
//    // Configure the view for the selected state
//}

}

