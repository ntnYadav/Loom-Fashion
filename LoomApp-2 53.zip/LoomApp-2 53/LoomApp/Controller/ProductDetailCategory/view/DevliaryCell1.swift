//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class DevliaryCell1 : UICollectionViewCell {
    @IBOutlet weak var btnDelivery: UIButton!
    @IBOutlet weak var txtPincode: UITextField!
    @IBOutlet weak var lblPincode: UILabel!
    @IBOutlet weak var btnApply: UIButton!
    @IBOutlet weak var lblError: UILabel!
    @IBOutlet weak var viewPincode: UIView!
    @IBOutlet weak var imgTraqck: UIImageView!
    @IBOutlet weak var view24: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var viewDelivery: UIView!
    //    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//        // Configure the view for the selected state
//    }
    
}


