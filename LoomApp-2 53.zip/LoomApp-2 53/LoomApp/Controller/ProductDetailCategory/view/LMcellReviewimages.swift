//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMcellReviewimages : UICollectionViewCell,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var collectionviewimage: UICollectionView!
    @IBOutlet weak var lblTitle: UILabel!
    var customerImages : [CustomerImageDetail]?

    override func awakeFromNib() {
        super.awakeFromNib()

    }
    func initalCollectionCall() {
        collectionviewimage.delegate = self
        collectionviewimage.dataSource = self
        
   
        collectionviewimage.register(UINib(nibName: "LMcellcPhoto", bundle: nil), forCellWithReuseIdentifier: "LMcellcPhoto")
  
        
        collectionviewimage.reloadData()
  

    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return customerImages?.count ?? 0
        
    
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionviewimage.dequeueReusableCell(withReuseIdentifier: "LMcellcPhoto", for: indexPath) as! LMcellcPhoto
            let obj = customerImages?[indexPath.row]
            cell.lblline.isHidden = true
            cell.lblSize.isHidden = true
            cell.imgProduct.sd_setImage(with: URL(string: obj?.url ?? ""))
            return cell
    }
    
    //7011462743
  
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
            let width  = (collectionView.frame.width-10)/5
            return CGSize(width: width, height: (width + 10))
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
}

