//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Itsuki on 2023/10/23.
//

import UIKit
import SVGKit

class LMProductTitleCell : UICollectionViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblPlus: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
       
    }
  
    
   
}
