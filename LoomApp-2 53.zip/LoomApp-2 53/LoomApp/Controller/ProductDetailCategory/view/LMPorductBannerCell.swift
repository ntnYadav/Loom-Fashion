import UIKit
import SDWebImage
import SVGKit

protocol LMPorductBannerCellDelegate: AnyObject {
    func didTapBack()
    func didTapBag()
    func didTapSimilar(modelproduct:ProductDataDetail)

}

class LMPorductBannerCell: UICollectionViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    var imageOpenincontroller: ((Int,String) -> Void)?

    @IBOutlet weak var viewsimilar: UIView!
    
    @IBOutlet weak var btnSimilar: UIButton!
    @IBOutlet weak var imgHeart: UIImageView!
    @IBOutlet weak var btnHeat: UIButton!
    @IBOutlet weak var btnbag: UIButton!
    @IBOutlet weak var imgBag: UIImageView!
    @IBOutlet weak var imgsimilar: UIImageView!

    @IBOutlet weak var imgBack: UIImageView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var collectionviewimage: UICollectionView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var marqueeContainer: UIView!
    @IBOutlet weak var marqueeLabel: UILabel!
    
    weak var delegate: LMPorductBannerCellDelegate?
    @IBOutlet weak var pageControl: UIPageControl!

    var customerImages: [CustomerImageDetail]?
    var modelproduct: ProductDataDetail? {
        didSet {
            initalCollectionCall()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
           
        imgBag.image = SVGKImage(named: "ic_bagfinal")?.uiImage
        imgBack.image = SVGKImage(named: "ic_backfinal")?.uiImage
        imgHeart.image = SVGKImage(named: "ic_heart_empty")?.uiImage
        imgsimilar.image = SVGKImage(named: "ic_similar_product")?.uiImage

        
        viewsimilar.layer.cornerRadius = 10
        viewsimilar.backgroundColor = .white

           
       // if !isMarqueeAnimating {
            
      // }
    }
    private var hasStartedAnimation = false
    private var hasSimilar          = false

    override func layoutSubviews() {
        super.layoutSubviews()
        if modelproduct?.similarProducts?.count != 0 {
//            if hasSimilar == false {
//                hasSimilar = true
                let originalX = viewsimilar.frame.origin.x
                // Move view off-screen to the left
                viewsimilar.frame.origin.x = -300
                // Animate it to the original position
                UIView.animate(withDuration: 1.0, delay: 0, options: [.curveEaseInOut], animations: {
                    self.viewsimilar.frame.origin.x = originalX
                }, completion: nil)
          //  }
        }
        marqueeContainer.layoutIfNeeded()

        if !hasStartedAnimation {
            hasStartedAnimation = true
            setupMarqueeLabel()
            startVerticalMarquee()
        }
    }

        
    
    
    
//    override func layoutSubviews() {
//        super.layoutSubviews()
//        setupMarqueeContainer()
//        setupMarqueeLabel()
//        startVerticalMarquee()
//    }
    private var isMarqueeAnimating = false

//    override func layoutSubviews() {
//            super.layoutSubviews()
////        if AppDelegate.shared.banner == true {
////            setupMarqueeContainer()
////            setupMarqueeLabel()
////            startVerticalMarquee()
////            isMarqueeAnimating = true
////            // Only setup marquee once when layout is ready
////        }
//        }
    // MARK: - Marquee Setup
    
    
    private func setupMarqueeLabel() {
        marqueeLabel.text = "SHIPS WITHIN 24 HOURS"
        marqueeLabel.textAlignment = .center
        marqueeLabel.font = UIFont.systemFont(ofSize: 16)
        marqueeLabel.textColor = .white
        marqueeLabel.sizeToFit()
        
        marqueeLabel.translatesAutoresizingMaskIntoConstraints = true
        marqueeContainer.clipsToBounds = true
        marqueeContainer.backgroundColor = .black
        marqueeContainer.addSubview(marqueeLabel)

        // Set initial Y below the container
        marqueeLabel.frame.origin.y = marqueeContainer.bounds.height
    }


    private func startVerticalMarquee() {
        animateMarqueeStep1()
    }

    private func animateMarqueeStep1() {
        let centerY = (marqueeContainer.bounds.height - marqueeLabel.frame.height) / 2
        let centerX = (marqueeContainer.bounds.width - marqueeLabel.frame.width) / 2

        // Always recenter horizontally
        marqueeLabel.frame.origin.x = centerX

        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveLinear], animations: {
            self.marqueeLabel.frame.origin.y = centerY
        }, completion: { _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.animateMarqueeStep2()
            }
        })
    }


    private func animateMarqueeStep2() {
        let centerX = (marqueeContainer.bounds.width - marqueeLabel.frame.width) / 2
        marqueeLabel.frame.origin.x = centerX
        self.marqueeLabel.isHidden = true

        UIView.animate(withDuration: 0.1, delay: 0, options: [.curveLinear], animations: {
            self.marqueeLabel.frame.origin.y = -self.marqueeLabel.frame.height
        }, completion: { _ in
            // Reset position for next cycle
            self.marqueeLabel.isHidden = false
            self.marqueeLabel.frame.origin.y = self.marqueeContainer.bounds.height
            self.startVerticalMarquee()
        })
    }


 
    
    
    
//    func setupMarqueeContainer() {
//        marqueeContainer.backgroundColor = .black
//        marqueeContainer.clipsToBounds = true
//        marqueeContainer.translatesAutoresizingMaskIntoConstraints = false
//    }
//    
//    func setupMarqueeLabel() {
//        marqueeLabel.text = "SHIPS WITHIN 24 HOURS"
//        marqueeLabel.textAlignment = .center
//
//        marqueeLabel.font = UIFont(name: ConstantFontSize.regular, size: 16)
//        marqueeLabel.textColor = .white
//        marqueeLabel.sizeToFit()
//        
//        // Position label just below container
//        marqueeLabel.frame = CGRect(
//            x: 10,
//            y: marqueeContainer.bounds.height,
//            width: marqueeLabel.frame.width,
//            height: marqueeLabel.frame.height
//        )
//        
//        marqueeContainer.addSubview(marqueeLabel)
//    }
    
//    func startVerticalMarquee() {
//        UIView.animate(withDuration: 1.5, delay: 0, options: [.curveLinear, .repeat], animations: {
//            self.marqueeLabel.frame = CGRect(
//                x: self.marqueeLabel.frame.origin.x,
//                y: -self.marqueeLabel.frame.height,
//                width: self.marqueeLabel.frame.width,
//                height: self.marqueeLabel.frame.height
//            )
//          //  AppDelegate.shared.banner = false
//        }, completion: nil)
//    }
    
    // MARK: - Collection View Setup
    
    func initalCollectionCall() {
        collectionviewimage.delegate = self
        collectionviewimage.dataSource = self
        
        collectionviewimage.register(UINib(nibName: "LMPlaycell", bundle: nil), forCellWithReuseIdentifier: "LMPlaycell")
        collectionviewimage.reloadData()
        // Setup page control pages and initial page
              pageControl.numberOfPages = modelproduct?.variants?[0].images?.count ?? 0
              pageControl.currentPage = 0
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
           let pageWidth = scrollView.frame.width
           let currentPage = Int((scrollView.contentOffset.x + pageWidth / 2) / pageWidth)
           pageControl.currentPage = currentPage
       }
       
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return modelproduct?.variants?[0].images?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionviewimage.dequeueReusableCell(withReuseIdentifier: "LMPlaycell", for: indexPath) as? LMPlaycell else {
            return UICollectionViewCell()
        }
        
        if let urlString = modelproduct?.variants?[0].images?[indexPath.row], let url = URL(string: urlString) {
            cell.imgProduct.sd_imageIndicator = SDWebImageActivityIndicator.gray
            cell.imgProduct.sd_setImage(with: url)
        } else {
            cell.imgProduct.image = nil
        }
        
        cell.imgBag.image = SVGKImage(named: "ic_bagfinal")?.uiImage
        cell.imgBack.image = SVGKImage(named: "ic_backfinal")?.uiImage
        cell.imgHeart.image = SVGKImage(named: "ic_heart_empty")?.uiImage
        
        // Setup Heart image based on wishlist status
        let objModel = modelproduct?.variantsColor?[0].sizes?[0]
        if objModel?.isWishlisted == false {
            cell.imgHeart.image = SVGKImage(named: "ic_heart_empty")?.uiImage
        } else {
            cell.imgHeart.image = SVGKImage(named: "ic_heart_fill")?.uiImage
        }
        
        // Button Targets
      //  cell.btnSimilar.addTarget(self, action: #selector(actsimilar), for: .touchUpInside)
        
        cell.imgProduct.isUserInteractionEnabled = true
        cell.imgProduct.tag = indexPath.row // or any identifier you want
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(actImage(_:)))
        cell.imgProduct.addGestureRecognizer(tapGesture)
        
        btnSimilar.addTarget(self, action: #selector(actsimilar), for: .touchUpInside)
        btnSimilar.tag = indexPath.row
        
        btnSimilar.addTarget(self, action: #selector(actsimilar), for: .touchUpInside)
        btnSimilar.tag = indexPath.row
        cell.btnback.addTarget(self, action: #selector(backTapped), for: .touchUpInside)
        cell.btnBag.addTarget(self, action: #selector(movetoBag), for: .touchUpInside)
        
        cell.setup()
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Return full width and fixed height; adjust if needed
        return CGSize(width: collectionView.frame.width, height: 630)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    // MARK: - Button Actions
    //                cell.imgProduct.tag = indexPath.item // or your identifier

    @objc func actImage(_ sender: UITapGestureRecognizer) {
        if let tag = sender.view?.tag {
            print("Image tapped at index: \(tag)")
            imageOpenincontroller?(tag, "")
            // Use this tag to identify which image or cell was tapped
        }
    }
    @objc func actsimilar() {
//        let deleteSheet = LMSimilarVC()
//       // deleteSheet.modalPresentationStyle = .overFullScreen
//        deleteSheet.modalTransitionStyle = .coverVertical
//        self.hostVC.present(deleteSheet, animated: true)
        //delegate?.didTapSimilar(modelproduct: modelproduct!)
    }
    @objc func movetoBag() {
        delegate?.didTapBag()
    }
    
    @objc func backTapped() {
        delegate?.didTapBack()
    }
}
