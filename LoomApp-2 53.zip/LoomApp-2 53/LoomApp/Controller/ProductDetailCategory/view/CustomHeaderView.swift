//
//  CustomHeaderView.swift
//  CustomHeaderView
//
//  Created by Santosh on 04/08/20.
//  Copyright © 2020 Santosh. All rights reserved.
//

import UIKit

class CustomHeaderView: UITableViewHeaderFooterView{

    @IBOutlet weak var imgPlus: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnheader: UIButton!

        

    }


 
