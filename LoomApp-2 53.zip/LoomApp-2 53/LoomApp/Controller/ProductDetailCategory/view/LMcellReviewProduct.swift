//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMcellReviewProduct : UICollectionViewCell,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    var onCollectionItemcolorSize: ((_ index: Int, _ sizes: [SizeVariant]) -> Void)?
    var onCollectionViewMore: ((_ index: Int) -> Void)?

    @IBOutlet weak var lblViewAll: UILabel!
    @IBOutlet weak var collectionviewHeight: NSLayoutConstraint!
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var lblDis: UILabel!
    @IBOutlet weak var lblRating: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var collectionviewimage: UICollectionView!
    var modelReview: [Review] = []
    var images: [String]?
    @IBOutlet weak var btnView: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        btnView.addTarget(self, action: #selector(LMcellReviewProduct.actViewMore(_:)), for: .touchUpInside)
        
        let attributes: [NSAttributedString.Key: Any] = [
            .underlineStyle: NSUnderlineStyle.single.rawValue,
            .foregroundColor: UIColor(red: 255/255, green: 147/255, blue: 0/255, alpha: 1.0)
,
            .font: UIFont.systemFont(ofSize: 18, weight: .medium),
            .underlineColor: UIColor(red: 255/255, green: 147/255, blue: 0/255, alpha: 1.0) // Optional: underline in a different color
        ]

        let attributedString = NSAttributedString(string: "VIEW MORE", attributes: attributes)

            lblViewAll.attributedText = attributedString
    }
    func initalCollectionCall() {
        
        if images?.count != 0 {
            
            collectionviewimage.delegate = self
            collectionviewimage.dataSource = self
            
            collectionviewimage.register(UINib(nibName: "LMcellcPhoto", bundle: nil), forCellWithReuseIdentifier: "LMcellcPhoto")
      
            
            collectionviewimage.reloadData()
        } else {
          //  collectionviewHeight.constant = 0
        }
        
  

    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images?.count ?? 0
        
    
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionviewimage.dequeueReusableCell(withReuseIdentifier: "LMcellcPhoto", for: indexPath) as! LMcellcPhoto
            cell.lblSize.isHidden = true
            cell.lblline.isHidden = true
           // cell.lblRating.text = "\(rating) "
            let obj = images?[indexPath.row]
            cell.imgProduct.sd_setImage(with: URL(string: obj ?? ""))
        
            return cell
        
    }
    
    //7011462743
  
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
            let width  = (collectionView.frame.width-10)/5
            return CGSize(width: width, height: (width + 10))
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    @objc func actViewMore(_ sender: UIButton) {
        let tag = sender.tag
        onCollectionViewMore?(tag)
    }
}

