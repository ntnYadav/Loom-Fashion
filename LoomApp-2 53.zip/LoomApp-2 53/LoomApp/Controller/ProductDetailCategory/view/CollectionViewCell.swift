//
//  CollectionViewCell.swift
//  BottomSlideDemo
//
//  Created by chetu on 13/05/25.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
}
