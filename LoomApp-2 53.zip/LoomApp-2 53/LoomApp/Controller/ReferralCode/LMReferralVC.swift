//
//  ViewController.swift
//  demoBan
//
//  Created by Flucent tech on 06/08/25.
//
import UIKit
import SwiftUI
import SDWebImage
import SVGKit




class LMReferralVC: UIViewController {

    var model : Userprofile?


        // MARK: - Properties
        let referralCode = ""
        
        let steps = [
            "Share Your code" + "\n" + "Share your unique referral code with friends and famaily",
            "Your friends use your code when they register",
            "You and your friend both get rewards when they sign uo using your reffal code!"
        ]
        
        // MARK: - UI Elements
        private let scrollView = UIScrollView()
        private let contentView = UIStackView()

        private let backButton: UIButton = {
            let button = UIButton(type: .system)
            button.setImage(UIImage(systemName: "chevron.left"), for: .normal)
            button.tintColor = .black
            button.addTarget(self, action: #selector(backTapped), for: .touchUpInside)
            button.widthAnchor.constraint(equalToConstant: 30).isActive = true
            return button
        }()

        private let headerLabel: UILabel = {
            let label = UILabel()
            label.text = "Refer & Earn"
            label.font = UIFont(name: ConstantFontSize.Bold, size: 18)
            label.textAlignment = .center
            return label
        }()

        private lazy var headerStackView: UIStackView = {
            let stack = UIStackView(arrangedSubviews: [backButton, headerLabel])
            stack.axis = .horizontal
            stack.alignment = .center
            stack.spacing = 8
            return stack
        }()

    override func viewWillAppear(_ animated: Bool) {
        getProfileApi()
    }
        
        private let bannerImage: UIImageView = {
            let imageView = UIImageView()
           // imageView.image = UIImage(systemName: "refferal")
            //imageView.image = SVGKImage(named: "refferal")?.uiImage
            imageView.sd_setImage(with: URL(string: "https://dy8r4okxud2nb.cloudfront.net/Uploads/Admin/Images/1754896396001-c9a6a902-10af-4053-b8dc-9d7c045173cc.webp"))
//
//           //
//            imageView.image = SVGKImage(named: "111676393_10030674")?.uiImage
//            if let testImage = SVGKImage(named: "111676393_10030674") {
//                imageView.image = testImage.uiImage
//            } else {
//                print("SVG failed to load")
//            }
            imageView.tintColor = .systemGreen
            imageView.contentMode = .scaleAspectFit
            return imageView
        }()
        
        private let headingLabel: UILabel = {
            let label = UILabel()
            label.text = "Refer Friends & Earn Rewards"
            label.font = UIFont(name: ConstantFontSize.regular, size: 16)
            label.textAlignment = .center
            label.numberOfLines = 0
            return label
        }()
        
        private let descriptionLabel: UILabel = {
            let label = UILabel()
            label.text = "Share your referral code and earn rewards for every friend who joins!"
            label.font = UIFont(name: ConstantFontSize.regular, size: 14)
            label.textColor = .gray
            label.numberOfLines = 0
            label.textAlignment = .center
            return label
        }()
        
        private let referralLabel: UILabel = {
            let label = UILabel()
            label.text = "Your Referral Code"
            label.font = UIFont(name: ConstantFontSize.regular, size: 13)
            label.textColor = .gray
            label.textAlignment = .center
            return label
        }()
        
        // MARK: - UITextField with embedded copy button on right
        
        private lazy var codeTextField: UITextField = {
            let textField = UITextField()
            if let ref =  THUserDefaultValue.userReferralCode {
                textField.text = ref
            }
            textField.font = .boldSystemFont(ofSize: 18)
            textField.backgroundColor = .systemGray6
            textField.layer.cornerRadius = 8
            textField.clipsToBounds = true
            textField.textAlignment = .center
            //textField.isUserInteractionEnabled = false  // Non-editable
            
            // Create copy button for rightView
            let copyBtn = UIButton(type: .system)
            copyBtn.setImage(UIImage(systemName: "doc.on.doc"), for: .normal)
            copyBtn.tintColor = .black
            copyBtn.frame = CGRect(x: 0, y: 0, width: 50, height: 30) // width 50 as requested
            copyBtn.addTarget(self, action: #selector(copyCode), for: .touchUpInside)
            
            textField.rightView = copyBtn
            textField.rightViewMode = .always
          
            return textField
        }()
        
        private let referButton: UIButton = {
            let button = UIButton(type: .system)
            button.setTitle("Refer Friend", for: .normal)
            button.backgroundColor = .systemGreen
            button.setTitleColor(.white, for: .normal)
            button.layer.cornerRadius = 12
            button.titleLabel?.font = UIFont(name: ConstantFontSize.regular, size: 14)
            button.translatesAutoresizingMaskIntoConstraints = false
            button.addTarget(self, action: #selector(ActReferral), for: .touchUpInside)

            return button
        }()
        
        private let tabBar: UIStackView = {
            let stack = UIStackView()
            stack.axis = .horizontal
            stack.distribution = .fillEqually
            stack.alignment = .center
            stack.spacing = 0
            stack.backgroundColor = .systemGray6
            return stack
        }()
        
        // MARK: - Lifecycle
        override func viewDidLoad() {
            super.viewDidLoad()
            view.backgroundColor = .white
            setupViews()
        }

        // MARK: - Setup
        private func setupViews() {
            setupScrollView()
            setupMainContent()
            setupTabBar()
        }
        
        private func setupScrollView() {
            view.addSubview(scrollView)
            scrollView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 0) // leave space for tab bar
            ])
            
            scrollView.addSubview(contentView)
            contentView.axis = .vertical
            contentView.spacing = 20
            contentView.alignment = .fill
            contentView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                contentView.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 20),
                contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 20),
                contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -20),
                contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
                contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -40)
            ])
        }
        
        private func setupMainContent() {
            contentView.addArrangedSubview(headerStackView)

            bannerImage.heightAnchor.constraint(equalToConstant: 200).isActive = true
            bannerImage.widthAnchor.constraint(equalToConstant: view.layer.frame.size.width).isActive = true
          

            contentView.addArrangedSubview(bannerImage)
            
            contentView.addArrangedSubview(headingLabel)
            contentView.addArrangedSubview(descriptionLabel)
            
            // Steps with overlay label inside image
            for (index, step) in steps.enumerated() {
                let stepStack = UIStackView()
                stepStack.axis = .horizontal
                stepStack.spacing = 12
                stepStack.alignment = .center  // Align top
                
                // Container view for image + overlay label
                let imageContainer = UIView()
                imageContainer.translatesAutoresizingMaskIntoConstraints = false
                imageContainer.widthAnchor.constraint(equalToConstant: 46).isActive = true
                imageContainer.heightAnchor.constraint(equalToConstant: 46).isActive = true
                imageContainer.layer.cornerRadius = 23 // Half of width/height (46)
                imageContainer.layer.borderColor = UIColor.gray.cgColor
               // imageContainer.layer.borderWidth = 
                imageContainer.backgroundColor = .systemGray6


                let imageView = UIImageView()
                imageView.contentMode = .scaleAspectFit
                imageView.tintColor = .systemGreen
                imageView.translatesAutoresizingMaskIntoConstraints = false
                if index == 0 {
                    imageView.image = SVGKImage(named: "share-3-svgrepo-com")?.uiImage
                } else if index == 1 {
                    imageView.image = SVGKImage(named: "ic_rupes")?.uiImage
                } else {
                    imageView.image = SVGKImage(named: "gift-svgrepo-com")?.uiImage
                }

                let symbolName = "\(index + 1).circle.fill"
                
                imageContainer.addSubview(imageView)
//                NSLayoutConstraint.activate([
//                    imageView.topAnchor.constraint(equalTo: imageContainer.topAnchor),
//                    imageView.leadingAnchor.constraint(equalTo: imageContainer.leadingAnchor),
//                    imageView.trailingAnchor.constraint(equalTo: imageContainer.trailingAnchor),
//                    imageView.bottomAnchor.constraint(equalTo: imageContainer.bottomAnchor)
//                ])
                NSLayoutConstraint.activate([
                    imageView.centerXAnchor.constraint(equalTo: imageContainer.centerXAnchor),
                    imageView.centerYAnchor.constraint(equalTo: imageContainer.centerYAnchor),
                    imageView.widthAnchor.constraint(equalToConstant: 24),   // set desired width
                    imageView.heightAnchor.constraint(equalToConstant: 24)   // set desired height
                ])
                // Overlay label inside the imageContainer (top-left)
                let overlayLabel = UILabel()
                overlayLabel.text = "\(index + 1)" // Number overlay per step
                overlayLabel.font = .systemFont(ofSize: 10, weight: .bold)
                overlayLabel.textColor = .white
                overlayLabel.backgroundColor = .darkGray
                overlayLabel.textAlignment = .center
                overlayLabel.layer.cornerRadius = 8
                overlayLabel.clipsToBounds = true
                overlayLabel.translatesAutoresizingMaskIntoConstraints = false
                
                imageContainer.addSubview(overlayLabel)
                NSLayoutConstraint.activate([
                    overlayLabel.topAnchor.constraint(equalTo: imageContainer.topAnchor, constant: 0),
                    overlayLabel.leadingAnchor.constraint(equalTo: imageContainer.leadingAnchor, constant: 0),
                    overlayLabel.heightAnchor.constraint(equalToConstant: 15),
                    overlayLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 15)
                ])
                
                // Step label next to the imageContainer
                let stepLabel = UILabel()
                if index == 0 {

                    let titleText = "Share Your Code"
                    let bodyText = "\nShare your unique referral code with friends and family"
                    let fullText = titleText + bodyText

                    let attributedString = NSMutableAttributedString(string: fullText)

                    // Define fonts
                    let titleFont = UIFont(name: ConstantFontSize.Bold, size: 14)
                    let bodyFont = UIFont(name: ConstantFontSize.regular, size: 12)

                    // Define colors
                    let titleColor = UIColor.black
                    let bodyColor  = UIColor.darkGray

                    // Apply to title
                    attributedString.addAttributes([
                        .font: titleFont,
                        .foregroundColor: titleColor
                    ], range: NSRange(location: 0, length: titleText.count))

                    // Apply to body
                    attributedString.addAttributes([
                        .font: bodyFont,
                        .foregroundColor: bodyColor
                    ], range: NSRange(location: titleText.count, length: bodyText.count))

                    // Assign to label
                    stepLabel.numberOfLines = 0
                    stepLabel.attributedText = attributedString
                } else if index == 1 {
                    let titleText = "They Sign Up"
                    let bodyText = "\nYour friends use your code when they register"
                    let fullText = titleText + bodyText
                   
                    let attributedString = NSMutableAttributedString(string: fullText)

                    // Define fonts
                    let titleFont = UIFont(name: ConstantFontSize.Bold, size: 14)
                    let bodyFont = UIFont(name: ConstantFontSize.regular, size: 12)

                    // Define colors
                    let titleColor = UIColor.black
                    let bodyColor = UIColor.darkGray

                    // Apply to title
                    attributedString.addAttributes([
                        .font: titleFont,
                        .foregroundColor: titleColor
                    ], range: NSRange(location: 0, length: titleText.count))

                    // Apply to body
                    attributedString.addAttributes([
                        .font: bodyFont,
                        .foregroundColor: bodyColor
                    ], range: NSRange(location: titleText.count, length: bodyText.count))

                    // Assign to label
                    stepLabel.numberOfLines = 0
                    stepLabel.attributedText = attributedString
                } else {
                    let titleText = "Both Get Rewards"
                    let bodyText = "\nYou and your friend both get rewards when they sign uo using your reffal code!"
                    let fullText = titleText + bodyText

                    let attributedString = NSMutableAttributedString(string: fullText)

                    // Define fonts
                    let titleFont = UIFont(name: ConstantFontSize.Bold, size: 14)
                    let bodyFont = UIFont(name: ConstantFontSize.regular, size: 12)

                    // Define colors
                    let titleColor = UIColor.black
                    let bodyColor = UIColor.darkGray

                    // Apply to title
                    attributedString.addAttributes([
                        .font: titleFont,
                        .foregroundColor: titleColor
                    ], range: NSRange(location: 0, length: titleText.count))

                    // Apply to body
                    attributedString.addAttributes([
                        .font: bodyFont,
                        .foregroundColor: bodyColor
                    ], range: NSRange(location: titleText.count, length: bodyText.count))

                    // Assign to label
                    stepLabel.numberOfLines = 0
                    stepLabel.attributedText = attributedString
                }
               // stepLabel.font = .systemFont(ofSize: 16)
                stepLabel.numberOfLines = 0
                stepLabel.setContentHuggingPriority(.defaultLow, for: .vertical)
                stepLabel.setContentCompressionResistancePriority(.required, for: .vertical)
                
                stepStack.addArrangedSubview(imageContainer)
                stepStack.addArrangedSubview(stepLabel)
                
                contentView.addArrangedSubview(stepStack)
            }

            // Referral Code Section
            contentView.addArrangedSubview(referralLabel)
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(copyCode))
            codeTextField.addGestureRecognizer(tapGesture)
            // Add the UITextField with embedded copy button (right side)
            NSLayoutConstraint.activate([
                codeTextField.widthAnchor.constraint(equalToConstant: 50),
                codeTextField.heightAnchor.constraint(equalToConstant: 50)
            ])
            contentView.addArrangedSubview(codeTextField)
            
            // Refer Button - width 50, height 50
            
            
            NSLayoutConstraint.activate([
                referButton.widthAnchor.constraint(equalToConstant: 50),
                referButton.heightAnchor.constraint(equalToConstant: 50)
            ])
            contentView.addArrangedSubview(referButton)

        }
        
        private func setupTabBar() {
            view.addSubview(tabBar)
            tabBar.isHidden = true
            
            tabBar.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                tabBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
                tabBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                tabBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                tabBar.heightAnchor.constraint(equalToConstant: 60)
            ])
            
            let items = [
                ("house", "Home"),
                ("person.2", "My Matches"),
                ("gift.fill", "Refer & Earn"),
                ("wallet.pass", "Withdraw")
            ]
            
            for (icon, title) in items {
                let stack = UIStackView()
                stack.axis = .vertical
                stack.alignment = .center
                stack.spacing = 4
                
                let imageView = UIImageView(image: UIImage(systemName: icon))
                imageView.tintColor = icon == "gift.fill" ? .systemGreen : .black
                
                let label = UILabel()
                label.text = title
                label.textColor = icon == "gift.fill" ? .systemGreen : .black
                
                stack.addArrangedSubview(imageView)
                stack.addArrangedSubview(label)
                
                tabBar.addArrangedSubview(stack)
            }
        }

        // MARK: - Actions
          @objc private func ActReferral() {
                  let referralText = """
                  🎁 Join me on Loom Fashion & get ₹50 instantly!
                  Use my referral code: TESTING_CODE
                  👉 Download now: https://apps.apple.com/in/app/loom-fashion/id6739187499
                  """

                  let activityVC = UIActivityViewController(activityItems: [referralText], applicationActivities: nil)

                  // For iPad (to avoid crash)
                  if let popoverController = activityVC.popoverPresentationController {
                      popoverController.sourceView = self.view
                      popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
                      popoverController.permittedArrowDirections = []
                  }

                  self.present(activityVC, animated: true, completion: nil)
              
          }
           @objc private func copyCode() {
            UIPasteboard.general.string = referralCode
            
            let alert = UIAlertController(title: "Copied!", message: "Referral code copied to clipboard.", preferredStyle: .alert)
            present(alert, animated: true)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                alert.dismiss(animated: true)
            }
        }
        @objc private func backTapped() {
            navigationController?.popViewController(animated: true)
            // Or use dismiss(animated: true) if presented modally
        }
    private  func getProfileApi() {
           GlobalLoader.shared.show()
        guard let phoneNumber = THUserDefaultValue.phoneNumber else {
                    return
                }
        THApiHandler.getApi(responseType: UserResponse.self,phoneNo:phoneNumber) { [weak self] dataResponse, error in
                debugPrint(dataResponse as Any)
                GlobalLoader.shared.hide()
                if dataResponse != nil{
                  //  self?.healthData = dataResponse?.data
                    self?.model = (dataResponse?.data)!
                    if self?.model != nil {
                       // THUserDefaultValue.userReferralCode = dataResponse?.data?.referralCode
                       // self?.codeTextField.text = self?.model.referr
                        
                    }
                    DispatchQueue.main.async {
                        //self?.hostVC.tblAddlist.reloadData()
                    }
                }
                
            }
        
    }
    
    }
