//
//  Item.swift
//  CollectionViewSelfSizing
//
//  Created by Vadym Bulavin on 1/31/19.
//  Copyright © 2019 Vadym Bulavin. All rights reserved.
//

import Foundation

struct Item {
    let title: String
}
