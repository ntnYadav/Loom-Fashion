//
//  ViewController.swift
//  reg
//
//  Created by Flucent tech on 07/08/25.
//

import UIKit

class LMContactDetailsVC: UIViewController, UITextFieldDelegate {
         let extraFieldNoteLabel = UILabel()
        private let containerView = UIView()
        private let headerLabel = UILabel()
        let nameTextField = UITextField()
        let phoneTextField = UITextField()
        let emailTextField = UITextField()
        let extraTextField = UITextField() // 👈 New text field
        private let continueButton = UIButton(type: .system)
        private let bottomLabel = UILabel()
        
        private let otpLoader = UIActivityIndicatorView(style: .large)
        private let otpTextField = UITextField()
        private let resendButton = UIButton(type: .system)
        private var resendTimer: Timer?
        private var remainingSeconds = 30
        private let timerLabel = UILabel()
        
        private let extraLeftButton = UIButton(type: .system) // 👈 New button
        
        lazy private var viewmodel = LMContactVM(hostController: self)

        override func viewDidLoad() {
            super.viewDidLoad()
            let dismissTap = UITapGestureRecognizer(target: self, action: #selector(backgroundTapped))
            dismissTap.cancelsTouchesInView = false
            view.addGestureRecognizer(dismissTap)
            
            
            extraFieldNoteLabel.isHidden = true
            nameTextField.delegate = self
            emailTextField.delegate = self
            
            nameTextField.returnKeyType = .next
            emailTextField.returnKeyType = .done
            
            setupUI()
            
            NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow),
                                                   name: UIResponder.keyboardWillShowNotification, object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide),
                                                   name: UIResponder.keyboardWillHideNotification, object: nil)
            
            let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
            view.addGestureRecognizer(tap)
            
            guard let phoneNumber = THUserDefaultValue.phoneNumber else {
                return
            }
            self.phoneTextField.text = phoneNumber
        }
        
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            
            let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
            swipeLeft.direction = .left
            
            let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
            swipeRight.direction = .right
            
            view.addGestureRecognizer(swipeLeft)
            view.addGestureRecognizer(swipeRight)
        }
        
        override func viewWillDisappear(_ animated: Bool) {
            super.viewWillDisappear(animated)
            dismissKeyboard()
        }

        @objc private func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
            if gesture.direction == .right {
                self.navigationController?.popViewController(animated: true)
            }
        }

        deinit {
            NotificationCenter.default.removeObserver(self)
        }
        
        @objc private func keyboardWillHide(notification: Notification) {
            UIView.animate(withDuration: 0.3) {
                self.containerView.transform = .identity
            }
        }

        @objc private func dismissKeyboard() {
            view.endEditing(true)
        }
        
        @objc private func keyboardWillShow(notification: Notification) {
            guard let userInfo = notification.userInfo,
                  let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }

            if self.containerView.transform == .identity {
                UIView.animate(withDuration: 0.3) {
                    self.containerView.transform = CGAffineTransform(translationX: 0, y: -keyboardFrame.height / 2)
                }
            }
        }
        
        private func showOTPLoaderAndResend() {
            otpLoader.startAnimating()
            containerView.addSubview(otpLoader)
            otpLoader.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                otpLoader.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
                otpLoader.topAnchor.constraint(equalTo: bottomLabel.bottomAnchor, constant: 20)
            ])
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                self.otpLoader.stopAnimating()
                self.otpLoader.removeFromSuperview()
                self.showOTPInputAndResend()
            }
        }
        
        private func showOTPInputAndResend() {
            otpTextField.placeholder = "Enter OTP"
            otpTextField.borderStyle = .roundedRect
            otpTextField.textAlignment = .center
            otpTextField.keyboardType = .numberPad
            otpTextField.font = UIFont(name: "HeroNew-Regular", size: 16)

            resendButton.setTitle("Resend OTP", for: .normal)
            resendButton.setTitleColor(.gray, for: .normal)
            resendButton.isEnabled = false
            resendButton.addTarget(self, action: #selector(resendOTP), for: .touchUpInside)

            timerLabel.font = UIFont.systemFont(ofSize: 14)
            timerLabel.textColor = .gray
            updateTimerLabel()

            let otpStack = UIStackView(arrangedSubviews: [otpTextField, resendButton, timerLabel])
            otpStack.axis = .vertical
            otpStack.spacing = 12
            otpStack.alignment = .center

            containerView.addSubview(otpStack)
            otpStack.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                otpStack.topAnchor.constraint(equalTo: bottomLabel.bottomAnchor, constant: 20),
                otpStack.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
                otpTextField.widthAnchor.constraint(equalToConstant: 120),
            ])

            startResendTimer()
        }
        
        private func updateTimerLabel() {
            timerLabel.text = "Resend in \(remainingSeconds)s"
        }

        private func startResendTimer() {
            remainingSeconds = 30
            resendTimer?.invalidate()
            resendTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                self.remainingSeconds -= 1
                self.updateTimerLabel()
                if self.remainingSeconds <= 0 {
                    self.resendTimer?.invalidate()
                    self.resendButton.isEnabled = true
                    self.resendButton.setTitleColor(.systemBlue, for: .normal)
                    self.timerLabel.text = "You can now resend OTP"
                }
            }
        }

        @objc private func resendOTP() {
            resendButton.isEnabled = false
            resendButton.setTitleColor(.gray, for: .normal)
            startResendTimer()
        }

        private func setupUI() {
            
            // New label below extraTextField
            extraFieldNoteLabel.text = "This is an extra field note."
            extraFieldNoteLabel.textColor = .gray
            extraFieldNoteLabel.font = UIFont(name: "HeroNew-Regular", size: 13)
            extraFieldNoteLabel.textAlignment = .left
            
            
            view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
            
            containerView.backgroundColor = .white
            containerView.layer.cornerRadius = 0
            containerView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            view.addSubview(containerView)
            containerView.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                containerView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.60),
              //  containerView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5),
                containerView.leftAnchor.constraint(equalTo: view.leftAnchor),
                containerView.rightAnchor.constraint(equalTo: view.rightAnchor),
                containerView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            ])
            
            headerLabel.text = "Contact Details"
            headerLabel.textColor = .black
            headerLabel.font = UIFont(name: "HeroNew-Regular", size: 20)
            headerLabel.textAlignment = .center

//            [nameTextField, phoneTextField, emailTextField, extraTextField].forEach {
////                $0.font = UIFont(name: "HeroNew-Regular", size: 16)
////                $0.layer.borderWidth = 0.3
////                $0.layer.borderColor = UIColor.lightGray.cgColor
////                $0.backgroundColor = .white
////                $0.borderStyle = .roundedRect
////                $0.setLeftPaddingPoints(10)
//                $0.heightAnchor.constraint(equalToConstant: 50).isActive = true
//                $0.delegate = self
//            }
            [nameTextField, phoneTextField, emailTextField, extraTextField].forEach {
                $0.font = UIFont(name: "HeroNew-Regular", size: 16)
                $0.layer.borderWidth = 0.3
                $0.layer.borderColor = UIColor.lightGray.cgColor
                $0.backgroundColor = .white
                $0.borderStyle = .roundedRect
                //$0.setLeftPaddingPoints(10)
                $0.heightAnchor.constraint(equalToConstant: 50).isActive = true
                $0.delegate = self
            }
            nameTextField.placeholder = "Enter name"
            phoneTextField.placeholder = "Enter phone no"
            phoneTextField.keyboardType = .numberPad
            phoneTextField.isUserInteractionEnabled = false
            emailTextField.placeholder = "Enter email address"
            extraTextField.placeholder = "Enter referral code(Optional)"

            // Add +91 prefix
            let prefixLabel = UILabel()
            prefixLabel.text = "  +91 | "
            prefixLabel.font = UIFont(name: "HeroNew-Regular", size: 16)
            prefixLabel.sizeToFit()
            phoneTextField.leftView = prefixLabel
            phoneTextField.leftViewMode = .always

            // 👇 Extra left button setup
            // 👇 Extra right button setup
            extraLeftButton.isHidden = true
            extraLeftButton.setTitle("Apply", for: .normal)
            extraLeftButton.setTitleColor(.black, for: .normal)
            extraLeftButton.titleLabel?.font = UIFont(name: "HeroNew-Regular", size: 16)
            extraLeftButton.addTarget(self, action: #selector(extraButtonTapped), for: .touchUpInside)
            extraLeftButton.sizeToFit()

            let buttonContainer = UIView(frame: CGRect(x: 0, y: 0, width: extraLeftButton.frame.width + 20, height: 30))
            extraLeftButton.frame = CGRect(x: 10, y: 0, width: extraLeftButton.frame.width, height: 30)
            buttonContainer.addSubview(extraLeftButton)

            // Assign to rightView
            extraTextField.rightView = buttonContainer
            extraTextField.rightViewMode = .always
            
            continueButton.titleLabel?.font = UIFont(name: "HeroNew-Regular", size: 18)
            continueButton.setTitle("Continue", for: .normal)
            continueButton.setTitleColor(.white, for: .normal)
            continueButton.backgroundColor = .black
            continueButton.layer.cornerRadius = 0
            continueButton.addTarget(self, action: #selector(continueTapped), for: .touchUpInside)
            continueButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
            
            bottomLabel.font = UIFont(name: "HeroNew-Regular", size: 14)
            bottomLabel.text = "By continuing, you agree to our Terms."
            bottomLabel.textColor = .gray
            bottomLabel.textAlignment = .center

            // 👇 Include extraTextField here
            let stack = UIStackView(arrangedSubviews: [
                headerLabel,
                nameTextField,
                phoneTextField,
                emailTextField,
                extraTextField,
                extraFieldNoteLabel, // 👈 Add the label here
                continueButton,
                bottomLabel
            ])

          //  let stack = UIStackView(arrangedSubviews: [headerLabel, nameTextField, phoneTextField, emailTextField, extraTextField, continueButton, bottomLabel])
            stack.axis = .vertical
            stack.spacing = 16
            stack.alignment = .fill
            
            containerView.addSubview(stack)
            stack.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                stack.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),
                stack.leftAnchor.constraint(equalTo: containerView.leftAnchor, constant: 20),
                stack.rightAnchor.constraint(equalTo: containerView.rightAnchor, constant: -20)
            ])
        }

        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            if textField == nameTextField {
                emailTextField.becomeFirstResponder()
            } else if textField == emailTextField {
                extraTextField.becomeFirstResponder()
            } else {
                textField.resignFirstResponder()
            }
            return true
        }
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//
//    }
        func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            let currentText = textField.text ?? ""
            guard let stringRange = Range(range, in: currentText) else { return false }
            let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
            if textField == extraTextField {
                    // Allow only letters and digits
                    let allowed = CharacterSet.letters.union(.decimalDigits)
                    guard string.rangeOfCharacter(from: allowed.inverted) == nil else {
                        return false
                    }

                    // If exactly 8 characters, call the API
                    if updatedText.count == 10 {
                        DispatchQueue.main.async {
                           // self.viewmodel.hitReferralApi(referalcoode: updatedText)
                        }
                    }

                    // Prevent input if more than 8 characters
                    return updatedText.count <= 10
                }
            
            
            if textField == nameTextField {
                let allowed = CharacterSet.letters.union(.whitespaces)
                return string.rangeOfCharacter(from: allowed.inverted) == nil && updatedText.count <= 30
            }

            if textField == emailTextField {
                return updatedText.count <= 50
            }

            return true
        }

        @objc private func continueTapped() {
            view.endEditing(true)
            viewmodel.validateValue()
        }

        @objc private func extraButtonTapped() {
            print("Extra left button tapped!")
            // You can add your own logic here
        }

        @IBAction func actSigin(_ sender: Any) {
            // Add logic if needed
        }
    @objc private func backgroundTapped(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: view)
        if !containerView.frame.contains(location) {
            // Dismiss the view controller
            self.dismiss(animated: true, completion: nil)
        }
    }
    }
