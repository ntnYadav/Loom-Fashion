//
//  LoginVM.swift
//  TouringHealth
//
//  Created by chetu on 07/10/22.
//

import Foundation
import UIKit
import Toast_Swift
//nameTextField.placeholder = "Enter Name"
//phoneTextField.placeholder = "Phone Number"
//emailTextField.placeholder = "Email Address"
class LMContactVM : NSObject{
    
    private var hostVC : LMContactDetailsVC
    init(hostController : LMContactDetailsVC) {
        self.hostVC = hostController
    }
    // MARK: validate value
    
    
    func validateValue(){
        guard hostVC.checkInternet else { return }
        
        let name = hostVC.nameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let phoneNumber = hostVC.phoneTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let email = hostVC.emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let referralCode = hostVC.extraTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        
        // 1. Validate name
        guard !name.isEmpty else {
            hostVC.showToastView(message: keyName.name)
            return
        }
        
        // 2. Validate phone number
        guard !phoneNumber.isEmpty else {
            hostVC.showToastView(message: keyName.phoneNumber)
            return
        }
        guard phoneNumber.count == 10 else {
            hostVC.showToastView(message: keyName.validPhoneNumber)
            return
        }
        
        // 3. Validate email if not empty
        if !email.isEmpty && !email.isValidEmail() {
            hostVC.showToastView(message: keyName.validEmail)
            return
        }
        
        // 4. Validate referral code if entered
        let allowedCharacters = CharacterSet.letters.union(.decimalDigits)
        if !referralCode.isEmpty {
            if referralCode.rangeOfCharacter(from: allowedCharacters.inverted) != nil || referralCode.count != 10 {
                hostVC.showToastView(message: "Referral code must be exactly 10 letters or digits")
                return
            }
        }
        
        // ✅ All validations passed – Call API
        self.hitContactApi(
            name: name,
            phoneNo: phoneNumber,
            emailId: email,
            referralCode: referralCode
        )
    }
//    func validateValue(){
//        guard hostVC.checkInternet else{
//            return
//        }
//        
//        let phoneNumber = hostVC.phoneTextField.text!
//        if hostVC.nameTextField.text!.isEmpty {
//            self.hostVC.showToastView(message: keyName.name)
//        } else if hostVC.phoneTextField.text!.isEmpty {
//            self.hostVC.showToastView(message: keyName.phoneNumber)
//        } else if phoneNumber.count != 10 {
//            self.hostVC.showToastView(message: keyName.validPhoneNumber)
//            return
//        } else if let email = hostVC.emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !email.isEmpty {
//                if !email.isValidEmail() {
//                    self.hostVC.showToastView(message: keyName.validEmail) // "Please enter a valid email"
//                } else {
//                    self.hitContactApi(name: hostVC.nameTextField.text!, phoneNo: hostVC.phoneTextField.text!, emailId: hostVC.emailTextField.text!, referralCode: hostVC.extraTextField.text!)
//                    
//                    // ✅ Email is valid, proceed
//                }
//            
////        } else if !hostVC.emailTextField.text!.isValidEmail() {
////            self.hostVC.showToastView(message: keyName.validEmail)
//        } else {
//            self.hitContactApi(name: hostVC.nameTextField.text!, phoneNo: hostVC.phoneTextField.text!, emailId: hostVC.emailTextField.text!, referralCode: hostVC.extraTextField.text!)
//        }
//    }
      func hitReferralApi(referalcoode:String) {
        GlobalLoader.shared.show()
     //THUserDefaultValue.userDeviceToken ?? ""{
        var tokenDevice = ""
        if let tokenDeviceFinal1 = THUserDefaultValue.userDeviceToken {
            print("Device Token: \(tokenDeviceFinal1)")
            tokenDevice = tokenDeviceFinal1
        }

        let bodyRequest = ContactReferalBody(referalcode: referalcoode)
        THApiHandler.post(requestBody: bodyRequest, responseType: ContactModelResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
            GlobalLoader.shared.hide()
            if let status = dataResponse?.success {

                UserDefaults.standard.set(dataResponse?.data?.accesstoken, forKey: "accessToken")
                THUserDefaultValue.userFirstName = dataResponse?.data?.name
                THUserDefaultValue.phoneNumber   = dataResponse?.data?.phoneNumber
                THUserDefaultValue.userEmail        = dataResponse?.data?.email
                THUserDefaultValue.isUserLoging     = true
                THUserDefaultValue.userReferralCode = dataResponse?.data?.referralCode

                
                self?.hitGuestUserApi()

            } else {
                self?.hostVC.showToastView(message: msg)
            }
        }
    }
    
    private  func hitContactApi(name:String,phoneNo:String,emailId:String,referralCode:String) {
        GlobalLoader.shared.show()
     //THUserDefaultValue.userDeviceToken ?? ""{
        var tokenDevice = ""
        if let tokenDeviceFinal1 = THUserDefaultValue.userDeviceToken {
            print("Device Token: \(tokenDeviceFinal1)")
            tokenDevice = tokenDeviceFinal1
        }
        
//        print("Device Token: \(tokenDeviceFinal)")
////        if tokenDeviceFinal == "" {
////            tokenDeviceFinal = ""
////        }
        
        let bodyRequest = ContactModelBody(name: name, phoneNumber: THconstant.countryCode + phoneNo, email: emailId, deviceType: "ios", deviceToken: tokenDevice, referralCode:referralCode)
        
        print("bodyRequest--\(bodyRequest)")
        THApiHandler.post(requestBody: bodyRequest, responseType: ContactModelResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
            GlobalLoader.shared.hide()
            if let status = dataResponse?.success {

                UserDefaults.standard.set(dataResponse?.data?.accesstoken, forKey: "accessToken")
                THUserDefaultValue.userFirstName = dataResponse?.data?.name
                THUserDefaultValue.phoneNumber   = dataResponse?.data?.phoneNumber
                THUserDefaultValue.userEmail     = dataResponse?.data?.email
                THUserDefaultValue.isUserLoging  = true
                self?.hitGuestUserApi()

                
//                THUserDefaultValue.authToken     = dataResponse?.data.token
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.id
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.phoneNumber
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
               // status ? self?.redirectToHome() : self?.hostVC.showToastView(message: dataResponse?.message ?? "")
            } else {
                if msg == "Invalid referral code" {
                    self?.hostVC.extraFieldNoteLabel.textColor = ConstantColour.orrangecolor
                    self?.hostVC.extraFieldNoteLabel.isHidden = true
                    self?.hostVC.extraFieldNoteLabel.text = msg
                }
                self?.hostVC.showToastView(message: msg)
            }
        }
    }
    
    func hitGuestUserApi() {
     // GlobalLoader.shared.show()
        var tokenDevice = ""
        if let tokenDeviceFinal1 = THUserDefaultValue.authTokenTemp {
            print("Device Token: \(tokenDeviceFinal1)")
            tokenDevice = tokenDeviceFinal1
        }
        
      THUserDefaultValue.authTokenTemp = nil
      let bodyRequest = LoginModelBodySuggestUser(guestId: tokenDevice)
      THApiHandler.post(requestBody: bodyRequest, responseType: GuestMergeResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
          // self?.hostVC.loginBtn.loadingIndicator(false)
          GlobalLoader.shared.hide()

          if let status = dataResponse?.success {
              
              AlertManager.showAlert(on: self!.hostVC,
                                     title: "Success",
                                     message: "Login successfully") {
                  self?.hostVC.dismiss(animated: true, completion: nil)
              }
              self?.hostVC.showToastView(message: dataResponse?.message ?? keyName.backenError)
          } else {
              self?.hostVC.showToastView(message: dataResponse?.message ?? keyName.backenError)
          }
      }
  }
    private func redirectToHome(){
       
          //hostVC.NavigationController(navigateFrom: hostVC, navigateTo: LMTabBarVC(), navigateToString: VcIdentifier.LMTabBarVC)
       // hostVC.NavigationController(navigateFrom: hostVC, navigateTo: LMTabBarVC(), navigateToString: VcIdentifier.LMTabBarVC)
    }
}
