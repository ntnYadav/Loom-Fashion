//
//  ViewController.swift
//  demoBan
//
//  Created by Flucent tech on 06/08/25.
//
import UIKit
import SwiftUI
import SDWebImage
import SVGKit




class LMSimilarVC: UIViewController {
    lazy fileprivate var viewmodel = LMSimilarMV(hostController: self)

        var modelproduct: ProductDataDetail?
        let backgroundView = UIView()
        let containerView = UIView()
        let dismissButton = UIButton()
        let similarProductsLabel = UILabel()
    
        var similarProductsDetail: [SimilarProductdata]?
   // var similarProducts: [SimilarProductdata]?

        let similarProducts = [
            ("BownBee", "₹1,184", "21% OFF"),
            ("VALUE CREATION", "₹599", "85% OFF"),
            ("Little Baby", "₹1,199", "20% OFF")
        ]

        let collectionView: UICollectionView = {
            let layout = UICollectionViewFlowLayout()
            layout.scrollDirection = .horizontal
            layout.itemSize = CGSize(width: 150, height: 320)
            layout.minimumLineSpacing = 12
            return UICollectionView(frame: .zero, collectionViewLayout: layout)
        }()

        override func viewDidLoad() {
            super.viewDidLoad()
            setupUI()
            collectionView.reloadData()
        }

        private func setupUI() {
            view.backgroundColor = .clear

            // Dimmed Background
            backgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
            backgroundView.alpha = 0
            view.addSubview(backgroundView)
            backgroundView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                backgroundView.topAnchor.constraint(equalTo: view.topAnchor),
                backgroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                backgroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                backgroundView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            ])

            // Container View
            containerView.backgroundColor = .white
            containerView.layer.cornerRadius = 20
            containerView.clipsToBounds = true
            view.addSubview(containerView)
            containerView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                containerView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5),
                containerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                containerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                containerView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            ])

            // Header Stack: Label + Close Button in same row
            let headerStack = UIStackView(arrangedSubviews: [similarProductsLabel, dismissButton])
            headerStack.axis = .horizontal
            headerStack.alignment = .center
            headerStack.distribution = .equalSpacing
            containerView.addSubview(headerStack)

            // Configure Label
            similarProductsLabel.text = "Similar Products"
            similarProductsLabel.font = UIFont.boldSystemFont(ofSize: 18)

            // Configure Button
            dismissButton.setTitle("✕", for: .normal)
            dismissButton.setTitleColor(.black, for: .normal)
            dismissButton.titleLabel?.font = UIFont.systemFont(ofSize: 24)
            dismissButton.addTarget(self, action: #selector(dismissSheet), for: .touchUpInside)

            headerStack.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                headerStack.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 16),
                headerStack.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
                headerStack.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16)
            ])

            // Collection View
            collectionView.backgroundColor = .clear
            collectionView.dataSource = self
            collectionView.delegate = self
            collectionView.showsHorizontalScrollIndicator = false
            collectionView.register(UINib(nibName: "ProductDetailCell", bundle: nil), forCellWithReuseIdentifier: "ProductDetailCell")

           // collectionView.register(SimilarProductCell.self, forCellWithReuseIdentifier: "cell")
            containerView.addSubview(collectionView)
            collectionView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                collectionView.topAnchor.constraint(equalTo: headerStack.bottomAnchor, constant: 10),
                collectionView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
                collectionView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
                collectionView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -20)
            ])
        }

        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            showAnimation()
        }

        private func showAnimation() {
            backgroundView.alpha = 0
            containerView.transform = CGAffineTransform(translationX: 0, y: view.frame.height)

            UIView.animate(withDuration: 0.3) {
                self.backgroundView.alpha = 1
                self.containerView.transform = .identity
            }
        }

        @objc private func dismissSheet() {
            UIView.animate(withDuration: 0.3, animations: {
                self.backgroundView.alpha = 0
                self.containerView.transform = CGAffineTransform(translationX: 0, y: self.view.frame.height)
            }) { _ in
                self.dismiss(animated: false)
            }
        }
    }

    // MARK: - Collection View DataSource
    extension LMSimilarVC: UICollectionViewDataSource, UICollectionViewDelegate {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return modelproduct?.similarProducts?.count ?? 0
        }

        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductDetailCell", for: indexPath) as! ProductDetailCell
            let objModel = modelproduct?.similarProducts?[indexPath.row]
            cell.imgProduct.sd_setImage(with: URL(string: objModel?.variantThumbnail?.image ?? ""))
            cell.lblProductName.text = objModel?.title
            cell.lblProductName.font = UIFont(name: "HeroNew-Regular", size: 15)
            cell.lblProductPrice.text = keyName.rupessymbol + " \(objModel?.lowestSellingPrice ?? 0.0)"
            
            
            //                cell.onproductItemTapLike = { [weak self] collectionIndexPath, variantId , color in
            //                    print(collectionIndexPath)
            //                    self?.viewmodel.callWishListAPI(productId: collectionIndexPath, strColor: color, strVaiantId:variantId)
            //
            //                }
            
            cell.btnFavorite.addTarget(self, action: #selector(LMSimilarVC.likeactionSimilar(_:)), for: .touchUpInside)
            
            //        let svgImage:SVGKImage = SVGKImage(named: "ic_heart_empty")
            //        cell.imgLike.image = svgImage.uiImage
            if objModel?.isWishlisted == true {
                cell.imgLike.image = SVGKImage(named: "ic_heart_fill")?.uiImage
            } else {
                cell.imgLike.image = SVGKImage(named: "ic_heart_empty")?.uiImage
            }
            cell.lblrateandReview.layer.cornerRadius = 10
            cell.lblrateandReview.layer.masksToBounds = true
            cell.lblrateandReview.layer.borderWidth = 0.5
            cell.lblrateandReview.layer.borderColor = UIColor.lightGray.cgColor
            cell.lblrateandReview.backgroundColor = UIColor.systemGray6
            cell.lblrateandReview.isHidden = true
            cell.viewraview.isHidden = true

            if objModel?.averageRating != 0 && objModel?.reviewCount != 0 {
                
                if let rating = objModel?.averageRating {
                    cell.lblrateandReview.isHidden = false
                    let formattedRating = rating.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(rating)) : String(rating)
                    if let reviewCount = objModel?.reviewCount {
                        let formattedRating1 = reviewCount.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(reviewCount)) : String(reviewCount)
                        //cell.lblreview.text = "\(formattedRating) "
                        cell.lblrateandReview.text = "     \(formattedRating)  ☆  |  \(formattedRating1)     "
                    } else {
                        cell.lblrateandReview.text = "     \(formattedRating)  ☆     "
                    }
                } else {
                    cell.lblrateandReview.isHidden = false
                }
            }
            cell.btnFavorite.tag = indexPath.row
            
            if objModel?.discountType == "flat" {
                let discount = Int(objModel?.lowestMRP ?? 0) - Int(objModel?.lowestSellingPrice ?? 0)
                
                if discount != 0 {
                    cell.lblDiscountPrice.text = "  ₹ \(discount) OFF!"
                    cell.imgBackground.image = UIImage(named: "red")
                } else {
                    cell.lblDiscountPrice.isHidden = true
                    cell.imgBackground.isHidden = true
                }
                
                //                        let discount = Int(objModel?.lowestMRP ?? 0) - Int(objModel?.lowestSellingPrice ?? 0)
                //
                //
                //                            cell.lblDiscountPrice.text = "  ₹ \(discount) OFF!"
                //                        cell.imgBackground.image = UIImage(named: "red")
            } else {
                cell.imgBackground.image = UIImage(named: "green")
                
                
                if let finalDiscountPercent1 = objModel?.finalDiscountPercent {
                    if finalDiscountPercent1 != 0 {
                        let formatted = String(format: "%.0f", finalDiscountPercent1)  // "10"
                        cell.lblDiscountPrice.text = "  ₹ \(formatted) % OFF!"
                        //cell.lblDiscountPrice.textColor = .white
                        
                    } else {
                        cell.lblDiscountPrice.isHidden = true
                        cell.imgBackground.isHidden = true
                    }
                    
                }
                
                //                        if let finalDiscountPercent1 = objModel?.finalDiscountPercent {
                //                            let formatted = String(format: "%.0f", finalDiscountPercent1)  // "10"
                //                            cell.lblDiscountPrice.text = "  ₹ \(formatted) % OFF!"
                //                        }
            }
            
            
            cell.lblCount.isHidden = true

            if let colorcode = objModel?.colorPreview?.count {
                    if 3 < colorcode {
                        cell.lblCount.isHidden = false
                        if let countlavbel = objModel?.totalColorCount {
                            cell.lblCount.text = "+ \((countlavbel - 3))"
                        }
                    }
                    if colorcode == 1 {
                        let uiColor = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? "")
                        if let lowercaseString = objModel?.colorPreview?[0].lowercased() {
                            if lowercaseString == "white" {
                                cell.lbl1.layer.borderColor = UIColor.black.cgColor
                                cell.lbl1.layer.borderWidth = 1
                            }
                        }
                        cell.lbl1.backgroundColor = uiColor
                        cell.lbl2.isHidden = true
                        cell.lbl3.isHidden = true

                    } else if colorcode == 2 {
                        let uiColor  = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? "")
                        let uiColor1 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[1] ?? "")
                        if let lowercaseString = objModel?.colorPreview?[0].lowercased() {
                            if lowercaseString == "white" {
                                cell.lbl1.layer.borderColor = UIColor.black.cgColor
                                cell.lbl1.layer.borderWidth = 1
                            }
                        }
                        if let lowercaseString = objModel?.colorPreview?[1].lowercased() {
                            if lowercaseString == "white" {
                                cell.lbl2.layer.borderColor = UIColor.black.cgColor
                                cell.lbl2.layer.borderWidth = 1
                            }
                        }
                        cell.lbl1.backgroundColor = uiColor
                        cell.lbl2.backgroundColor = uiColor1
                        cell.lbl3.isHidden = true
                    } else {
                        let uiColor  = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? "")
                        let uiColor1 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[1] ?? "")
                        let uiColor2 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[2] ?? "")
                        
                        if let lowercaseString = objModel?.colorPreview?[0].lowercased() {
                            if lowercaseString == "white" {
                                cell.lbl1.layer.borderColor = UIColor.black.cgColor
                                cell.lbl1.layer.borderWidth = 1
                            }
                        }
                        if let lowercaseString = objModel?.colorPreview?[1].lowercased() {
                            if lowercaseString == "white" {
                                cell.lbl2.layer.borderColor = UIColor.black.cgColor
                                cell.lbl2.layer.borderWidth = 1
                            }
                        }
                        if let lowercaseString = objModel?.colorPreview?[2].lowercased() {
                            if lowercaseString == "white" {
                                cell.lbl3.layer.borderColor = UIColor.black.cgColor
                                cell.lbl3.layer.borderWidth = 1
                            }
                        }
                        
                        cell.lbl1.backgroundColor = uiColor
                        cell.lbl2.backgroundColor = uiColor1
                        cell.lbl3.backgroundColor = uiColor2
                    }
                }
                
            return cell
        }
        @objc func likeactionSimilar(_ sender : UIButton) {
            let tag = sender.tag
            var objModel = modelproduct?.similarProducts?[tag]
            //var objModel = productsdetail[tag]
            if objModel?.isWishlisted == nil {
                modelproduct?.similarProducts?[tag].isWishlisted = true

                objModel?.isWishlisted = true
            } else {
                if objModel?.isWishlisted == false {
                    modelproduct?.similarProducts?[tag].isWishlisted = true

                    objModel?.isWishlisted = true
                } else {
                    modelproduct?.similarProducts?[tag].isWishlisted = false

                    objModel?.isWishlisted = false
                }
            }
            collectionView.reloadData()
            self.viewmodel.callWishListAPI(productId: objModel?._id ?? "", strColor: objModel?.variantThumbnail?.variantId ?? "", strVaiantId:objModel?.variantThumbnail?.variantId ?? "")
          //  onproductItemTapLike?(objModel._id ?? "", objModel.variantThumbnail?.variantId ?? "", objModel.variantThumbnail?.color ?? "")

        }
    }

    // MARK: - Custom Cell
    class SimilarProductCell: UICollectionViewCell {
        let imageView = UIImageView()
        let nameLabel = UILabel()
        let priceLabel = UILabel()
        let discountLabel = UILabel()
        let addButton = UIButton()

        override init(frame: CGRect) {
            super.init(frame: frame)
            setup()
        }

        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }

        func configure(name: String, price: String, discount: String) {
            nameLabel.text = name
            priceLabel.text = price
            discountLabel.text = discount
        }
       
        private func setup() {
            imageView.image = UIImage(named: "imgg") // replace with real images
            imageView.backgroundColor = UIColor.systemGray5
            imageView.contentMode = .scaleAspectFill
            imageView.layer.cornerRadius = 8
            imageView.clipsToBounds = true

            nameLabel.font = UIFont.systemFont(ofSize: 14)
            nameLabel.numberOfLines = 2

            priceLabel.font = UIFont.boldSystemFont(ofSize: 14)
            discountLabel.font = UIFont.systemFont(ofSize: 12)
            discountLabel.textColor = .red

            addButton.setTitle("Add to Bag", for: .normal)
            addButton.setTitleColor(.systemPink, for: .normal)
            addButton.titleLabel?.font = UIFont.systemFont(ofSize: 13)
            addButton.layer.borderColor = UIColor.systemPink.cgColor
            addButton.layer.borderWidth = 1
            addButton.layer.cornerRadius = 5

            let stack = UIStackView(arrangedSubviews: [imageView, nameLabel, priceLabel, discountLabel, addButton])
            stack.axis = .vertical
            stack.spacing = 4
            contentView.addSubview(stack)

            stack.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                stack.topAnchor.constraint(equalTo: contentView.topAnchor),
                stack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
                stack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
                stack.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor)
            ])

            imageView.heightAnchor.constraint(equalToConstant: 200).isActive = true
        }
    }
