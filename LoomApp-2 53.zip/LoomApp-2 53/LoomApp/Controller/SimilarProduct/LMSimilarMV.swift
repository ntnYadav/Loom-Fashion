//
//  LMAddressMV.swift
//  LoomApp
//
//  Created by Flucent tech on 30/04/25.


import Foundation
import UIKit
import Toast_Swift


class LMSimilarMV : NSObject{
    var modelCoupon : PromoData?
    var modelproduct : ProductDataDetail?
    var modelCategory : ResponseData?
    var modelReview: [Review] = []
    var customerImages: [CustomerImageDetail] = []
    var sizeArrayTemp: [String]?

    
    private var hostVC : LMSimilarVC
    init(hostController : LMSimilarVC) {
        self.hostVC = hostController
    }
    
    // MARK: validate value
    
    
   
    func callWishListAPI(productId:String,strColor:String,strVaiantId:String) {
        GlobalLoader.shared.show()
        
        let bodyRequest = wishlist(productId:productId, color:strColor.capitalizedFirstLetter, variantId: strVaiantId)
        //cartParameter(productId:productId, variantId:variantId,quantity: qty)
        THApiHandler.post(requestBody: bodyRequest, responseType: WishlistResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
            GlobalLoader.shared.hide()
            if let status = dataResponse?.success {
//                let deleteSheet = LMCartPop()
//                deleteSheet.modalPresentationStyle = .overFullScreen
//                deleteSheet.modalTransitionStyle = .coverVertical
//                self?.hostVC.present(deleteSheet, animated: true)
            } else {
                self?.hostVC.showToastView(message: msg)
            }
        }
    }
    
    
    
   
    
    // MARK: validate value
    func validatePincodeValue(Pincode:String,weight:Double,height:Double,breadth:Double,length:Double){
        guard hostVC.checkInternet else {
            return
        }
        GlobalLoader.shared.show()
        let bodyRequest = deliveryPincodeReq12(deliveryPincode: Int(Pincode) ?? 0, weight: 5.2, height: Double(height), breadth: Double(breadth), length: Double(length))
        
            THApiHandler.post(requestBody: bodyRequest, responseType: DeliveryEstimateResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
                GlobalLoader.shared.hide()
                if let status = dataResponse?.success {
                    let mod = dataResponse?.data
                    self?.hostVC.dismiss(animated: true) {
                        let formatter = DateFormatter()
                        formatter.dateFormat = "yyyy-MM-dd"
                        let currentDateString = formatter.string(from: Date())
                        
                        THUserDefaultValue.userdateCurrentDate = currentDateString
                        
                        THUserDefaultValue.userdateDays   = mod?.estimatedDeliveryDays ?? ""

                        THUserDefaultValue.userdatefrmate = mod?.expectedDeliveryDate ?? ""
                        //self?.hostVC.onApplyTapped?(Pincode,[""])
                        THUserDefaultValue.isUserPincodeLoging = true
                                      }
                   // self?.hostVC.showToastView(message: dataResponse?.message ?? "")
                } else {
                    
                    //self?.hostVC.infoLabel.text = "Pincode is not serviceable"
                }
            }
        
        
    }
    
}
