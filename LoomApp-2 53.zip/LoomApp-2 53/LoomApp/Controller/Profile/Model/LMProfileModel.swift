//
//  LMAddressModel.swift
//  LoomApp
//
//  Created by Flucent tech on 30/04/25.
//

import Foundation


struct UserResponse: Codable {
    let success: Bool?
    let message: String?
    let data: Userprofile?
}

struct Userprofile: Codable {
    let id: String?
    let name: String?
    let email: String?
    let phoneNumber: String?
    let dob: String?
    let anniversary: String?
    let gender: String?
    let stylePreference: [String]?
    let addresses: [String]?
    let searches: [String]?
    let isBlocked: Bool?
    let isDeleted: Bool?
    let deviceType: String?
    let accesstoken: String?
    let amountSpent: String?
    let orderCount: String?
    let loyaltyPoints: Int?
    let isEmailVerified: Bool?
    let isPhoneVerified: Bool?
    let deviceToken: String?
    let devices: [UserDevicedata]?
    let loginCount: Int?
    let totalTimeSpent: Int?
    let averageTimeSpent: Int?
    let createdAt: String?
    let updatedAt: String?
    let referralCode: String?

    
    // Map "_id" to "id"
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case name, email, phoneNumber, dob, anniversary, gender
        case stylePreference = "style_preference"
        case addresses, searches, isBlocked, isDeleted, deviceType
        case accesstoken, amountSpent, orderCount, loyaltyPoints
        case isEmailVerified, isPhoneVerified, deviceToken, devices
        case loginCount, totalTimeSpent, averageTimeSpent, createdAt, updatedAt, referralCode
    }
}

struct UserDevicedata: Codable {
    let deviceToken: String?
    let deviceType: String?
    let browserName: String?
    let lastLoggedIn: String?
    let id: String?

    enum CodingKeys: String, CodingKey {
        case deviceToken, deviceType, browserName, lastLoggedIn
        case id = "_id"
    }
}



//////
///
///    private  func callUpdateApi(name:String,phoneNo:String,email:String,dob:String,anniversary:String,gender:String,style:String) {

struct ProfileUpdate: Codable {
let dob: String?
let anniversary: String?
let gender: String?
let style_preference:[String]?
}
////Upsdate profile
///

struct UserProfileResponse: Codable {
    let success: Bool?
    let message: String?
    let data: UserProfile?
}

struct UserProfile: Codable {
    let id: String?
    let name: String?
    let email: String?
    let phoneNumber: String?
    let stylePreference: [String]?
    let addresses: [String]?
    let searches: [String]?
    let isBlocked: Bool?
    let deviceType: String?
    let deviceToken: String?
    let loginCount: Int?
    let totalTimeSpent: Int?
    let averageTimeSpent: Int?
    let createdAt: String?
    let updatedAt: String?
    let accesstoken: String?
    let dob: String?
    let anniversary: String?
    let gender: String?

    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case name, email, phoneNumber, stylePreference = "style_preference"
        case addresses, searches, isBlocked, deviceType, deviceToken
        case loginCount, totalTimeSpent, averageTimeSpent
        case createdAt, updatedAt, accesstoken, dob, anniversary, gender
    }
}

