//
//  userDatamodel.swift
//  OrderDetailsDemo
//
//  Created by Abdul Quadir on 16/07/25.
//

import Foundation
struct AddressUserDataResponse {
    var name: String
    var address: String
    var city: String
    var phone: String
}
