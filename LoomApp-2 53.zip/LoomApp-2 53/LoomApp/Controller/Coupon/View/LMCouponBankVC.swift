import UIKit

// MARK: - Model
struct Coupon {
    let offerPrice: String
    let description: String
    let code: String
}

// MARK: - View Controller
class CouponsViewController: UIViewController, UITableViewDataSource {
    private let tableView = UITableView()
    var couponarr:[Couponinitial] = []

    private let coupons: [Coupon] = [
        Coupon(offerPrice: "₹396", description: "Get 20% off on Minimum purchase of Rs. 1500", code: "AJIOGRAM20"),
        Coupon(offerPrice: "₹445", description: "Get 10% off on Minimum purchase of Rs. 1200", code: "AJIOGRAM10"),
        Coupon(offerPrice: "₹494", description: "Special offer for frequent shoppers", code: "AJIOSHOP")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Coupons"
        view.backgroundColor = .systemBackground
        setupTableView()
        setupTableHeader()
    }
    
    private func setupTableView() {
        tableView.dataSource = self
        tableView.register(CouponBankDetailCell.self, forCellReuseIdentifier: CouponBankDetailCell.identifier)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100
        view.addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    // MARK: - Table Header with Header + Apply Coupon View
    private func setupTableHeader() {
        let containerView = UIView()
        containerView.backgroundColor = .systemBackground

        // === Header View ===
        let headerView = UIView()
        headerView.backgroundColor = .systemBackground

        let imageView = UIImageView()
        imageView.image = UIImage(systemName: "tag")
        imageView.tintColor = .systemGreen
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.widthAnchor.constraint(equalToConstant: 24).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: 24).isActive = true

        let titleLabel = UILabel()
    
        titleLabel.text = AppDelegate.shared.headertitle
        titleLabel.font = UIFont.boldSystemFont(ofSize: 20)
        titleLabel.textColor = .label

        let cancelButton = UIButton(type: .system)
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.setTitleColor(.systemRed, for: .normal)
        cancelButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        cancelButton.addTarget(self, action: #selector(cancelButtonTapped), for: .touchUpInside)

        let leftStack = UIStackView(arrangedSubviews: [imageView, titleLabel])
        leftStack.axis = .horizontal
        leftStack.spacing = 8
        leftStack.alignment = .center

        let mainStack = UIStackView(arrangedSubviews: [leftStack, UIView(), cancelButton])
        mainStack.axis = .horizontal
        mainStack.alignment = .center
        mainStack.spacing = 8
        mainStack.translatesAutoresizingMaskIntoConstraints = false

        headerView.addSubview(mainStack)
        headerView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            mainStack.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 16),
            mainStack.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -16),
            mainStack.topAnchor.constraint(equalTo: headerView.topAnchor),
            mainStack.bottomAnchor.constraint(equalTo: headerView.bottomAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 60)
        ])

        // === Apply Coupon View ===
        let applyCouponView = UIView()
        applyCouponView.isHidden = true
        applyCouponView.layer.borderWidth = 1
        applyCouponView.layer.borderColor = UIColor.systemGray4.cgColor
        applyCouponView.layer.cornerRadius = 8
        applyCouponView.backgroundColor = .systemBackground
        applyCouponView.translatesAutoresizingMaskIntoConstraints = false

        let couponTextField = UITextField()
        couponTextField.placeholder = "Enter coupon code"
        couponTextField.borderStyle = .roundedRect
        couponTextField.translatesAutoresizingMaskIntoConstraints = false

        let applyButton = UIButton(type: .system)
        applyButton.setTitle("Apply", for: .normal)
        applyButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        applyButton.backgroundColor = .black
        applyButton.tintColor = .white
        applyButton.layer.cornerRadius = 6
        applyButton.translatesAutoresizingMaskIntoConstraints = false
        applyButton.contentEdgeInsets = UIEdgeInsets(top: 10, left: 20, bottom: 10, right: 20)

        applyCouponView.addSubview(couponTextField)
        applyCouponView.addSubview(applyButton)

        NSLayoutConstraint.activate([
            couponTextField.leadingAnchor.constraint(equalTo: applyCouponView.leadingAnchor, constant: 16),
            couponTextField.centerYAnchor.constraint(equalTo: applyCouponView.centerYAnchor),
            couponTextField.heightAnchor.constraint(equalToConstant: 0),

            applyButton.leadingAnchor.constraint(equalTo: couponTextField.trailingAnchor, constant: 12),
            applyButton.trailingAnchor.constraint(equalTo: applyCouponView.trailingAnchor, constant: -16),
            applyButton.centerYAnchor.constraint(equalTo: applyCouponView.centerYAnchor),
            applyButton.heightAnchor.constraint(equalToConstant: 36),

            couponTextField.widthAnchor.constraint(greaterThanOrEqualToConstant: 150),
            applyButton.widthAnchor.constraint(greaterThanOrEqualToConstant: 70)
        ])

        // === Wrap applyCouponView in padding container ===
        let applyCouponWrapper = UIView()
        applyCouponWrapper.translatesAutoresizingMaskIntoConstraints = false
        applyCouponWrapper.addSubview(applyCouponView)

        NSLayoutConstraint.activate([
            applyCouponView.leadingAnchor.constraint(equalTo: applyCouponWrapper.leadingAnchor, constant: 16),
            applyCouponView.trailingAnchor.constraint(equalTo: applyCouponWrapper.trailingAnchor, constant: -16),
            applyCouponView.topAnchor.constraint(equalTo: applyCouponWrapper.topAnchor),
            applyCouponView.bottomAnchor.constraint(equalTo: applyCouponWrapper.bottomAnchor)
        ])

        // === Stack Views ===
        let containerStack = UIStackView(arrangedSubviews: [headerView, applyCouponWrapper])
        containerStack.axis = .vertical
        containerStack.spacing = 12
        containerStack.translatesAutoresizingMaskIntoConstraints = false

        containerView.addSubview(containerStack)

        NSLayoutConstraint.activate([
            containerStack.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 8),
            containerStack.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            containerStack.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            containerStack.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -8)
        ])

        // === Set table header view height ===
        let totalHeight: CGFloat = 60 + 0 + 0 // header + apply + spacing
        containerView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: totalHeight)

        tableView.tableHeaderView = containerView
    }

//    private func setupTableHeader() {
//        // Container for both header and apply coupon views
//        let containerView = UIView()
//        containerView.backgroundColor = .systemBackground
//        
//        // === Existing Header View (icon + title + cancel) ===
//        let headerView = UIView()
//        headerView.backgroundColor = .systemBackground
//        
//        let imageView = UIImageView()
//        imageView.image = UIImage(systemName: "tag")
//        imageView.tintColor = .systemGreen
//        imageView.contentMode = .scaleAspectFit
//        imageView.translatesAutoresizingMaskIntoConstraints = false
//        imageView.widthAnchor.constraint(equalToConstant: 24).isActive = true
//        imageView.heightAnchor.constraint(equalToConstant: 24).isActive = true
//
//        let titleLabel = UILabel()
//        titleLabel.text = "Available Coupons"
//        titleLabel.font = UIFont.boldSystemFont(ofSize: 20)
//        titleLabel.textColor = .label
//
//        let cancelButton = UIButton(type: .system)
//        cancelButton.setTitle("Cancel", for: .normal)
//        cancelButton.setTitleColor(.systemRed, for: .normal)
//        cancelButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
//        cancelButton.addTarget(self, action: #selector(cancelButtonTapped), for: .touchUpInside)
//
//        let leftStack = UIStackView(arrangedSubviews: [imageView, titleLabel])
//        leftStack.axis = .horizontal
//        leftStack.spacing = 8
//        leftStack.alignment = .center
//
//        let mainStack = UIStackView(arrangedSubviews: [leftStack, UIView(), cancelButton])
//        mainStack.axis = .horizontal
//        mainStack.alignment = .center
//        mainStack.spacing = 8
//        mainStack.translatesAutoresizingMaskIntoConstraints = false
//        
//        headerView.addSubview(mainStack)
//        
//        NSLayoutConstraint.activate([
//            mainStack.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 16),
//            mainStack.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -16),
//            mainStack.topAnchor.constraint(equalTo: headerView.topAnchor),
//            mainStack.bottomAnchor.constraint(equalTo: headerView.bottomAnchor),
//            headerView.heightAnchor.constraint(equalToConstant: 60)
//        ])
//        
//        headerView.translatesAutoresizingMaskIntoConstraints = false
//
//        // === New Apply Coupon View ===
//        let applyCouponView = UIView()
//        applyCouponView.layer.borderWidth = 1
//        applyCouponView.layer.borderColor = UIColor.systemGray4.cgColor
//        applyCouponView.layer.cornerRadius = 8
//        applyCouponView.backgroundColor = .systemBackground
//        applyCouponView.translatesAutoresizingMaskIntoConstraints = false
//
//        let couponTextField = UITextField()
//        couponTextField.placeholder = "Enter coupon code"
//        couponTextField.borderStyle = .roundedRect
//        couponTextField.translatesAutoresizingMaskIntoConstraints = false
//
//        let applyButton = UIButton(type: .system)
//        applyButton.setTitle("Apply", for: .normal)
//        applyButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
//        applyButton.backgroundColor = .black
//        applyButton.tintColor = .white
//        applyButton.layer.cornerRadius = 6
//        applyButton.translatesAutoresizingMaskIntoConstraints = false
//        applyButton.contentEdgeInsets = UIEdgeInsets(top: 10, left: 20, bottom: 10, right: 20)
//        // Add target if you want action:
//        // applyButton.addTarget(self, action: #selector(applyButtonTapped), for: .touchUpInside)
//
//        applyCouponView.addSubview(couponTextField)
//        applyCouponView.addSubview(applyButton)
//
//        NSLayoutConstraint.activate([
//           // applyCouponView.leadingAnchor.constraint(equalTo: applyCouponView.leadingAnchor, constant: 16),
//
//                couponTextField.leadingAnchor.constraint(equalTo: applyCouponView.leadingAnchor, constant: 2),
//                couponTextField.centerYAnchor.constraint(equalTo: applyCouponView.centerYAnchor),
//                couponTextField.heightAnchor.constraint(equalToConstant: 36),
//
//                
//                applyButton.leadingAnchor.constraint(equalTo: couponTextField.trailingAnchor, constant: 2),
//                applyButton.trailingAnchor.constraint(equalTo: applyCouponView.trailingAnchor, constant: -16),
//                applyButton.centerYAnchor.constraint(equalTo: applyCouponView.centerYAnchor),
//                applyButton.heightAnchor.constraint(equalToConstant: 36),
//
//                couponTextField.widthAnchor.constraint(greaterThanOrEqualToConstant: 150),
//                applyButton.widthAnchor.constraint(greaterThanOrEqualToConstant: 40)
//            ])
////        NSLayoutConstraint.activate([
////            couponTextField.leadingAnchor.constraint(equalTo: applyCouponView.leadingAnchor, constant: 16),
////            couponTextField.centerYAnchor.constraint(equalTo: applyCouponView.centerYAnchor),
////            couponTextField.heightAnchor.constraint(equalToConstant: 36),
////            
////            applyButton.leadingAnchor.constraint(equalTo: couponTextField.trailingAnchor, constant: 12),
////            applyButton.trailingAnchor.constraint(equalTo: applyCouponView.trailingAnchor, constant: -16),
////            applyButton.centerYAnchor.constraint(equalTo: applyCouponView.centerYAnchor),
////            applyButton.heightAnchor.constraint(equalToConstant: 36),
////
////            couponTextField.widthAnchor.constraint(greaterThanOrEqualToConstant: 150),
////            applyButton.widthAnchor.constraint(greaterThanOrEqualToConstant: 70)
////            
////            
//////            applyCouponView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
//////            applyCouponView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
////            
////        ])
//
//        
////        NSLayoutConstraint.activate([
////            couponTextField.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 8),
////            couponTextField.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),  // no padding here, full width stack
////            couponTextField.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
////
////            couponTextField.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -8),
////
////            // Add horizontal padding only for applyCouponView inside the stack:
////            applyCouponView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
////            applyCouponView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
////        ])
////        
//        // === Stack the header and applyCouponView vertically ===
//        let containerStack = UIStackView(arrangedSubviews: [headerView, applyCouponView])
//        containerStack.axis = .vertical
//        containerStack.spacing = 12
//        containerStack.translatesAutoresizingMaskIntoConstraints = false
//
//        containerView.addSubview(containerStack)
//
//        NSLayoutConstraint.activate([
//            containerStack.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 8),
//            containerStack.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 8),
//            containerStack.trailingAnchor.constraint(equalTo: containerView.trailingAnchor,constant:  16),
////            containerStack.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
//            containerStack.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -8)
//        ])
//
//        // Calculate total height and set frame (important for tableHeaderView)
//        let totalHeight: CGFloat = 60 /*header*/ + 50 /*applyCouponView approx*/ + 20 /*spacing and padding*/
//        containerView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: totalHeight)
//
//        tableView.tableHeaderView = containerView
//    }
    
    // MARK: - Table Data Source
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return couponarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CouponBankDetailCell.identifier, for: indexPath) as! CouponBankDetailCell
        
        cell.selectionStyle = .none // or .blue, etc.

        let obj = couponarr[indexPath.row]
//        cell.lblOffer.text    = obj.name
//        cell.lblDescribe.text = obj.name
       
        if let potPrice = obj.potentialFinalPrice {
            let potentialFinalPrice = String(format: "%.0f", potPrice)

            cell.offerPriceLabel.text    = "Offer Price " + " \(keyName.rupessymbol)" + " \(potentialFinalPrice)" //obj.name
        }
        
        //cell.offerPriceLabel.text = obj.name
        if  let couponcode = obj.code {
            cell.couponCodeLabel.text   = "  \(couponcode)  "
        }
       // cell.couponCodeLabel.text = coupon.code
        
        // Setup attributed string with tappable "T&C" inside description (optional)
        cell.descriptionLabel.text = obj.description
        
      //  cell.configure(with: coupons[indexPath.row])
        return cell
    }
    
    @objc private func cancelButtonTapped() {
        // Dismiss or navigate back
        self.dismiss(animated: true, completion: nil)
        // Or: navigationController?.popViewController(animated: true)
    }
    
    // Uncomment and implement if you want apply button action
    /*
    @objc private func applyButtonTapped() {
        print("Apply button tapped!")
        // Your logic here...
    }
    */
}

// MARK: - Custom Cell
class CouponBankDetailCell: UITableViewCell {
    
    static let identifier = "CouponBankDetailCell"
    
    private var tappableRange: NSRange?
    private var dashedBorder: CAShapeLayer?

    
    override func layoutSubviews() {
        super.layoutSubviews()
        couponCodeLabel.font = UIFont(name: ConstantFontSize.regular, size: 12)
       

        applyDashedBorderToLabel()
        

    }

    private func applyDashedBorderToLabel() {
        // Remove existing dashed border
        couponCodeLabel.layer.sublayers?
            .filter { $0.name == "dashedBorder" }
            .forEach { $0.removeFromSuperlayer() }

        let dashBorder = CAShapeLayer()
        dashBorder.name = "dashedBorder"
        dashBorder.strokeColor = UIColor.black.cgColor
        dashBorder.lineDashPattern = [4, 4]
        dashBorder.fillColor = nil
        dashBorder.lineWidth = 1
        dashBorder.frame = couponCodeLabel.bounds
        dashBorder.path = UIBezierPath(rect: couponCodeLabel.bounds).cgPath

        couponCodeLabel.layer.addSublayer(dashBorder)
    }
    
    
    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .systemBackground
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.systemGray4.cgColor
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
     let offerPriceLabel: UILabel = {
        let label = UILabel()
        label.textColor = .systemGreen
        label.font = UIFont.boldSystemFont(ofSize: 16)
        return label
    }()
    
     let descriptionLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = .darkGray
        label.numberOfLines = 0
        label.isUserInteractionEnabled = true  // Enable tap interaction
        return label
    }()
    
     let couponCodeLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.monospacedDigitSystemFont(ofSize: 14, weight: .medium)
        label.backgroundColor = UIColor(red: 226/255, green: 246/255, blue: 233/255, alpha: 1.0)
        label.textAlignment = .center
        return label
    }()
    
    private let termsButton: UIButton = {
        let button = UIButton(type: .system)
        if AppDelegate.shared.headertitle == "Coupon" {
            button.contentHorizontalAlignment = .left // Align text to left
        } else {
            button.contentHorizontalAlignment = .left // Align text to left
        }
        button.setTitle("T&C", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        return button
    }()
    
    private let stackView = UIStackView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        contentView.addSubview(containerView)
        
        // Setup stack view
        stackView.axis = .vertical
        stackView.spacing = 8
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        containerView.addSubview(stackView)
        
        stackView.addArrangedSubview(offerPriceLabel)
        stackView.addArrangedSubview(descriptionLabel)
        
        if AppDelegate.shared.headertitle == "Coupon" {
            let codeRow = UIStackView(arrangedSubviews: [couponCodeLabel, UIView(), termsButton])
            codeRow.axis = .horizontal
            codeRow.spacing = 10
            stackView.addArrangedSubview(codeRow)
        } else {
            let codeRow = UIStackView(arrangedSubviews: [termsButton])
            codeRow.axis = .horizontal
            codeRow.spacing = 10
            stackView.addArrangedSubview(codeRow)
        }
        
        // Constraints
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),
            
            stackView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 12),
            stackView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 12),
            stackView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -12),
            stackView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -12),
            
            couponCodeLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 100)
        ])
        
        // Add tap gesture recognizer to descriptionLabel
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTapOnLabel(_:)))
        descriptionLabel.addGestureRecognizer(tapGesture)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func configure(with coupon: Coupon) {
        offerPriceLabel.text = coupon.offerPrice
        couponCodeLabel.text = coupon.code
        
        // Setup attributed string with tappable "T&C" inside description (optional)
        descriptionLabel.text = coupon.description
        // You can enhance with tappable text as before if you want
    }
    
    @objc private func handleTapOnLabel(_ gesture: UITapGestureRecognizer) {
        // Handle tap if you want tappable "T&C" inside description label
    }
}
