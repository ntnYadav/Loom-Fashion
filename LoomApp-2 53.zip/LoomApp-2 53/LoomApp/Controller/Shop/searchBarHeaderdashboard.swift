//
//  CustomHeaderView.swift
//  CollectionView-Header-Footer-Sample
//
//  Created by kawaharadai on 2019/05/02.
//  Copyright © 2019 kawaharadai. All rights reserved.
//

import UIKit

class searchBarHeaderdashboard: UICollectionViewCell {
    @IBOutlet weak var lblHeader1: UILabel!
   
}
