//
//  ViewController.swift
//  photos
//
//  Created by Flucent tech on 26/07/25.
//

import UIKit
import SDWebImage
import UIKit
import SDWebImage


class LMProductdetailsPhotos: UIViewController {
    var images: [String]? = nil
    var flagNavigation = ""
    var modelproduct : ProductDataDetail?
    var startIndex: Int = 0
    var productId: String = ""
    //var viewModel: LMReviewClickPhotosMV?
  //  lazy fileprivate var viewModel = LMReviewClickPhotosMV(hostController: self)

    private var isLoadingMore = false
    private var currentPage = 1
    private let limit = 10

    private let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0

        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.isPagingEnabled = true
        cv.showsHorizontalScrollIndicator = false
        cv.backgroundColor = .black
        return cv
    }()

    private let cancelButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "xmark"), for: .normal)
        button.tintColor = .white
        button.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        button.layer.cornerRadius = 15
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let leftButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        button.tintColor = .white
        button.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        button.layer.cornerRadius = 20
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let rightButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "chevron.right"), for: .normal)
        button.tintColor = .white
        button.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        button.layer.cornerRadius = 20
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupCollectionView()
        setupCancelButton()
        setupNavButtons()

        collectionView.register(ReviewImageCell1.self, forCellWithReuseIdentifier: "ReviewImageCell1")

        DispatchQueue.main.async {
            let indexPath = IndexPath(item: self.startIndex, section: 0)
            self.collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
        }
    }

    private func setupCollectionView() {
        view.addSubview(collectionView)
        collectionView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        collectionView.delegate = self
        collectionView.dataSource = self
    }

    private func setupCancelButton() {
        view.addSubview(cancelButton)
        NSLayoutConstraint.activate([
            cancelButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            cancelButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            cancelButton.widthAnchor.constraint(equalToConstant: 30),
            cancelButton.heightAnchor.constraint(equalToConstant: 30)
        ])
        cancelButton.addTarget(self, action: #selector(didTapCancel), for: .touchUpInside)
    }

    private func setupNavButtons() {
        view.addSubview(leftButton)
        view.addSubview(rightButton)

        NSLayoutConstraint.activate([
            leftButton.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            leftButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            leftButton.widthAnchor.constraint(equalToConstant: 40),
            leftButton.heightAnchor.constraint(equalToConstant: 40),

            rightButton.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            rightButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            rightButton.widthAnchor.constraint(equalToConstant: 40),
            rightButton.heightAnchor.constraint(equalToConstant: 40),
        ])

        leftButton.addTarget(self, action: #selector(didTapLeft), for: .touchUpInside)
        rightButton.addTarget(self, action: #selector(didTapRight), for: .touchUpInside)
    }

    @objc private func didTapCancel() {
        dismiss(animated: true, completion: nil)
    }

    @objc private func didTapLeft() {
        guard let images = modelproduct?.variants?[0].images, !images.isEmpty else { return }
        
        let visibleIndex = Int(collectionView.contentOffset.x / collectionView.bounds.width)
        let previousIndex = max(visibleIndex - 1, 0)
        
        collectionView.scrollToItem(at: IndexPath(item: previousIndex, section: 0), at: .centeredHorizontally, animated: true)
    }

    @objc private func didTapRight() {
        guard let images = modelproduct?.variants?[0].images else { return }
        let count = images.count
        let visibleIndex = Int(collectionView.contentOffset.x / collectionView.bounds.width)
        let nextIndex = min(visibleIndex + 1, count - 1)
        collectionView.scrollToItem(at: IndexPath(item: nextIndex, section: 0), at: .centeredHorizontally, animated: true)
    }

    func reloadDataAfterAppending() {
        collectionView.reloadData()
        isLoadingMore = false
    }

    private func loadMoreDataIfNeeded() {
        guard !isLoadingMore else { return }
        isLoadingMore = true
        currentPage += 1
    }
}

// MARK: - UICollectionViewDelegate & DataSource

extension LMProductdetailsPhotos: UICollectionViewDelegate, UICollectionViewDataSource, UIScrollViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return modelproduct?.variants?[0].images?.count ?? 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ReviewImageCell1", for: indexPath) as? ReviewImageCell1 else {
            return UICollectionViewCell()
        }
        cell.bottomView.isHidden = true
       // if flagNavigation == "FullData" {
        let obj = modelproduct?.variants?[0].images?[indexPath.row]
            cell.setdata()
            cell.nameLabel.isHidden = true
            cell.commentLabel.isHidden = true
            cell.ratingLabel.isHidden = true
           // cell.configure(with: obj.url)
       // } else {
        cell.configure(with: obj)
       // }

        return cell
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard let total = modelproduct?.variants?[0].images?.count, total > 0 else {
            leftButton.isHidden = true
            rightButton.isHidden = true
            return
        }

        let index = Int(round(collectionView.contentOffset.x / collectionView.bounds.width))

        leftButton.isHidden = index == 0
        rightButton.isHidden = index == total - 1
    }
}

// ✅ Rename ImageCell1 to ImageCell
//class ImageCell: UICollectionViewCell {
class ReviewImageCell1: UICollectionViewCell {

    let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

     let bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

     let ratingLabel = UILabel()
     let nameLabel = UILabel()
     let verifiedLabel = UILabel()
     let likeIcon = UIImageView()
     let likeLabel = UILabel()
     let commentLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imageView)
        contentView.addSubview(bottomView)

        setupImageConstraints()
        
      
    }

    func setdata() {
             setupBottomView()
        
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupImageConstraints() {
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
        ])
    }

    private func setupBottomView() {
        // Add subviews
        [ratingLabel, nameLabel, verifiedLabel, likeIcon, likeLabel, commentLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            bottomView.addSubview($0)
        }

        // Layout bottom view
        NSLayoutConstraint.activate([
            bottomView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            bottomView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            bottomView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            bottomView.heightAnchor.constraint(equalToConstant: 120)
        ])

        // Configure and constrain inner elements
        ratingLabel.text = "5 ★"
        ratingLabel.textColor = .white
        ratingLabel.font = UIFont.boldSystemFont(ofSize: 14)
        ratingLabel.backgroundColor = .black
        ratingLabel.textAlignment = .center
        ratingLabel.layer.cornerRadius = 4
        ratingLabel.clipsToBounds = true

        nameLabel.text = "Mayur"
        nameLabel.textColor = .white
        nameLabel.font = UIFont.boldSystemFont(ofSize: 14)

        verifiedLabel.text = "Verified User"
        verifiedLabel.isHidden = true
        verifiedLabel.textColor = .systemOrange
        verifiedLabel.font = UIFont.systemFont(ofSize: 13)

        likeIcon.image = UIImage(systemName: "hand.thumbsup")
        likeIcon.tintColor = .white
        likeIcon.isHidden = true

        likeLabel.text = "146"
        likeLabel.isHidden = true

        likeLabel.textColor = .white
        likeLabel.font = UIFont.systemFont(ofSize: 14)

        commentLabel.text = "Superb quality, perfect fitting, love the colour 😊👌🏻"
        commentLabel.textColor = .white
        commentLabel.font = UIFont.systemFont(ofSize: 13)
        commentLabel.numberOfLines = 0

        // Constraints
        NSLayoutConstraint.activate([
            ratingLabel.leadingAnchor.constraint(equalTo: bottomView.leadingAnchor, constant: 16),
            ratingLabel.topAnchor.constraint(equalTo: bottomView.topAnchor, constant: 12),
            ratingLabel.widthAnchor.constraint(equalToConstant: 40),
            ratingLabel.heightAnchor.constraint(equalToConstant: 24),

            nameLabel.leadingAnchor.constraint(equalTo: ratingLabel.trailingAnchor, constant: 8),
            nameLabel.centerYAnchor.constraint(equalTo: ratingLabel.centerYAnchor),

            verifiedLabel.leadingAnchor.constraint(equalTo: nameLabel.trailingAnchor, constant: 6),
            verifiedLabel.centerYAnchor.constraint(equalTo: nameLabel.centerYAnchor),

            likeIcon.trailingAnchor.constraint(equalTo: bottomView.trailingAnchor, constant: -16),
            likeIcon.centerYAnchor.constraint(equalTo: ratingLabel.centerYAnchor),
            likeIcon.widthAnchor.constraint(equalToConstant: 16),
            likeIcon.heightAnchor.constraint(equalToConstant: 16),

            likeLabel.trailingAnchor.constraint(equalTo: likeIcon.leadingAnchor, constant: -6),
            likeLabel.centerYAnchor.constraint(equalTo: ratingLabel.centerYAnchor),

            commentLabel.leadingAnchor.constraint(equalTo: bottomView.leadingAnchor, constant: 16),
            commentLabel.trailingAnchor.constraint(equalTo: bottomView.trailingAnchor, constant: -16),
            commentLabel.topAnchor.constraint(equalTo: ratingLabel.bottomAnchor, constant: 8)
        ])
    }

    func configure(with imageUrl: String?) {
        if let url = imageUrl, let imgURL = URL(string: url) {
            imageView.sd_setImage(with: imgURL)
        }
    }
}
