import Foundation
import UIKit
import Toast_Swift
import Alamofire

class LMReviewClickPhotosMV: NSObject {

    var modelReviewlist: [Review] = []
    var customerImages: [CustomerImageDetail] = []

    private var hostVC: LMReviewClickPhotos  // <-- Updated to match correct ViewController
    init(hostController: LMReviewClickPhotos) {
        self.hostVC = hostController
    }

    func getReviewApi(productId: String, page: Int, limit: Int) {
        GlobalLoader.shared.show()

        THApiHandler.getApi(
            responseType: ReviewResponse123.self,
            page: "\(page)",
            limit: "\(limit)",
            subcategoryId: productId,tagValue:"2"
        ) { [weak self] dataResponse, error in
            GlobalLoader.shared.hide()

            guard let self = self, let data = dataResponse?.data else {
                print("❌ No data received or error: \(String(describing: error))")
                return
            }

            if let newReviews = data.reviews {
                self.modelReviewlist += newReviews
            }

            if let newImages = data.customerImageDetails {
                self.customerImages += newImages
            }

            DispatchQueue.main.async {
                self.hostVC.customerImages = self.customerImages
                self.hostVC.reloadDataAfterAppending()
            }
        }
    }
}
