//
//  LMProductCell.swift
//  LoomApp
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMProductCell12 : UICollectionViewCell {
    @IBOutlet weak var imgCollectionViewCell1: UIImageView!

}

