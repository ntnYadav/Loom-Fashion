//
//  LMProductCell.swift
//  LoomApp
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMProductCell1 : UICollectionViewCell,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UISearchBarDelegate {
    var onproductItemTap: ((String) -> Void)?
    var onproductItemTapSearchBar: ((String) -> Void)?
    var onBannerSelected: ((String,String,String) -> Void)?

    var searchSuggestions = [
                "Search shirt",
                "Search jeans",
                "Search chinos",
                "Search shorts",
                "Search formal shirt",
                "Search co-ord set",
                "Search t-shirt",
            ]
    
    @IBOutlet weak var viewMarqueContainer: UIView!

    var modelBanner : [Bannerdynmaically?] = []
    var modelMarquee : [MessageBar?] = []

    @IBOutlet weak var viewPager: UIView!
    @IBOutlet weak var lblMarque: UILabel!
    @IBOutlet weak var pageview: UIPageControl!

    @IBOutlet weak var collectionView1: UICollectionView!
    let searchBar = UISearchBar()
    
    var timer = Timer()
    var timer1 = Timer()

    var counter = 0
    var counter1 = 0

    let placeholderLabel = UILabel()
    let dotsContainer = UIStackView()
    var progressView: UIView?
    override func layoutSubviews() {
        super.layoutSubviews()
        lblMarque.text = ""
        //loadMarquee()
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        lblMarque.numberOfLines = 1
          lblMarque.lineBreakMode = .byClipping
          lblMarque.clipsToBounds = true
        lblMarque.textAlignment = .left
        //lblMarqueAnimate.isHidden = true
        
        
        viewMarqueContainer.clipsToBounds = true
        lblMarque.frame = CGRect(x: 0, y: 0, width: 100, height: viewMarqueContainer.bounds.height) // Width will be resized
        viewMarqueContainer.addSubview(lblMarque)
        
        collectionView1.delegate = self
        collectionView1.dataSource = self
        collectionView1.register(UINib(nibName: "LMProductCell12", bundle: nil), forCellWithReuseIdentifier: "LMProductCell12")

   
        
        searchBarSetup()
        progressbar()
        DispatchQueue.main.async {
        self.timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(self.changeImage), userInfo: nil, repeats: true)
        }
        
        DispatchQueue.main.async {
        self.timer1 = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.changeImage1), userInfo: nil, repeats: true)
        }
    }
    func loadMarquee() {
        let allMessages = modelMarquee.compactMap {
            $0?.message?.trimmingCharacters(in: .whitespacesAndNewlines)
        }

        guard !allMessages.isEmpty else {
            print("No messages found in modelMarquee")
            return
        }

        let strippedMessages = allMessages.map {
            $0.replacingOccurrences(of: "<p>", with: " ")
                .replacingOccurrences(of: "</p>", with: " ")
                .replacingOccurrences(of: "\u{200B}", with: " ")
        }
        
        
        let joined = strippedMessages.joined(separator: "&nbsp;&nbsp;<span style=\"color: #ffffff;\">•</span>&nbsp;&nbsp;")
//        let joined = strippedMessages.joined(separator: " <span style=\"color: #ffffff;\">  • </span> ")
        print("joined! \(joined)")

        let finalHTML = """
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="margin:0;">
        <span style="font-family: -apple-system; font-size: 16px; white-space: nowrap;">\(joined)</span>
        </body>
        </html>
        """

        print("finalHTML! \(finalHTML)")
        
        DispatchQueue.main.async {
            guard let data = finalHTML.data(using: .utf8) else { return }

            let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
                .documentType: NSAttributedString.DocumentType.html,
                .characterEncoding: String.Encoding.utf8.rawValue
            ]


            do {
                let attributed = try NSAttributedString(data: data, options: options, documentAttributes: nil)

                self.lblMarque.attributedText = attributed
                self.lblMarque.numberOfLines = 1
                self.lblMarque.lineBreakMode = .byClipping
                self.lblMarque.sizeToFit()

                // Get accurate size based on full attributedText
                let maxSize = CGSize(width: CGFloat.greatestFiniteMagnitude, height: self.viewMarqueContainer.frame.height)
                let neededSize = self.lblMarque.sizeThatFits(maxSize)

                self.lblMarque.frame = CGRect(x: 0, y: 0, width: neededSize.width, height: self.viewMarqueContainer.frame.height)

                self.viewMarqueContainer.subviews.forEach { $0.removeFromSuperview() }
                self.viewMarqueContainer.addSubview(self.lblMarque)

                self.startMarquee(label: self.lblMarque, containerView: self.viewMarqueContainer)

            } catch {
                print("HTML conversion error: \(error)")
            }
        }
    }
    
    //aq
    func attributedString(from html: String, font: UIFont) -> NSAttributedString? {
        let htmlWithFont = """
        <span style="font-family: -apple-system; font-size: \(font.pointSize)px">\(html)</span>
        """
        guard let data = htmlWithFont.data(using: .utf8) else { return nil }

        do {
            return try NSAttributedString(
                data: data,
                options: [
                    .documentType: NSAttributedString.DocumentType.html,
                    .characterEncoding: String.Encoding.utf8.rawValue
                ],
                documentAttributes: nil
            )
        } catch {
            print("HTML conversion error: \(error)")
            return nil
        }
    }


    func startMarquee(label: UILabel, containerView: UIView, duration: TimeInterval = 16.0) {
        guard let attributedText = label.attributedText else { return }

        // Calculate width of the attributed text
        let textWidth = attributedText.width(forHeight: label.bounds.height)

        // If text fits inside the label, no need to scroll
        guard textWidth > containerView.bounds.width else { return }

        // Reset label frame
        label.frame = CGRect(x: 0, y: 0, width: textWidth, height: containerView.bounds.height)

        // Create a duplicate label
        let duplicateLabel = UILabel(frame: CGRect(x: textWidth + 40, y: 0, width: textWidth, height: containerView.bounds.height))
        duplicateLabel.attributedText = attributedText
        duplicateLabel.backgroundColor = .clear
        containerView.addSubview(duplicateLabel)

        // Animate both labels together
        UIView.animate(withDuration: duration, delay: 0, options: [.curveLinear, .repeat], animations: {
            label.frame.origin.x -= (textWidth + 40)
            duplicateLabel.frame.origin.x -= (textWidth + 40)
        }, completion: nil)
    }
    

//    func attributedString(from html: String) -> NSAttributedString? {
//        guard let data = html.data(using: .utf8) else { return nil }
//
//        do {
//            return try NSAttributedString(
//                data: data,
//                options: [
//                    .documentType: NSAttributedString.DocumentType.html,
//                    .characterEncoding: String.Encoding.utf8.rawValue
//                ],
//                documentAttributes: nil
//            )
//        } catch {
//            print("❌ Error parsing HTML: \(error)")
//            return nil
//        }
//    }
    
    func setInit() {
        lblMarque.text = ""
        progressbar()
        collectionView1.reloadData()
    }

    func progressbar(){
          dotsContainer.axis = .horizontal
          dotsContainer.alignment = .center
          dotsContainer.distribution = .equalSpacing
          dotsContainer.spacing = 12
          dotsContainer.translatesAutoresizingMaskIntoConstraints = false

          viewPager.addSubview(dotsContainer)

          NSLayoutConstraint.activate([
              dotsContainer.centerXAnchor.constraint(equalTo: viewPager.centerXAnchor),
              dotsContainer.bottomAnchor.constraint(equalTo: viewPager.bottomAnchor, constant: -8),
              dotsContainer.heightAnchor.constraint(equalToConstant: 10)
          ])
           setupDotsWithProgressBar(currentIndex: 0, totalDots: modelBanner.count)

    }
    func setupDotsWithProgressBar(currentIndex: Int, totalDots: Int, selectedSize: CGFloat = 40, unselectedSize: CGFloat = 5) {
           dotsContainer.arrangedSubviews.forEach { $0.removeFromSuperview() }
   
           for i in 0..<totalDots {
               if i == currentIndex {
                   // Create outer frame
                   let frame = UIView()
                   frame.backgroundColor = UIColor.white
                   frame.layer.cornerRadius = unselectedSize / 2
                   frame.clipsToBounds = true
                   frame.translatesAutoresizingMaskIntoConstraints = false
                   frame.widthAnchor.constraint(equalToConstant: selectedSize).isActive = true
                   frame.heightAnchor.constraint(equalToConstant: unselectedSize).isActive = true
   
                   // Create inner progress view
                   let progress = UIView()
                   progress.backgroundColor = UIColor.lightGray
                   progress.layer.cornerRadius = unselectedSize / 2
                   progress.translatesAutoresizingMaskIntoConstraints = false
   
                   frame.addSubview(progress)
                   dotsContainer.addArrangedSubview(frame)
   
                   // Set initial width constraint for animation
                   let widthConstraint = progress.widthAnchor.constraint(equalToConstant: 0)
                   NSLayoutConstraint.activate([
                       progress.leadingAnchor.constraint(equalTo: frame.leadingAnchor),
                       progress.topAnchor.constraint(equalTo: frame.topAnchor),
                       progress.bottomAnchor.constraint(equalTo: frame.bottomAnchor),
                       widthConstraint
                   ])
   
                   // Animate progress bar
                   animateProgressBar(widthConstraint: widthConstraint, targetWidth: selectedSize)
               } else {
                   let dot = UIView()
                   dot.backgroundColor = UIColor.white
                   dot.layer.cornerRadius = unselectedSize / 2
                   dot.translatesAutoresizingMaskIntoConstraints = false
                   dot.widthAnchor.constraint(equalToConstant: unselectedSize).isActive = true
                   dot.heightAnchor.constraint(equalToConstant: unselectedSize).isActive = true
                   dotsContainer.addArrangedSubview(dot)
               }
           }
       }
   
       func animateProgressBar(widthConstraint: NSLayoutConstraint, targetWidth: CGFloat) {
            self.layoutIfNeeded()
           widthConstraint.constant = targetWidth
           UIView.animate(withDuration: 3.0) { // 3 seconds, similar to AUTO_SLIDE_TIME
               self.layoutIfNeeded()
           }
       }
   
    
    
    @objc func changeImage() {
     
     if counter < modelBanner.count {
         let index = IndexPath.init(item: counter, section: 0)
         let obj = modelBanner[counter]

         self.collectionView1.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
         setupDotsWithProgressBar(currentIndex: counter, totalDots: modelBanner.count)

         counter += 1

     } else {
         if modelBanner.count != 0 {
             counter = 0
             let index = IndexPath.init(item: counter, section: 0)
             setupDotsWithProgressBar(currentIndex: counter, totalDots: modelBanner.count)
             self.collectionView1.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
             counter = 1
         }
     }
  }
    
    
    
    
    @objc func changeImage1() {
     
     if counter1 < searchSuggestions.count {
         let index = IndexPath.init(item: counter1, section: 0)
         let obj = searchSuggestions[counter1]

//         self.collectionView1.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
//         setupDotsWithProgressBar(currentIndex: counter, totalDots: modelBanner.count)

         searchBar.placeholder = ""
         guard let textField = searchBar.value(forKey: "searchField") as? UITextField else { return }
      
         placeholderLabel.text = "       \(obj)"
         
         placeholderLabel.font = textField.font
         placeholderLabel.textColor = .white
         placeholderLabel.alpha = 0
         placeholderLabel.frame = CGRect(x: 8, y: textField.bounds.height, width: textField.bounds.width, height: 20)
         textField.addSubview(placeholderLabel)

         // Animate from bottom to top
         UIView.animate(withDuration: 0.4, delay: 0.2, options: [.curveEaseOut], animations: {
             self.placeholderLabel.frame.origin.y = (textField.bounds.height - 20) / 2
             self.placeholderLabel.alpha = 1
         }, completion: nil)
         UIView.animate(withDuration: 0.4, delay: 0.2, options: [.curveEaseOut], animations: {
             self.placeholderLabel.frame.origin.y = (textField.bounds.height - 20) / 2
             self.placeholderLabel.alpha = 1
         }, completion: nil)
         counter1 += 1

     } else {
         if searchSuggestions.count != 0 {
             counter1 = 0
             let index = IndexPath.init(item: counter, section: 0)
            // setupDotsWithProgressBar(currentIndex: counter, totalDots: modelBanner.count)
           //  self.collectionView1.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
         }
     }
  }
    // self.NavigationController(navigateFrom: self, navigateTo: LMSearchVC(), navigateToString: VcIdentifier.LMSearchVC)
    func searchBarSetup() {
                
        searchBar.placeholder = "Search items..."
        searchBar.delegate = self
        placeholderLabel.textColor = .white

        searchBar.translatesAutoresizingMaskIntoConstraints = false
        searchBar.setImage(UIImage(systemName: "searchbar.jpg"), for: .search, state: .normal)
        searchBar.tintColor = .white
        contentView.addSubview(searchBar)
        searchBar.backgroundImage = UIImage()
        searchBar.barTintColor = .white
        
        let textFieldInsideSearchBar = searchBar.value(forKey: "searchField") as? UITextField
        let imageV = textFieldInsideSearchBar?.leftView as! UIImageView
        imageV.image = imageV.image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        imageV.tintColor = UIColor.white
        
        
        guard let textField = searchBar.value(forKey: "searchField") as? UITextField else { return }

        placeholderLabel.font = textField.font
        placeholderLabel.textColor = .white
        placeholderLabel.alpha = 0
        placeholderLabel.frame = CGRect(x: 8, y: textField.bounds.height, width: textField.bounds.width, height: 20)
        textField.addSubview(placeholderLabel)
        
      // Change border color
        if let textField = searchBar.value(forKey: "searchField") as? UITextField {
            textField.textColor  = UIColor.white
            textField.layer.borderColor = UIColor.white.cgColor
            textField.layer.borderWidth = 1.5
            textField.layer.cornerRadius = 0
            textField.clipsToBounds = true
            
        }
        
        
        NSLayoutConstraint.activate([
            searchBar.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 100),
            searchBar.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            searchBar.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            searchBar.heightAnchor.constraint(equalToConstant: 40)
            
        ])
        collectionView1.translatesAutoresizingMaskIntoConstraints = false
//        NSLayoutConstraint.activate([
//            collectionView1.topAnchor.constraint(equalTo: searchBar.bottomAnchor, constant: 8),
//            collectionView1.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
//            collectionView1.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
//            collectionView1.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
//        ])
    }
    // Called when editing begins
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("Editing began")
        onproductItemTapSearchBar!("")
        textField.resignFirstResponder()

    }

    // Called when editing ends
    func textFieldDidEndEditing(_ textField: UITextField) {
        print("Editing ended")
        textField.resignFirstResponder()

    }

    // Called when Return key is pressed
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()  // Hides the keyboard
        return true
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return modelBanner.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView1.dequeueReusableCell(withReuseIdentifier: "LMProductCell12", for: indexPath) as! LMProductCell12
       // cell.lblShopNow.layer.cornerRadius = 10
        cell.clipsToBounds = true
        let obj = modelBanner[indexPath.row]
        
        if obj?.mobileImage == nil {
            
            //cell.imgCollectionViewCell1.sd_imageIndicator = SDWebImageActivityIndicator.gray
            cell.imgCollectionViewCell1.sd_setImage(with: URL(string:obj?.webVideo ?? keyName.emptyStr))
        } else {
            
           // cell.imgCollectionViewCell1.sd_imageIndicator = SDWebImageActivityIndicator.gray
            cell.imgCollectionViewCell1.sd_setImage(with: URL(string:obj?.mobileImage ?? keyName.emptyStr))
        }
        
//        cell.imgCollectionViewCell1.sd_imageIndicator = SDWebImageActivityIndicator.gray
//        cell.imgCollectionViewCell1.sd_setImage(with: URL(string:obj?.mobileImage ?? keyName.emptyStr))

        return cell
    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)  // Full height
//    }
    
    // Called when user starts editing in the search bar
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        print("SearchBar began editing")
        onproductItemTapSearchBar?("")
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let sizevalue = sizesArr[indexPath.item].size
//        dismiss(animated: true, completion: nil)
        let obj = modelBanner[indexPath.item]
        
       // for banner in self.modelBanner ?? [] {
        let queryString = self.filtersToQueryString(obj?.filters)
            print(queryString)
        //}
        
        onBannerSelected?(queryString, obj?.subcategoryId ?? "", obj?.title ?? "")
    }
    func filtersToQueryString(_ filters: [Filter]?) -> String {
           guard let filters = filters else { return "" }
           
           var components: [String] = []
           
           for filter in filters {
               guard let key = filter.key else { continue }
               let value = filter.values?.joined(separator: ",") ?? ""
               
               if let encodedKey = key.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                  let encodedValue = value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
                   components.append("\(encodedKey)=\(encodedValue)")
               }
           }
           
           return components.joined(separator: "&")
       }
   
}

extension NSAttributedString {
    func width(forHeight height: CGFloat) -> CGFloat {
        let constraintBox = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintBox, options: [.usesLineFragmentOrigin, .usesFontLeading], context: nil)
        return ceil(boundingBox.width)
    }
}

