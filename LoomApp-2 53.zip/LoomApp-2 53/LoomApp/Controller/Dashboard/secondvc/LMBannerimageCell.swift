
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMBannerimageCell : UICollectionViewCell {
    
    @IBOutlet weak var imgProduct: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       // viewMain.addBottomBorderWithShadow()
    }
    
}
