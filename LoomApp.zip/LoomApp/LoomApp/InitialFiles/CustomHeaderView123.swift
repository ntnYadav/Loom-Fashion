//
//  CustomHeaderView.swift
//  CustomHeaderView
//
//  Created by Santosh on 04/08/20.
//  Copyright © 2020 Santosh. All rights reserved.
//

import UIKit

class CustomHeaderView123: UITableViewHeaderFooterView {

    @IBOutlet weak var sectionTitleLabel: UILabel!

}
