//
//  ViewController.swift
//  Demo alomofire
//
//  Created by chetu on 3/20/25.
//

import UIKit
import Alamofire
import ImageIO
import AVFoundation
import UIKit
import AVFoundation

class LMSplashVC: UIViewController {
    
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        playSplashVideo()
    }

    private func playSplashVideo() {
        guard let path = Bundle.main.path(forResource: "1750079959282-343765128", ofType: "mp4") else {
            goToNextScreen()
            return
        }

        let url = URL(fileURLWithPath: path)
        player = AVPlayer(url: url)
        player?.volume = 0  // Mute the video

        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = view.bounds
        playerLayer?.videoGravity = .resize

        if let playerLayer = playerLayer {
            view.layer.addSublayer(playerLayer)
        }

        // Observe when the video ends
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(videoDidEnd),
            name: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem
        )

        player?.play()
    }

    @objc private func videoDidEnd(notification: Notification) {
        goToNextScreen()
    }

    private func goToNextScreen() {
        // Stop and remove video
        player?.pause()
        playerLayer?.removeFromSuperlayer()
        player = nil
        playerLayer = nil

        NotificationCenter.default.removeObserver(self)

        // Navigate to Tab Bar (replace with your VC name if different)
            self.NavigationController(navigateFrom: self, navigateTo: LMTabBarVC(), navigateToString: VcIdentifier.LMTabBarVC)

    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}


//class LMSplashVC: UIViewController {
//    
//    var counter = 0
//    var timer = Timer()
//    let imgGif = UIImage.gifImageWithName("splas")
//    var player: AVPlayer?
//       var playerLayer: AVPlayerLayer?
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        playSplashVideo()
//    }
//    func playSplashVideo() {
//            guard let path = Bundle.main.path(forResource: "1750079959282-343765128", ofType: "mp4") else {
//                goToNextScreen()
//                return
//            }
//
//            let url = URL(fileURLWithPath: path)
//            player = AVPlayer(url: url)
//            player?.volume = 0  // 👈 Mute the video
//
//            playerLayer = AVPlayerLayer(player: player)
//            playerLayer?.frame = view.bounds
//            playerLayer?.videoGravity = .resize
//
//            if let playerLayer = playerLayer {
//                view.layer.addSublayer(playerLayer)
//            }
//
//            NotificationCenter.default.addObserver(
//                self,
//                selector: #selector(videoDidEnd),
//                name: .AVPlayerItemDidPlayToEndTime,
//                object: player?.currentItem
//            )
//
//            player?.play()
//        }
//
//    @objc func videoDidEnd(notification: Notification) {
//            goToNextScreen()
//        }
//    func goToNextScreen() {
//           // Clean up to free memory
//           player?.pause()
//           playerLayer?.removeFromSuperlayer()
//           player = nil
//           playerLayer = nil
//
//           // Transition to the main screen
//         //self.NavigationController(navigateFrom: self, navigateTo: LMReviewRateVC(), navigateToString: VcIdentifier.LMReviewRateVC)
//        
//        self.NavigationController(navigateFrom: self, navigateTo: LMTabBarVC(), navigateToString: VcIdentifier.LMTabBarVC)
//
//
//       }
//    deinit {
//            NotificationCenter.default.removeObserver(self)
//        }
//}
