import UIKit

class LMChartSheetVC: UIViewController {

    private let containerView = UIView()
    private let imageView = UIImageView()
    var sizeChartUrl = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupContainer()
        setupImageView()
    }

    private func setupBackground() {
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissSheet))
        view.addGestureRecognizer(tap)
    }

    private func setupContainer() {
        containerView.backgroundColor = .white
        containerView.layer.cornerRadius = 16
        containerView.clipsToBounds = true
        view.addSubview(containerView)

        containerView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            containerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            containerView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            containerView.heightAnchor.constraint(equalToConstant: 400)
        ])
    }

    private func setupImageView() {
        
        imageView.sd_setImage(with: URL(string: sizeChartUrl))
//        imageView.image = UIImage(named: "warning_icon") // Replace with your image asset name
        imageView.contentMode = .scaleToFill
        containerView.addSubview(imageView)

        imageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 0),
            imageView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 0),
            imageView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: 0),
            imageView.heightAnchor.constraint(equalTo: containerView.heightAnchor)
        ])
    }

    @objc private func dismissSheet() {
        dismiss(animated: true, completion: nil)
    }
}
