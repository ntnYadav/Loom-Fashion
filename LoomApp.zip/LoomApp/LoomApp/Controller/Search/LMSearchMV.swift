import Foundation
import UIKit
import Toast_Swift

class LMSearchMV: NSObject {
    
    private var hostVC: LMSearchVC
    init(hostController: LMSearchVC) {
        self.hostVC = hostController
    }

    var model: ProductListDataSearch?
    var currentPage = 1
    var totalPages = 1
    var isFetching = false
    var lastQuery = ""

    // MARK: - Public Method to Start New Search
    func validateValue(str: String) {
        guard hostVC.checkInternet else { return }

        lastQuery = str
        currentPage = 1
        totalPages = 1
        model = nil
        fetchNextPage()
    }

    // MARK: - Fetch Next Page
    func fetchNextPage() {
        guard hostVC.checkInternet, !isFetching, currentPage <= totalPages else { return }

        isFetching = true
        GlobalLoader.shared.show()

        THApiHandler.getApi(responseType: ProductListResponse.self,
                            page: "\(currentPage)",
                            limit: "10",  // you can change the limit here
                            subcategoryId: lastQuery) { [weak self] dataResponse, error in

            DispatchQueue.main.async {
                GlobalLoader.shared.hide()
                self?.isFetching = false
            }

            guard let self = self else { return }

            if let data = dataResponse?.data {
                self.totalPages = data.totalPages ?? 1

                if self.model == nil {
                    self.model = data
                } else {
                    self.model?.products?.append(contentsOf: data.products ?? [])
                }

                self.currentPage += 1

                DispatchQueue.main.async {
                    let hasResults = (self.model?.products?.isEmpty == false)
                    self.hostVC.collectionView.isHidden = !hasResults
                    self.hostVC.viewEmpty.isHidden = hasResults
                    self.hostVC.collectionView.reloadData()
                }

            } else {
                DispatchQueue.main.async {
                    self.hostVC.collectionView.isHidden = true
                    self.hostVC.viewEmpty.isHidden = false
                    self.hostVC.txtSearchBorder.resignFirstResponder() // Hides the keyboard

                }
            }
        }
    }
}
