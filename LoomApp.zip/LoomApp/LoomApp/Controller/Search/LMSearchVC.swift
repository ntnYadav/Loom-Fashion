//
//  ViewController.swift
//  CustomHeaderView
//
//  Created by Santosh on 04/08/20.
//  Copyright © 2020 Santosh. All rights reserved.
//

import UIKit

class LMSearchVC: UIViewController,UISearchBarDelegate,UITextFieldDelegate,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    let items = ["Shirt", "WHITE SHIRT", "TROUSER", "LINEN", "JEANS", "FORMAL WEAR", "OVERSHIRT", "POLO", "CHECKS SHIRT", "BAGGY JEANS"]
    var updatedText2:String = ""

    var currentPage = 1
    var isLoading = false
    var hasMoreData = true
    @IBOutlet weak var viewEmptyCell: UIView!

    @IBOutlet weak var viewEmpty: UIView!
    var collectionView: UICollectionView!
    lazy private var viewmodel = LMSearchMV(hostController: self)
    @IBOutlet weak var lblLabel: UILabel!
    @IBOutlet weak var searchborder: UITextField!
    @IBOutlet weak var txtSearchBorder: UITextField!
    @IBOutlet weak var viewSearch: UIView!
    @IBOutlet weak var viewMainCollecrtion: UIView!

    
    

    
    @IBOutlet weak var tableView: UITableView!
    let  arrRecent = ["RECENT SEARCHES", "TOP SEARCHES", "TRENDING"]
    let  arrList = ["RECENT SEARCHES","RECENT SEARCHES","RECENT SEARCHES","RECENT SEARCHES","RECENT SEARCHES","RECENT SEARCHES","RECENT SEARCHES","RECENT SEARCHES","RECENT SEARCHES"]
    let  arrLast = ["RECENT SEARCHES", "TOP SEARCHES", "TRENDING"]
    let  arrCotegory = ["All", "Shirts", "T-shirts", "Jeans","Trouser", "Jacket","Sweaters","Swearshirt","Shorts","All", "Shirts", "T-shirts", "Jeans","Trouser", "Jacket","Sweaters","Swearshirt","Shorts"]

    var searchBar = UISearchBar()
    let placeholderLabel = UILabel()
    var timer = Timer()
    var counter = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false
        viewEmptyCell.addSubview(container)

        NSLayoutConstraint.activate([
            container.topAnchor.constraint(equalTo: viewEmptyCell.topAnchor),
            container.leadingAnchor.constraint(equalTo: viewEmptyCell.leadingAnchor, constant: 16),
            container.trailingAnchor.constraint(equalTo: viewEmptyCell.trailingAnchor, constant: -16)
        ])

        layoutButtons(in: container)
        
        
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.headerReferenceSize = CGSize(width: view.frame.width, height: 0)
        layout.sectionHeadersPinToVisibleBounds = true // 👈 Make header sticky
//
//        collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: layout)
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        viewMainCollecrtion.addSubview(collectionView)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.contentInsetAdjustmentBehavior = .never
        collectionView.register(CustomCell.self, forCellWithReuseIdentifier: CustomCell.identifier)
        collectionView.register(UINib(nibName: "LMcellShopCell", bundle: nil), forCellWithReuseIdentifier: "LMcellShopCell")

       //collectionView.register("LMcellShopCell", forCellWithReuseIdentifier: "LMcellShopCell")

        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        
        collectionView.register(
            UINib(nibName: "searchBarHeaderCv", bundle: nil),
            forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
            withReuseIdentifier: "searchBarHeaderCv"
        )
        collectionView.register(
            UINib(nibName: "searchBarHeader1", bundle: nil),
            forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
            withReuseIdentifier: "searchBarHeader1"
        )
        
        viewMainCollecrtion.addSubview(collectionView)
//        viewMainCollecrtion.backgroundColor = .yellow
//        collectionView.backgroundColor = .cyan
        collectionView.isScrollEnabled = true
        collectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: viewMainCollecrtion.topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: viewMainCollecrtion.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: viewMainCollecrtion.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: viewMainCollecrtion.trailingAnchor)
        ])
        
        searchBarSetup()
        tableView.contentInsetAdjustmentBehavior = .never // If you're customizing layout manually

        txtSearchBorder.delegate = self //set delegate to textfile
        txtSearchBorder.becomeFirstResponder()

        searchborder.layer.borderWidth = 0.5
        searchborder.layer.borderColor = UIColor.lightGray.cgColor
        tableView.delegate   = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "CustomHeaderView", bundle: nil), forHeaderFooterViewReuseIdentifier: "CustomHeaderView")
        tableView.register(UINib(nibName: "CustomFooterView", bundle: nil), forHeaderFooterViewReuseIdentifier: "CustomFooterView")
        tableView.register(UINib(nibName: "LMTrendingCell", bundle: nil), forCellReuseIdentifier: "LMTrendingCell")
        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(timeInterval: 6.0, target: self, selector: #selector(self.changeImage), userInfo: nil, repeats: true)
        }
        viewmodel.validateValue(str: "popular")
    }
    func layoutButtons(in container: UIView) {
        let horizontalSpacing: CGFloat = 10
        let verticalSpacing: CGFloat = 12
        let buttonHeight: CGFloat = 32
        let padding: CGFloat = 10
        let maxWidth = view.bounds.width - (padding * 2)
        let font = UIFont(name: ConstantFontSize.regular, size: 15)

        var currentRowButtons: [UIButton] = []
        var currentRowWidth: CGFloat = 0
        var allRows: [[UIButton]] = []

        // Create all buttons first
        let buttons: [UIButton] = items.enumerated().map { (index, title) in
            let button = UIButton(type: .system)
            button.setTitle(title, for: .normal)
            button.setTitleColor(.black, for: .normal)
            button.backgroundColor = .white
            button.layer.borderColor = UIColor.black.cgColor
            button.layer.borderWidth = 0.2

            button.titleLabel?.font = font
            button.layer.cornerRadius = 0
            button.tag = index
            button.addTarget(self, action: #selector(buttonTapped(_:)), for: .touchUpInside)
            let size = (title as NSString).size(withAttributes: [.font: font])
            button.frame.size = CGSize(width: size.width + 32, height: buttonHeight)
            return button
        }

        // Arrange buttons into rows
        for button in buttons {
            let buttonWidth = button.frame.width
            if currentRowWidth + buttonWidth + CGFloat(currentRowButtons.count) * horizontalSpacing > maxWidth {
                allRows.append(currentRowButtons)
                currentRowButtons = [button]
                currentRowWidth = buttonWidth
            } else {
                currentRowButtons.append(button)
                currentRowWidth += buttonWidth
            }
        }
        if !currentRowButtons.isEmpty {
            allRows.append(currentRowButtons)
        }

        // Layout each row
        var currentY: CGFloat = 0
        for row in allRows {
            let totalButtonWidth = row.reduce(0) { $0 + $1.frame.width }
            let totalSpacing = CGFloat(row.count - 1) * horizontalSpacing
            let rowWidth = totalButtonWidth + totalSpacing
            var x = (view.bounds.width - rowWidth) / 2

            for button in row {
                button.frame.origin = CGPoint(x: x, y: currentY)
                container.addSubview(button)
                x += button.frame.width + horizontalSpacing
            }
            currentY += buttonHeight + verticalSpacing
        }

        container.heightAnchor.constraint(equalToConstant: currentY).isActive = true
    }

    @objc func buttonTapped(_ sender: UIButton) {
        let title = items[sender.tag]
        viewmodel.validateValue(str:title)

        print("Tapped: \(title)")
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.frame = viewMainCollecrtion.bounds
    }
    // Hide keyboard when Return is tapped
      func textFieldShouldReturn(_ textField: UITextField) -> Bool {
          textField.resignFirstResponder() // Hides the keyboard
          return true
      }
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool {

        
        if string == "\n" {
            txtSearchBorder.resignFirstResponder() // Hides keyboard
            return false
        }
        // Limit total characters to 6
        let currentText = textField.text ?? ""
        guard let stringRange = Range(range, in: currentText) else {
            return false
        }

        let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
        
        if  3 <= updatedText.count{
            updatedText2 = updatedText
            viewmodel.validateValue(str: updatedText)
        }
        return updatedText.count <= 50
    }
    
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let height = scrollView.frame.size.height

        if offsetY > contentHeight - height - 100 {
            viewmodel.fetchNextPage()
        }
    }
    func searchBarSetup(){}
    @objc func changeImage() {}

    @IBAction func actBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
//    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//        let offsetY = scrollView.contentOffset.y
//        let contentHeight = scrollView.contentSize.height
//        let frameHeight = scrollView.frame.size.height
//
//        if offsetY > contentHeight - frameHeight * 2 {
//           // viewmodel.fetchMoreDataIfNeeded(indexPath: IndexPath(row: viewmodel.model?.products?.count ?? 0 - 1, section: 0), updatedText2: updatedText2)
//            
//            //viewmodel.validateValue(str: updatedText2)
//        }
//    }
//    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
//        viewModel.fetchMoreDataIfNeeded(indexPath: indexPath, updatedText2: currentSearchText)
//    }
}

extension LMSearchVC: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrRecent.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 1
        case 1:
            return 0
       
        case 3:
            return arrList.count
        default:
            return arrList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            let cell = tableView.dequeueReusableCell(withIdentifier: "LMTrendingCell", for: indexPath) as! LMTrendingCell
            cell.selectionStyle = .none

            tableView.separatorColor = .clear
            // cell.textLabel?.text = arrList[indexPath.row]
            return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "CustomHeaderView") as! CustomHeaderView

        //headerView.sectionTitleLabel.text = arrRecent[section]
        self.tableView.separatorColor = .clear

        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
  
    ////      // MARK: - UICollectionViewDataSource
    
//    func numberOfSections(in collectionView: UICollectionView) -> Int {
//        return 3
//    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       // if section == 2 {
            return viewmodel.model?.products?.count ?? 0
//        }
//        return 0

    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        if indexPath.section == 0 {
//            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CustomCell.identifier, for: indexPath) as! CustomCell
//            cell.imageView.image = UIImage(systemName: "image") // Replace with your image
//            cell.imageView.backgroundColor = .gray
//            cell.titleLabel.text = "Item \(indexPath.item)"
//            return cell
//        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LMcellShopCell", for: indexPath) as! LMcellShopCell
        let objModel = viewmodel.model?.products?[indexPath.row]
        if let obj = (objModel?.variantThumbnail?.image){
                cell.imgProduct.sd_setImage(with: URL(string: obj ?? ""))
             }
            cell.lblTitle.text  = objModel?.title
            if let price = objModel?.lowestSellingPrice {
            cell.lblPrice.text = keyName.rupessymbol + " \(price)"
            }
//            if let colorcode = objModel?.colorPreview?.count {
//            if colorcode < 3 {
//                cell.lblColorsize.isHidden = false
//                if let countlavbel = objModel?.totalColorCount {
//                    cell.lblColorsize.text = "\(countlavbel)"
//                }
//            }
//
//            if colorcode == 1 {
//                let uiColor = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? keyName.emptyStr)
//                cell.lblFirstColor.backgroundColor = uiColor
//                cell.lblThirdColor.isHidden = true
//                cell.lblSecondColor.isHidden = true
//
//            } else if colorcode == 2 {
//                let uiColor  = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? keyName.emptyStr)
//                let uiColor1 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[1] ?? keyName.emptyStr)
//                cell.lblFirstColor.backgroundColor = uiColor
//                cell.lblSecondColor.backgroundColor = uiColor1
//                cell.lblThirdColor.isHidden = true
//            } else {
//                let uiColor  = LMGlobal.shared.colorFromString(objModel?.colorPreview?[0] ?? keyName.emptyStr)
//                let uiColor1 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[1] ?? keyName.emptyStr)
//                let uiColor2 = LMGlobal.shared.colorFromString(objModel?.colorPreview?[2] ?? keyName.emptyStr)
//                cell.lblFirstColor.backgroundColor = uiColor
//                cell.lblSecondColor.backgroundColor = uiColor1
//                cell.lblThirdColor.backgroundColor = uiColor2
//
//            }
          //  print(colorcode)
        
            
//                cell.imageView.image = UIImage(systemName: "image") // Replace with your image
//                cell.imageView.backgroundColor = .gray
//                cell.titleLabel.text = "Item \(indexPath.item)"
            return cell
            
      //  }
    }

    // MARK: - Header View

    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader {
            if indexPath.section == 0 {
                let header = collectionView.dequeueReusableSupplementaryView(
                    ofKind: kind,
                    withReuseIdentifier: "searchBarHeader1",
                    for: indexPath
                ) as! searchBarHeader1
                
                //header.backgroundColor = .green
                header.lblTitle.text = "TOP SEARCHES"
                header.lblTitle.font = UIFont(name: ConstantFontSize.Bold, size: 18)
                
                header.onproductItemTapSearchBar123 = { [weak self] collectionIndexPath in
                    self?.viewmodel.validateValue(str: collectionIndexPath)

                   // self?.NavigationController(navigateFrom: self, navigateTo: LMSearchVC(), navigateToString: VcIdentifier.LMSearchVC)

                }

                return header
            } else if indexPath.section == 0 {

                let header = collectionView.dequeueReusableSupplementaryView(
                    ofKind: kind,
                    withReuseIdentifier: "searchBarHeader1",
                    for: indexPath
                ) as! searchBarHeader1
                //header.backgroundColor = .green
                header.lblTitle.text = "TOP SEARCHES1"
                header.lblTitle.font = UIFont(name: ConstantFontSize.Bold, size: 18)

                return header
            } else {
                let header = collectionView.dequeueReusableSupplementaryView(
                    ofKind: kind,
                    withReuseIdentifier: "searchBarHeader1",
                    for: indexPath
                ) as! searchBarHeader1
                //header.backgroundColor = .green
                header.lblTitle.text = "TRENDING"
                header.lblTitle.font = UIFont(name: ConstantFontSize.Bold, size: 18)

                return header
            }
        }
        return UICollectionReusableView()
    }

    // MARK: - Layout
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMProductDetVC) as! LMProductDetVC
        let objModel = viewmodel.model?.products?[indexPath.row]
        secondVC.productId = objModel?._id ?? keyName.emptyStr
        navigationController?.pushViewController(secondVC, animated: true)
        
//        let obj = subcategoriesitem[indexPath.row]
//        onCollectionItemTap?(obj._id, obj.name)
    }
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
//        if indexPath.section == 0 {
//            return CGSize(width: (view.frame.width - 30), height: 105)
//        } else if indexPath.section == 1{
//            return CGSize(width: (view.frame.width - 30), height: 105)
//        } else if indexPath.section == 2{
//            return CGSize(width: (view.frame.width - 30)/2, height: (40 * 10))
//        } else {
            return CGSize(width: (view.frame.width - 20)/2, height: 400)

  //      }
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 || section == 1 || section == 2{
            return CGSize(width: collectionView.bounds.width, height: 105) // Adjust height as needed
        } else {
            return CGSize(width: (view.frame.width - 30)/2, height: 400) // Adjust height as needed
        }
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 2, left: 5, bottom: 2, right: 5)
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
}
//extension ViewController: UITextViewDelegate {
//
//    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
//        if text == "\n" {
//            textView.resignFirstResponder() // Hides keyboard
//            return false
//        }
//        return true
//    }
//}
