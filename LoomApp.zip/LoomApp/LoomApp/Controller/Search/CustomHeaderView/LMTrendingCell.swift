//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMTrendingCell :UITableViewCell {
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var lblSize: UILabel!
    @IBOutlet weak var viewCell: UIView!

    // Note: must be strong
  
    override func awakeFromNib() {
        super.awakeFromNib()
    
    }
    
}
