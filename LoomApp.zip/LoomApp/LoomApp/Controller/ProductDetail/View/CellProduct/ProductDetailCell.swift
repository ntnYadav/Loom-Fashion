//
//  LMProductCell.swift
//  LoomApp
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit


class ProductDetailCell : UICollectionViewCell{

    @IBOutlet weak var imgProduct: UIImageView!
    
    @IBOutlet weak var btnFavorite: UIButton!
//    @IBOutlet weak var topconsview: NSLayoutConstraint!
//    @IBOutlet weak var viewcolourConstraint: NSLayoutConstraint!
//    @IBOutlet weak var bottomConstraintFinal: NSLayoutConstraint!
//    @IBOutlet weak var topImgconstraint: NSLayoutConstraint!
//    @IBOutlet weak var topconstraint: NSLayoutConstraint!
//    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
//    @IBOutlet weak var lblProductName: UILabel!
//    @IBOutlet weak var lblProductPrice: UILabel!
//    @IBOutlet weak var lblColorsize: UILabel!
    @IBOutlet weak var lblProductPrice: UILabel!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var viewproductColor: UIView!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lblCount: UILabel!
    
 
}
