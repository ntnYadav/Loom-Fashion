//
//  LMProductCell.swift
//  LoomApp
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit
import WebKit


class LMwishlistCell : UITableViewCell {
 
    @IBOutlet weak var btnMovetoBag: UIButton!
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var lblSize: UILabel!
    @IBOutlet weak var btnmovvetoBag: UIButton!
    @IBOutlet weak var lblProductname: UILabel!
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var lblPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

