
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMcellShopCell2 : UICollectionViewCell {
    
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var lblCategory: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       // viewMain.addBottomBorderWithShadow()
    }
    
}
