//
//  LoginVM.swift
//  TouringHealth
//
//  Created by chetu on 07/10/22.
//

import Foundation
import UIKit
import Toast_Swift
//nameTextField.placeholder = "Enter Name"
//phoneTextField.placeholder = "Phone Number"
//emailTextField.placeholder = "Email Address"
class LMContactVM : NSObject{
    
    private var hostVC : LMContactDetailsVC
    init(hostController : LMContactDetailsVC) {
        self.hostVC = hostController
    }
    // MARK: validate value
    func validateValue(){
        guard hostVC.checkInternet else{
            return
        }
        
        let phoneNumber = hostVC.phoneTextField.text!
        if hostVC.nameTextField.text!.isEmpty {
            self.hostVC.showToastView(message: keyName.name)
        } else if hostVC.phoneTextField.text!.isEmpty {
            self.hostVC.showToastView(message: keyName.phoneNumber)
        } else if phoneNumber.count != 10 {
            self.hostVC.showToastView(message: keyName.validPhoneNumber)
            return
//        }else if hostVC.emailTextField.text!.isEmpty {
//            self.hostVC.showToastView(message: keyName.emailCheck)
//        } else if !hostVC.emailTextField.text!.isValidEmail() {
//            self.hostVC.showToastView(message: keyName.validEmail)
        } else {
            self.hitContactApi(name: hostVC.nameTextField.text!, phoneNo: hostVC.phoneTextField.text!, emailId: hostVC.emailTextField.text!)
        }
    }
    
    
    private  func hitContactApi(name:String,phoneNo:String,emailId:String) {
        GlobalLoader.shared.show()
        let bodyRequest = ContactModelBody(name: name, phoneNumber: THconstant.countryCode + phoneNo, email: emailId, deviceType: "ios", deviceToken: "89238120321")
        THApiHandler.post(requestBody: bodyRequest, responseType: ContactModelResponse.self, progressView: hostVC.view) { [weak self] dataResponse, error,msg  in
            GlobalLoader.shared.hide()
            if let status = dataResponse?.success {

                UserDefaults.standard.set(dataResponse?.data?.accesstoken, forKey: "accessToken")
                THUserDefaultValue.userFirstName = dataResponse?.data?.name
                THUserDefaultValue.phoneNumber   = dataResponse?.data?.phoneNumber
                THUserDefaultValue.userEmail     = dataResponse?.data?.email
                THUserDefaultValue.isUserLoging  = true
                GlobalLoader.shared.hide()
                AlertManager.showAlert(on: self!.hostVC,
                                       title: "Success",
                                       message: dataResponse?.message ?? "") {
                    self?.hostVC.dismiss(animated: true, completion: nil)
                }
                
//                THUserDefaultValue.authToken     = dataResponse?.data.token
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.id
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.phoneNumber
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
//                THUserDefaultValue.userFirstName = dataResponse?.data.user.name
               // status ? self?.redirectToHome() : self?.hostVC.showToastView(message: dataResponse?.message ?? "")
            } else {
                self?.hostVC.showToastView(message: msg)
            }
        }
    }
    private func redirectToHome(){
       
          //hostVC.NavigationController(navigateFrom: hostVC, navigateTo: LMTabBarVC(), navigateToString: VcIdentifier.LMTabBarVC)
       // hostVC.NavigationController(navigateFrom: hostVC, navigateTo: LMTabBarVC(), navigateToString: VcIdentifier.LMTabBarVC)
    }
}
