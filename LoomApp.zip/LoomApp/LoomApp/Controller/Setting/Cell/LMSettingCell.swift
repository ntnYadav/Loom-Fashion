//
//  LMProductCell.swift
//  LoomApp
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit


class LMSettingCell : UITableViewCell {
 
    @IBOutlet weak var lblSetting: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
        
       
    }


