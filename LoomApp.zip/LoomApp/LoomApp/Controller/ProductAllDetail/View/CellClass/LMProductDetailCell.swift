//
//  LMProductCell.swift
//  LoomApp
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMProductDetailCell : UICollectionViewCell{
    @IBOutlet weak var img: UIImageView!
}
