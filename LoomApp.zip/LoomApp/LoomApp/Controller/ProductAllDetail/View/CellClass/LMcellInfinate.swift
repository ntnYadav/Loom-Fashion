
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class LMcellInfinate : UICollectionViewCell {
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var lblSize: UILabel!
}
