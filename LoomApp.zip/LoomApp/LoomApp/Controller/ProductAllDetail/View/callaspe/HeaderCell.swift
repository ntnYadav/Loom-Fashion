//
//  HeaderCell.swift
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class HeaderCell1: UITableViewCell {

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var toggleButton: UIButton!

}
