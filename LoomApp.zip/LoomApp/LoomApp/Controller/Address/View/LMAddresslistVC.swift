//
//  LMProductDetailVC.swift
//  LoomApp
//
//  Created by Flucent tech on 07/04/25.
//
import UIKit


class LMAddresslistVC: UIViewController,UITableViewDelegate, UITableViewDataSource {
    var onAddressSelected: ((String, String) -> Void)?
    var strAddress: String = keyName.name
    var addressID : String = ""
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var viewEmpty: UIView!

    @IBOutlet weak var viewBottom: UIView!
    var selectCell: IndexPath? = nil
    var flagAddressDirectionCheck:Bool = false
    @IBOutlet weak var lblError: UILabel!
    @IBOutlet weak var tblAddlist: UITableView!
    lazy private var viewmodel = LMAddressListMV(hostController: self)
    var strClickAct: String = ""
    var arrcount: Int = 0
    let  arrCotegory = ["All", "Shirts", "T-shirts", "Jeans","Trouser", "Jacket","Sweaters","Swearshirt","Shorts","All", "Shirts", "T-shirts", "Jeans","Trouser", "Jacket","Sweaters","Swearshirt","Shorts"]
    var selectedCell = [IndexPath]()
    var timer = Timer()
    var counter = 0
    
    override func viewDidLoad() {
        
        overrideUserInterfaceStyle = .light
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lblError.isHidden = false
        tblAddlist.isHidden = true
        viewmodel.validateValue()
        if flagAddressDirectionCheck == true {
            viewBottom.isHidden = false
            viewBottom.layer.frame.size.height = 50
        } else {
            viewBottom.layer.frame.size.height = 0
            viewBottom.isHidden = true
        }
        initset()
    }
    func initset() {
        viewmodel.validateValue()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print((viewmodel.model?.otherAddresses.count ?? 0) + 1)

        
        
        if viewmodel.model?.defaultAddress != nil {
            return (viewmodel.model?.otherAddresses.count ?? 0) + 1
        }
        return viewmodel.model?.otherAddresses.count ?? 0
     //   return arrCotegory.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        
        if viewmodel.model?.defaultAddress != nil {
            if indexPath.row == 0 {
                return 220

            } else {
                if indexPath.row == 1 {
                    return 220

                } else {
                    return 190

                }

            }
        } else {
            if indexPath.row == 0 {
                return 220

            } else {
                return 190

            }
        }
        return 220
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tblAddlist.separatorColor = .clear
       
        let selectedView = UIView()
        selectedView.backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        if viewmodel.model?.defaultAddress != nil {
           
            
            if indexPath.row == 0 {
                let cell = tblAddlist.dequeueReusableCell(withIdentifier: CellIdentifier.LMAddresslistCell, for: indexPath) as! LMAddresslistCell
                cell.selectionStyle = .none

                cell.headerheightconstraint.constant = 40
                if viewmodel.model?.defaultAddress != nil {
                    cell.lblHeader.text = keyName.DefaultAddress
                    
                    let obj = viewmodel.model?.defaultAddress
                    cell.btnedit.tag         = indexPath.row
                    cell.btndelete.tag       = indexPath.row
                    cell.lblName.text        = (obj?.name ?? "")
                    cell.lblAddress.text     = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "")
                    cell.lblCity.text        = (obj?.city ?? "") + " " + (obj?.state ?? "")
                    cell.lblPhonenumber.text = "Phone Number: " + (obj?.mobile ?? "")
                    cell.btndelete.addTarget(self, action: #selector(LMAddresslistVC.delegateaddress(_:)), for: .touchUpInside)
                    cell.btnedit.addTarget(self, action: #selector(LMAddresslistVC.Editaddress(_:)), for: .touchUpInside)
                    
                    
                    if flagAddressDirectionCheck == true {
                        cell.btnSelect.isHidden = false
                        cell.viewWidthCOnstraint.constant = 25
                        cell.btndelete.isHidden = true
                    } else {
                        cell.btnSelect.isHidden = true
                        cell.viewWidthCOnstraint.constant = 0
                    }
                    if selectCell == indexPath || addressID == (obj?.id ?? ""){
                        selectCell = nil
                        addressID = (obj?.id ?? "")
                        strAddress = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "") + " " + (obj?.city ?? "") + " " + (obj?.state ?? "")
                        cell.btnSelect.setImage(UIImage(named: "fillcircle.png"), for:.normal)
                    } else {
                        cell.btnSelect.setImage(UIImage(named: "circle.png"), for:.normal)
                    }

                } else {
                    if indexPath.row == 0{
                        cell.headerheightconstraint.constant = 40
                    } else {
                        cell.headerheightconstraint.constant = 0
                    }
                    
                    cell.lblHeader.text = keyName.otherSave
                    let obj = viewmodel.model?.otherAddresses[indexPath.row - 1]
                    cell.btnedit.tag         = indexPath.row
                    cell.btndelete.tag       = indexPath.row
                    cell.lblName.text        = (obj?.name ?? "")
                    cell.lblAddress.text     = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "")
                    cell.lblCity.text        = (obj?.city ?? "") + " " + (obj?.state ?? "")
                    cell.lblPhonenumber.text = "Phone Number: " + (obj?.mobile ?? "")
                    cell.btndelete.addTarget(self, action: #selector(LMAddresslistVC.delegateaddress(_:)), for: .touchUpInside)
                    cell.btnedit.addTarget(self, action: #selector(LMAddresslistVC.Editaddress(_:)), for: .touchUpInside)

                    
                    if flagAddressDirectionCheck == true {
                        cell.btnSelect.isHidden = false
                        cell.viewWidthCOnstraint.constant = 25
                        cell.btndelete.isHidden = true
                    } else {
                        cell.btnSelect.isHidden = true
                        cell.viewWidthCOnstraint.constant = 0
                    }
                    
                    if selectCell == indexPath || addressID == (obj?.id ?? ""){
                        selectCell = nil
                        addressID = (obj?.id ?? "")
                        strAddress = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "") + " " + (obj?.city ?? "") + " " + (obj?.state ?? "")

                        cell.btnSelect.setImage(UIImage(named: "fillcircle.png"), for:.normal)
                    } else {
                        cell.btnSelect.setImage(UIImage(named: "circle.png"), for:.normal)
                    }
                }
                cell.selectedBackgroundView = selectedView

                return cell
            } else {
                let cell = tblAddlist.dequeueReusableCell(withIdentifier: CellIdentifier.LMAddresslistCell, for: indexPath) as! LMAddresslistCell
                cell.selectionStyle = .none

              
                if indexPath.row == 1 {
                    
                    if viewmodel.model?.defaultAddress != nil {
                        cell.headerheightconstraint.constant = 40
                        
                        cell.lblHeader.text = keyName.otherSave
                        let obj = viewmodel.model?.otherAddresses[indexPath.row - 1]
                        cell.btnedit.tag         = indexPath.row
                        cell.btndelete.tag       = indexPath.row
                        cell.lblName.text        = (obj?.name ?? "")
                        cell.lblAddress.text     = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "")
                        cell.lblCity.text        = (obj?.city ?? "") + " " + (obj?.state ?? "")
                        cell.lblPhonenumber.text = "Phone Number: " + (obj?.mobile ?? "")
                        cell.btndelete.addTarget(self, action: #selector(LMAddresslistVC.delegateaddress(_:)), for: .touchUpInside)
                        cell.btnedit.addTarget(self, action: #selector(LMAddresslistVC.Editaddress(_:)), for: .touchUpInside)

                        if flagAddressDirectionCheck == true {
                            cell.btnSelect.isHidden = false
                            cell.viewWidthCOnstraint.constant = 25
                            cell.btndelete.isHidden = true
                        } else {
                            cell.btnSelect.isHidden = true
                            cell.viewWidthCOnstraint.constant = 0
                        }
                        
                        if selectCell == indexPath || addressID == (obj?.id ?? ""){
                            selectCell = nil
                            addressID = (obj?.id ?? "")
                            strAddress = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "") + " " + (obj?.city ?? "") + " " + (obj?.state ?? "")

                            cell.btnSelect.setImage(UIImage(named: "fillcircle.png"), for:.normal)
                        } else {
                            cell.btnSelect.setImage(UIImage(named: "circle.png"), for:.normal)
                        }
                        cell.selectedBackgroundView = selectedView

                        return cell

                    }
                } else {
                        cell.headerheightconstraint.constant = 0

                        let obj = viewmodel.model?.otherAddresses[indexPath.row - 1]
                        cell.btnedit.tag         = indexPath.row
                        cell.btndelete.tag       = indexPath.row
                        cell.lblName.text        = (obj?.name ?? "")
                        cell.lblAddress.text     = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "")
                        cell.lblCity.text        = (obj?.city ?? "") + " " + (obj?.state ?? "")
                        cell.lblPhonenumber.text = "Phone Number: " + (obj?.mobile ?? "")
                        cell.btndelete.addTarget(self, action: #selector(LMAddresslistVC.delegateaddress(_:)), for: .touchUpInside)
                        cell.btnedit.addTarget(self, action: #selector(LMAddresslistVC.Editaddress(_:)), for: .touchUpInside)

                    if flagAddressDirectionCheck == true {
                        cell.btnSelect.isHidden = false
                        cell.viewWidthCOnstraint.constant = 25
                        cell.btndelete.isHidden = true
                    } else {
                        cell.btnSelect.isHidden = true
                        cell.viewWidthCOnstraint.constant = 0
                    }
                    
                    if selectCell == indexPath || addressID == (obj?.id ?? ""){
                        selectCell = nil
                        addressID = (obj?.id ?? "")
                        strAddress = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "") + " " + (obj?.city ?? "") + " " + (obj?.state ?? "")
                        cell.btnSelect.setImage(UIImage(named: "fillcircle.png"), for:.normal)
                    } else {
                        cell.btnSelect.setImage(UIImage(named: "circle.png"), for:.normal)
                    }
                    cell.selectedBackgroundView = selectedView

                    return cell

                    }
                }
            
        } else {
            let cell = tblAddlist.dequeueReusableCell(withIdentifier: CellIdentifier.LMAddresslistCell, for: indexPath) as! LMAddresslistCell
            
           
            
            if indexPath.row == 0{
                cell.headerheightconstraint.constant = 40
            } else {
                cell.headerheightconstraint.constant = 0
            }
                    cell.lblHeader.text = keyName.otherSave
                    let obj = viewmodel.model?.otherAddresses[indexPath.row]
                    cell.btnedit.tag         = indexPath.row
                    cell.btndelete.tag       = indexPath.row 
                    cell.lblName.text        = (obj?.name ?? "")
                    cell.lblAddress.text     = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "")
                    cell.lblCity.text        = (obj?.city ?? "") + " " + (obj?.state ?? "")
                    cell.lblPhonenumber.text = "Phone Number: " + (obj?.mobile ?? "")

                    cell.btndelete.addTarget(self, action: #selector(LMAddresslistVC.delegateaddress(_:)), for: .touchUpInside)
                    cell.btnedit.addTarget(self, action: #selector(LMAddresslistVC.Editaddress(_:)), for: .touchUpInside)
            if flagAddressDirectionCheck == true {
                cell.btnSelect.isHidden = false
                cell.viewWidthCOnstraint.constant = 25
                cell.btndelete.isHidden = true
            } else {
                cell.btnSelect.isHidden = true
                cell.viewWidthCOnstraint.constant = 0
            }
            if selectCell == indexPath || addressID == (obj?.id ?? ""){
                selectCell = nil
                addressID = (obj?.id ?? "")
                strAddress = (obj?.houseNumber ?? "") + " " + (obj?.area ?? "") + " " + (obj?.city ?? "") + " " + (obj?.state ?? "")
                cell.btnSelect.setImage(UIImage(named: "fillcircle.png"), for:.normal)
            } else {
                cell.btnSelect.setImage(UIImage(named: "circle.png"), for:.normal)
            }
            cell.selectedBackgroundView = selectedView

            return cell

                }
        let cell = tblAddlist.dequeueReusableCell(withIdentifier: CellIdentifier.LMAddresslistCell, for: indexPath) as! LMAddresslistCell

        return cell

        }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var obj : Addresslisting?
        if viewmodel.model?.defaultAddress != nil {
                if indexPath.row == 0 {
                    if viewmodel.model?.defaultAddress != nil {
                         obj = viewmodel.model?.defaultAddress
                    } else {
                         obj = viewmodel.model?.otherAddresses[indexPath.row - 1]
                    }
                   
                } else {
                    if indexPath.row == 1 {
                        if viewmodel.model?.defaultAddress != nil {
                             obj = viewmodel.model?.otherAddresses[indexPath.row - 1]
                        }
                    } else {
                             obj = viewmodel.model?.otherAddresses[indexPath.row - 1]
                        }
                    }
            } else {
                         obj = viewmodel.model?.otherAddresses[indexPath.row]
            }
          
        guard let phoneNumber = THUserDefaultValue.phoneNumber else {
            return
        }
               
        viewmodel.callEditApi(name: obj?.name ?? keyName.name, phoneNo: phoneNumber, pincode: obj?.pinCode ?? keyName.name, house: obj?.houseNumber ?? keyName.name, area: obj?.area ?? keyName.name, city: obj?.city ?? keyName.name, state: obj?.state ?? keyName.name, country:"India", degaultaddress: true,addressId: obj?.id ?? "")
        selectCell = indexPath
        addressID = obj?.id ?? ""
        self.tblAddlist.reloadData()
    }

      
    
    // MARK: - Action
    // MARK: - Action
    @objc func Editaddress(_ sender : UIButton) {
      let tag = sender.tag
        var obj : Addresslisting?
      
        
        if viewmodel.model?.defaultAddress != nil {
                if tag == 0 {
                    if viewmodel.model?.defaultAddress != nil {
                         obj = viewmodel.model?.defaultAddress
                    } else {
                         obj = viewmodel.model?.otherAddresses[tag - 1]
                    }
                   
                } else {
                    if tag == 1 {
                        if viewmodel.model?.defaultAddress != nil {
                             obj = viewmodel.model?.otherAddresses[tag - 1]
                        }
                    } else {
                             obj = viewmodel.model?.otherAddresses[tag - 1]
                        }
                    }
            } else {
                         obj = viewmodel.model?.otherAddresses[tag]
            }
        
        
        
        
        
        
       // let obj = viewmodel.model?.otherAddresses[tag]
//        let secondVC = LMAddressAddVC1()
//        secondVC.edit = keyName.Edit
//        secondVC.modeldata = obj
//        navigationController?.pushViewController(secondVC, animated: true)
//        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMAddressAddVC1) as! LMAddressAddVC1
        secondVC.edit      = keyName.Edit
        secondVC.modeldata = obj
        self.navigationController?.pushViewController(secondVC, animated: true)
        
        
        //viewmodel.deleteValue(addressId: obj?.id ?? keyName.emptyStr)

    }
    @objc func delegateaddress(_ sender : UIButton) {
      let tag = sender.tag
        if tag == 0 {
            if viewmodel.model?.defaultAddress != nil {
                let obj = viewmodel.model?.defaultAddress
                viewmodel.deleteValue(addressId: obj?.id ?? keyName.emptyStr)
            } else {
                let obj = viewmodel.model?.otherAddresses[tag]
                viewmodel.deleteValue(addressId: obj?.id ?? keyName.emptyStr)
            }
        } else {
            let obj = viewmodel.model?.otherAddresses[tag]
            viewmodel.deleteValue(addressId: obj?.id ?? keyName.emptyStr)
        }
        
  

    }
    
    @IBAction func actAdd(_ sender: Any) {
        let tag = (sender as AnyObject).tag
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(withIdentifier: VcIdentifier.LMAddressAddVC1) as! LMAddressAddVC1
        secondVC.edit      = keyName.emptyStr
        self.navigationController?.pushViewController(secondVC, animated: true)
        
    }
    @IBAction func actBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func actFilter(_ sender: Any) {
            self.NavigationController(navigateFrom: self, navigateTo: LMFilterVC(), navigateToString: VcIdentifier.LMFilterVC)
        }
    
    @IBAction func actDeliverHere(_ sender: Any) {
        
//        viewmodel.validateValue(AddressId: modeldata?.id ?? "")
    
        onAddressSelected?(strAddress, addressID)
        self.navigationController?.popViewController(animated: true)

    }
}

