//
//  RetailShopViewController.swift
//  TouringHealth
//
//  Created by chetu on 27/10/22.
//

import UIKit
import SafariServices
import WebKit

class LMPrivacyPolicyVC: UIViewController {
    
    @IBOutlet weak var lblPrivacy: UILabel!
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    var openURL = ""
    var isFrom :isFromScreen = .none

    override func viewDidLoad() {
        super.viewDidLoad()
        
        activityIndicator.isHidden = true
        
        if isFrom == .privacyPolicy {
            lblPrivacy.text = "privacy Policy"
            webView.load(URLRequest(url: URL(string: "https://www.loomfashion.co.in/policies/privacy-policy")!))
        } else {
            lblPrivacy.text = "return Policy"

            webView.load(URLRequest(url: URL(string: "https://www.loomfashion.co.in/policies/refund-policy")!))
        }
//            switch isFrom {
//            case .fromDiagnosisDetails:
//                viewModel.openUrl(url: openURL)
//            case .fromPrivacyPolicy:
//                webView.load(URLRequest(url: URL(string: "https://uat.thwwwsuccess.com/uploads/privacy-policy.pdf")!))
//            case .termAndConditions:
//                webView.load(URLRequest(url: URL(string: "https://touringhealth.com/wp-content/uploads/2023/04/HIPPA-2023-1.pdf")!))
//            case.openSourceInfo1:
//                webView.load(URLRequest(url: URL(string: openURL)!))
//            case.healthCare101:
//                webView.load(URLRequest(url: URL(string: openURL)!))
//            case.registration:
//                webView.load(URLRequest(url: URL(string: openURL)!))
//            case.logIn:
//                webView.load(URLRequest(url: URL(string: openURL)!))
//            default:
//                viewModel.getURLfromAPI()
//            }
        guard self.checkInternet else{
            return
        }
        webView.navigationDelegate = self



    }
    
    //MARK: action handler
    @IBAction func backActionAction(_ sender: UIButton) {
        activityIndicator.isHidden = true
        activityIndicator.stopAnimating()
        self.navigationController?.popViewController(animated: true)
       
    }
   

}


//MARK: webview delegate
extension LMPrivacyPolicyVC: WKNavigationDelegate{
  func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
      debugPrint(#function)
  }

  func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
      activityIndicator.startAnimating()
      activityIndicator.isHidden = false
      debugPrint(#function)
  }

  func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
      activityIndicator.stopAnimating()
      activityIndicator.isHidden = true
      debugPrint(#function)
  }

  func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
      debugPrint(#function)
  }

  func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
      activityIndicator.stopAnimating()
      activityIndicator.isHidden = true
      debugPrint(#function)
  }

  func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
      //SwiftLoader.show(title: keyName.loading, animated: true)
      debugPrint(#function)
  }

  func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
      debugPrint(#function)
  }

  func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
      debugPrint(#function)
      //SwiftLoader.hide()
      activityIndicator.startAnimating()
      activityIndicator.isHidden = false
     // SwiftLoader.show(title: keyName.loading, animated: true)
      completionHandler(.performDefaultHandling,nil)
  }

  func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
      debugPrint(#function)
      decisionHandler(.allow)
  }

  func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
      debugPrint(#function)
      decisionHandler(.allow)
  }
}
