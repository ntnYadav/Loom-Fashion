//
//  MainCell.swift
//  expandableCellDemo
//
//  Created by Flucent tech on 07/04/25.
//

import UIKit

class priceSubCategoryDetailTableCell : UITableViewCell {
   
    @IBOutlet weak var lblYoumayLIke: UILabel!
    @IBOutlet weak var btnDelete: UIButton!
    // @IBOutlet weak var lblMRP: NSLayoutConstraint!
    @IBOutlet weak var lblMRPPrice: UILabel!
    
    @IBOutlet weak var lblSellingPrice: UILabel!
    @IBOutlet weak var lblSelling: UILabel!
    
    @IBOutlet weak var lblProductDiscount: UILabel!
    @IBOutlet weak var lblProductDiscountPrice: UILabel!

    @IBOutlet weak var lblBagTotal: UILabel!
    
    @IBOutlet weak var lblCOD: UILabel!
    @IBOutlet weak var lblCODPrice: UILabel!
    
    @IBOutlet weak var lblCouponDiscount: UILabel!
    @IBOutlet weak var lblCouponDiscountprice: UILabel!

    @IBOutlet weak var lblGrandTotal: UILabel!
    @IBOutlet weak var lblGrandTotalPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        lblBagTotal.font           = UIFont(name: ConstantFontSize.regular, size: 14)
//        
//        lblSellingPrice.font      = UIFont(name: ConstantFontSize.regular, size: 14)
//        lblSelling.font           = UIFont(name: ConstantFontSize.regular, size: 14)
//        
//        lblProductDiscount.font      = UIFont(name: ConstantFontSize.regular, size: 14)
//        lblCouponDiscountprice.font     = UIFont(name: ConstantFontSize.regular, size: 14)
//        
//        lblCOD.font           = UIFont(name: ConstantFontSize.regular, size: 14)
//        lblCODPrice.font      = UIFont(name: ConstantFontSize.regular, size: 14)
//        
//        lblGrandTotal.font = UIFont(name: ConstantFontSize.regular, size: 14)
//        lblGrandTotalPrice.font = UIFont(name: ConstantFontSize.regular, size: 14)
//
//        lblMRPPrice.font = UIFont(name: ConstantFontSize.regular, size: 14)
//        lblGrandTotal.font = UIFont(name: ConstantFontSize.regular, size: 14)
//        
//        
//        lblCouponDiscount.font = UIFont(name: ConstantFontSize.regular, size: 14)
//        lblCouponDiscountprice.font = UIFont(name: ConstantFontSize.regular, size: 14)

    }
}

class LMCartSecondCell : UITableViewCell{
    @IBOutlet weak var lblApply: UILabel!
    
    @IBOutlet weak var btnApply: UIButton!
    @IBOutlet weak var lblOrder: UILabel!
    @IBOutlet weak var lblOfferName: UILabel!
}
