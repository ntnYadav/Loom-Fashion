//
//  LMProductDetailVC.swift
//  LoomApp
//
//  Created by Flucent tech on 07/04/25.
//
import UIKit
import SDWebImage
import UIKit
import ImageIO
import MobileCoreServices

class LMCartTableVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    let imgGif = UIImage.gifImageWithName("splas")
    @IBOutlet weak var imgGIF1: SDAnimatedImageView!

    @IBOutlet weak var viewOfferAlert: UIView!
    @IBOutlet weak var lblFlate: UILabel!
    @IBOutlet weak var lblOffer: UILabel!
    @IBOutlet weak var viewPopOffer: UIView!
    @IBOutlet weak var btnSHopping: UIButton!
    @IBOutlet weak var viewEmpty: UIView!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var btnChnage: UIButton!
    @IBOutlet weak var btnBack: UIButton!
    let tableView = UITableView()
    lazy fileprivate var viewmodel = LMCartTableMV(hostController: self)
    @IBOutlet weak var btnPay: UIButton!
    var addresID:String = keyName.name
    var flagBack:Bool = true
    // Sample data: array of sections, each with an array of rows
    @IBOutlet weak var tblcart: UITableView!
    var flag:Bool = true
    var payableAmount: Double = 0.0
    var finalAmountPayment: String = ""
    var discount: String = ""
    var discountcode: String = ""
    var backBtn: String = ""
    var couponFlag: String = ""

    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    //    var finalAmountPayment: String = ""
//    var finalAmountPayment: String = ""

    let data = [
        ("Fruits", ["Carrot"])]

    override func viewDidLoad() {
        super.viewDidLoad()
        imgGIF1.isHidden = true
        viewOfferAlert.isHidden = true
        if flagBack == false {
            btnBack.isHidden = false
        }
        view.backgroundColor = .white
        overrideUserInterfaceStyle = .light

        // Setup TableView
        tblcart.frame = view.bounds
        tblcart.dataSource = self
        tblcart.delegate   = self
        tblcart.register(UINib(nibName: "CartCustomHeaderView", bundle: nil), forHeaderFooterViewReuseIdentifier: "CartCustomHeaderView")
        tblcart.register(UINib(nibName: "LMCartBagCellCell", bundle: nil), forCellReuseIdentifier: "LMCartBagCellCell")

        tblcart.register(UINib(nibName: "ExpandableCell", bundle: nil), forCellReuseIdentifier: "ExpandableCell")
        tblcart.register(UINib(nibName: "priceSubCategoryDetailTableCell", bundle: nil), forCellReuseIdentifier: "priceSubCategoryDetailTableCell")
        view.addSubview(tableView)
        btnSHopping.layer.borderColor = UIColor.lightGray.cgColor
        btnSHopping.layer.borderWidth = 0.5
    }

    @IBOutlet weak var viewBottomConstraint: NSLayoutConstraint!
    override func viewWillAppear(_ animated: Bool) {
        
        if backBtn == "Product" {
            bottomConstraint.constant = 20
            viewBottomConstraint.constant = 20
            btnBack.isHidden = false
        } else {
            btnBack.isHidden = true
        }
        viewmodel.validateGetAddressList()

        if AppDelegate.shared.tabbarFlag == true {
            viewmodel.validateValue()
        }
    }
    
    // MARK: - TableView DataSource

    func numberOfSections(in tableView: UITableView) -> Int {
        print("data.count ==\(data.count)")
        return data.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            viewmodel.modelproduct?.items.reversed()
            return viewmodel.modelproduct?.items.count ?? 0
        } else {
            return 1
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
 
        let obj = viewmodel.modelproduct?.items[indexPath.row]
        if obj?.variantId == "offer" {
            let cell = tblcart.dequeueReusableCell(withIdentifier: "LMCartSecondCell", for: indexPath) as! LMCartSecondCell
            cell.selectionStyle = .none

            if viewmodel.modelproduct?.pricingSummary.couponDiscount == 0.0 {
                cell.btnApply.isHidden = true
                cell.lblOfferName.text = "To get more discount use coupon"
                cell.lblApply.text = ""

            } else {
                cell.btnApply.isHidden = false
                let fullText1 = "COUPON "
                let amountText = (viewmodel.modelproduct?.pricingSummary.couponCode ?? "")
                let codeText = " APPLIED"
                let fullText = fullText1 + amountText + codeText
                let attributedText = NSMutableAttributedString(string: fullText,
                    attributes: [.font: UIFont.systemFont(ofSize: 16)])
                // Manually find the start index of the second word
                // Assume words are separated by spaces
                let words = fullText.components(separatedBy: " ")
                var currentLocation = 0
                for (index, word) in words.enumerated() {
                    let wordLength = word.count
                    if index == 1 { // second word
                        let nsRange = NSRange(location: currentLocation, length: wordLength)
                        attributedText.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 16), range: nsRange)
                        break
                    }
                    currentLocation += wordLength + 1 // +1 for the space
                }
                cell.lblOfferName.attributedText = attributedText

                cell.lblApply.text = "Remove"
                cell.btnApply.tag = indexPath.row
                cell.btnApply.addTarget(self, action: #selector(LMCartTableVC.RemoveCart(_:)), for: .touchUpInside)

            }
            
            //self.tblcart.separatorColor = .clear
            return cell
        } else if obj?.variantId == "otherDetail" {
            let cell = tblcart.dequeueReusableCell(withIdentifier: "ExpandableCell", for: indexPath) as! ExpandableCell
            cell.selectionStyle = .none

            cell.setupEverytime()
            self.tblcart.separatorColor = .clear
            return cell
            return cell
        } else if obj?.variantId == "price"{
            let cell = tblcart.dequeueReusableCell(withIdentifier: "priceSubCategoryDetailTableCell", for: indexPath) as! priceSubCategoryDetailTableCell
            cell.selectionStyle = .none

            
            cell.btnDelete.isHidden     = true
            cell.lblYoumayLIke.isHidden = true

            let obj = viewmodel.modelproduct?.pricingSummary

            if let price = obj?.payableAmount {
                let price = String(format: "%.2f", price)
                cell.lblGrandTotalPrice.text = keyName.rupessymbol  + "\(price)"
                let amout = "Pay " + keyName.rupessymbol + " \(price)"
                btnPay.setTitle(amout, for: .normal)
                finalAmountPayment = "\(price)"
            }
            if let baseTotal = obj?.baseTotal {
                cell.lblMRPPrice.text = keyName.rupessymbol  + "\(baseTotal)"
            }
            if let couponDiscount = obj?.couponDiscount {
                let dicountvaluetemp = String(format: "%.2f", couponDiscount)
                cell.lblCouponDiscountprice.text   = "- " +  keyName.rupessymbol  + "\(dicountvaluetemp)"
                discount = " \(dicountvaluetemp)"
            }
            if let couponDiscount = obj?.couponCode {
                discountcode = " \(couponDiscount)"
            }

            if let sellingPrice = obj?.sellingTotal {
                let sellingPrice = String(format: "%.2f", sellingPrice)
                cell.lblSellingPrice.text =  keyName.rupessymbol  + "\(sellingPrice)"
            }
            
            if let savings = obj?.savings {
                let savings = String(format: "%.2f", savings)
                cell.lblProductDiscountPrice.text =  "- " + keyName.rupessymbol  + "\(savings)"
            }
            
            self.tblcart.separatorColor = .clear
            return cell
        } else {
            if indexPath.section == 1 {
                let cell = tblcart.dequeueReusableCell(withIdentifier: "ExpandableCell", for: indexPath) as! ExpandableCell
                cell.selectionStyle = .none

                cell.setupEverytime()
                self.tblcart.separatorColor = .clear
                return cell
            } else {
                let cell = tblcart.dequeueReusableCell(withIdentifier: "LMCartBagCellCell", for: indexPath) as! LMCartBagCellCell
                cell.selectionStyle = .none

                self.tblcart.separatorColor = .clear
                //cell.lblProductName.text = obj.na
                //cell.btnQtylisting.addTarget(self, action: #selector(LMCartTableVC.qty(_:)), for: .touchUpInside)
                cell.btndelete.addTarget(self, action: #selector(LMCartTableVC.DeleteCart(_:)), for: .touchUpInside)

                let objModel = viewmodel.modelproduct?.items[indexPath.row]
                
                cell.lblProductDetail.font = UIFont(name: ConstantFontSize.regular, size: 14)
                cell.lblProductName.font   = UIFont(name: ConstantFontSize.regular, size: 14)
                cell.lblSize.font          = UIFont(name: ConstantFontSize.regular, size: 14)
                cell.lblPrice.font         = UIFont(name: ConstantFontSize.regular, size: 14)

                cell.productQty = objModel?.avlVarQnty ?? 0
                cell.lblProductName.text = objModel?.productTitle
                cell.lblProductDetail.text = (objModel?.color ?? "") + " | " + (objModel?.size ?? "")

                if let qty = (objModel?.quantity){
                    cell.lblSize.text = "  QTY | " + String(qty)
                }

                if let url = (objModel?.productImage){
                    cell.imgProduct.sd_setImage(with: URL(string: url))
                }
                cell.onCollectionItemupdateQty = { [weak self] indexvalue, qty in
                    let objModel = self?.viewmodel.modelproduct?.items[indexvalue]
                        self?.viewmodel.validateUpdateQty(id: objModel?.id ?? "", qty: qty)
                }
                
                if let price = viewmodel.modelproduct?.items[indexPath.row].priceSnapshot {
                    let mrp = price.basePrice!
                    let sellingPrice = price.sellingPrice!
                    let discountPercent = 0
                    let attributedPriceText = createPriceAttributedText(
                        discountPercent: 0,
                        originalPrice: mrp,
                        discountedPrice: sellingPrice
                    )
                    cell.lblPrice.attributedText = attributedPriceText
                }
                
                return cell
            }
        }
    }
  
    @objc func RemoveCart(_ sender : UIButton) {
        let tag = sender.tag
        couponFlag = ""
        viewmodel.modelproduct?.pricingSummary.couponDiscount      = 0.0
        self.viewmodel.modelproduct?.pricingSummary.payableAmount  = self.payableAmount
        self.viewmodel.modelproduct?.pricingSummary.couponCode     = ""
        tblcart.reloadData()
    }
    @objc func DeleteCart(_ sender : UIButton) {
        let tag = sender.tag
        if let objModel = self.viewmodel.modelproduct?.items[tag] {
            self.viewmodel.validateDeleteCart(id: objModel.id ?? "")
        }
    }
    
    @objc func qty(_ sender : UIButton) {
      let tag = sender.tag
        let objModel = viewmodel.modelproduct?.items[tag]
        
        if objModel?.avlVarQnty ?? 0 <= 5 {
            let input = (objModel?.avlVarQnty)!
            let arr = (1...input).map { "\($0)" }
            RPicker.selectOption(dataArray: arr) {[weak self] (selctedText, atIndex) in
                
            }
        } else {
            RPicker.selectOption(dataArray: THconstant.arrqty) {[weak self] (selctedText, atIndex) in
                
            }
        }
    }
    // MARK: - Header Titles
    func createPriceAttributedText(discountPercent: Int, originalPrice: Double, discountedPrice: Double) -> NSAttributedString {
        let attributedText = NSMutableAttributedString()

        // Discount arrow + percentage
//        let discountString = "↓ \(discountPercent)% "
//        let discountAttributes: [NSAttributedString.Key: Any] = [
//            .foregroundColor: UIColor.systemGreen,
//            .font: UIFont(name: ConstantFontSize.regular, size: 13)
//        ]
//        attributedText.append(NSAttributedString(string: discountString, attributes: discountAttributes))

        // Original price with strikethrough
        let originalPriceString = "₹\(Int(originalPrice)) "
        let originalPriceAttributes: [NSAttributedString.Key: Any] = [
            .strikethroughStyle: NSUnderlineStyle.single.rawValue,
            .foregroundColor: UIColor.gray,
            .font: UIFont(name: ConstantFontSize.regular, size: 14)
        ]
        attributedText.append(NSAttributedString(string: originalPriceString, attributes: originalPriceAttributes))

        // Discounted price
        let discountedPriceString = "₹\(Int(discountedPrice))"
        let discountedPriceAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.black,
            .font: UIFont(name: ConstantFontSize.Semibold, size: 14)
        ]
        attributedText.append(NSAttributedString(string: discountedPriceString, attributes: discountedPriceAttributes))

        return attributedText
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tblcart.dequeueReusableHeaderFooterView(withIdentifier: "CartCustomHeaderView") as! CartCustomHeaderView
        //headerView.sectionTitleLabel.text = arrRecent[section]
        self.tblcart.separatorColor = .clear

        return headerView
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1{
            return 70
        } else {
            return 0
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        
        print("indexPath.section=== \(indexPath.section)")
        if indexPath.section == 1{
            return 800
        } else {
            let obj = viewmodel.modelproduct?.items[indexPath.row]
            if obj?.variantId == "offer" {
                return 125
            } else if obj?.variantId == "price"{
                return 300

            } else {
                return 180

            }
         }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = viewmodel.modelproduct?.items[indexPath.row]
        if obj?.variantId == "offer" {
             let secondVC = LMCouponVC()
              secondVC.totalAmount = self.payableAmount
              secondVC.couponFlag  = self.couponFlag

              secondVC.onCouponSelected = { amountFianl , discoutAmount, distype ,couponID  in
                  AppDelegate.shared.tabbarFlag = false

                  self.couponFlag = couponID
                print("User selected: \(amountFianl)\(discoutAmount)\(distype)")
                  self.viewmodel.modelproduct?.pricingSummary.couponDiscount = discoutAmount
                  self.viewmodel.modelproduct?.pricingSummary.payableAmount  = amountFianl
                  self.viewmodel.modelproduct?.pricingSummary.couponCode     = distype

                  
                  print("self.viewmodel.modelproduct?.pricingSummary.payableAmount : \(self.viewmodel.modelproduct?.pricingSummary.payableAmount )")
                  self.flag = false
                  DispatchQueue.main.async {
                      self.tblcart.reloadData()
                  }
                  

                  
                  
                  
                  
                  
                  let attributedString = NSMutableAttributedString(
                      string: "\(distype)",
                      attributes: [
                          .foregroundColor: UIColor.black,
                          .font: UIFont.systemFont(ofSize: 13)
                      ]
                  )

                  let secondPart = NSAttributedString(
                      string: "APPLIED",
                      attributes: [
                          .foregroundColor: UIColor.orange,
                          .font: UIFont.boldSystemFont(ofSize: 12)
                      ]
                  )

                  attributedString.append(secondPart)
                  self.lblFlate.attributedText = attributedString
                  
                  self.lblOffer.text = "You Saved ₹ \(discoutAmount)"


                                    
                  self.imgGIF1.isHidden = false
                  self.viewOfferAlert.isHidden = false

                  self.imgGIF1.sd_imageIndicator = SDWebImageActivityIndicator.gray
                  self.imgGIF1.sd_setImage(with: URL(string: "https://loomfashion-buk123.s3.ap-south-1.amazonaws.com/Uploads/Admin/Images/1750834019491-345765673.gif"), placeholderImage: UIImage(named: "placeholder"))
                  
                  DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in
                      self?.imgGIF1.isHidden = true
                      self?.viewOfferAlert.isHidden = true

                      self?.imgGIF1.image = nil
                  }

                  
            }
             navigationController?.pushViewController(secondVC, animated: true)
        }
    }
 
 


    
//    func playGIF() {
//        self.imgGIF1.isHidden = false
//
//        if let path = Bundle.main.path(forResource: "64787-success", ofType: "gif"),
//           let data = try? Data(contentsOf: URL(fileURLWithPath: path)),
//           let gifImage = SDAnimatedImage(data: data) {
//
//            // Assign a new image object to force restart
//            self.imgGIF1.image = nil
//            self.imgGIF1.stopAnimating()
//
//            // Optional: play only once (loop count = 1)
//            self.imgGIF1.startAnimating()
//            self.imgGIF1.image = gifImage
//
//            let duration = gifImage.duration
//            DispatchQueue.main.asyncAfter(deadline: .now() + duration) { [weak self] in
//                self?.imgGIF1.isHidden = true
//                self?.imgGIF1.image = nil
//            }
//        }
//    }

    
    @IBAction func actChangeAddress(_ sender: Any) {
       // self.NavigationController(navigateFrom: self, navigateTo: LMAddresslistVC(), navigateToString: VcIdentifier.LMAddresslistVC)
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let modalVC = storyboard.instantiateViewController(withIdentifier:VcIdentifier.LMAddresslistVC) as? LMAddresslistVC {
            modalVC.flagAddressDirectionCheck = true
            modalVC.addressID = addresID
            modalVC.onAddressSelected = { selected, addressID in
                print("User selected: \(selected)")
                self.addresID = addressID
                self.lblAddress.text = "Address: " + selected
            }
            
            self.navigationController?.pushViewController(modalVC, animated: true)
        }
//        
     
    }
    
    @IBAction func actWishList(_ sender: Any) {
    }
    @IBAction func actPay(_ sender: Any) {
        if THUserDefaultValue.isUserLoging  == false {
            let halfVC = LoginVC()
            halfVC.modalPresentationStyle = .overFullScreen
           present(halfVC, animated: true)
            
        } else {
            
            if self.lblAddress.text ==  "ADDRESS: Add your address" {
                AlertManager.showAlert(on: self,
                                       title: "Please select the address",
                                       message: "") {
                }
            } else {
                viewmodel.paymentApi(couponDiscount: discount, addressId: self.addresID, couponCode: discountcode, walletPointsToUse: "0")
            }

            
            print(finalAmountPayment)
//            let price = (Int(finalAmountPayment) ?? 0) + 100
//            obj.amountpayment = finalAmountPayment
//            obj.coupondiscountAmount = discount
//            obj.couponCode = discountcode
//            obj.AddressID =  self.addresID
            //obj.couponCode = self.lbl
            

        }
        
    }
    
    @IBAction func btnStartShopping(_ sender: Any) {
        self.NavigationController(navigateFrom: self, navigateTo: LMTabBarVC(), navigateToString: VcIdentifier.LMTabBarVC)

    }
    @IBAction func actBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}
